import React, { useState, useEffect } from "react";
import {
  endMeetingRedirectUrl,
  guestApp,
  guestWebinarApp,
  telware_meet,
  telware_webinar_meet,
  ONECLOUD_APP_SECRET,
  backendMeetingApi,
  webinarMeeting,
  OneCloudGuestUserID,
  // GuestMaxUserLimit,
  // OneCloudMaxUserLimit,
  Socketurl,
  Baseurl_app,
  getScope_featureList,
  getAllScopesApi,
  GuestScopeId,
  getFeatureFromMeetingIdApi,
  WebinarParticipantId
} from "../../constant";
import { MESSAGES } from "../../constant/messages"
const jwt = require('jwt-simple-error-identify').jwt;
import {
  Redirect,
} from "react-router-dom";
import { toast } from 'react-toastify';
import { getAuthToken } from '../../helpers/auth-header';
let currentMeeting = {};
let activeParticipant = {};
let selfId = {};
let isModerator;
let featureList = {};
let OcScopeData = {};
// let OneCloudMaxUserLimit = 0;
// let GuestMaxUserLimit = 0;
const StartConference = (props) => {
  const jitsiContainerId = "jitsi-container-id";
  const [jitsi, setJitsi] = useState({});
  // const [featureList, setFeatureList] = useState({});
  const cname = props.computedMatch.params.cname;
  const dispname = props.computedMatch.params.dispname;
  const audio = props.computedMatch.params.s_audio;
  const video = props.computedMatch.params.s_video;
  const jwt_token = props.computedMatch.params.token;
  const [checkMeetingForSchedule, setCheckMeetingForSchedule] = useState(false);
  let decoded_token = jwt.decode(jwt_token, ONECLOUD_APP_SECRET, true);

  const [decodedToken, setDecodedToken] = useState(decoded_token);
  // const [isModerator, setIsModerater] = useState(decoded_token.moderator);
  isModerator = decoded_token.moderator;
  const [isWebinar, setIsWebinar] = useState(decoded_token.is_webinar);
  // const [selfParticipantId, setSelfParticipantId] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(localStorage.getItem('isAuthenticated') ? localStorage.getItem('isAuthenticated') : false);
  const [currentMeetingState, setcurrentMeetingState] = useState(localStorage.getItem("current_meeting_data") ? JSON.parse(localStorage.getItem("current_meeting_data")) : {});
  const [meetSocket, setMeetSocket] = useState(new WebSocket(Socketurl + "/ws/hdmeet/" + cname + "/"));
  const [apiUserDetail, setApiUserDetail] = useState(localStorage.getItem('apiUserDetail') ? JSON.parse(localStorage.getItem('apiUserDetail')) : null);
  const meetingUrl = Baseurl_app + '/startwebinar/' + props.computedMatch.params.cname + '/' + props.computedMatch.params.s_audio + '/' + props.computedMatch.params.s_video + '/' + props.computedMatch.params.token
  const [meetingPassword, setMeetingPassword] = useState(decoded_token.password)
  const [tokenExp, settokenExp] = useState(decoded_token.is_webinar ? decoded_token.exp * 1000 : null)

  if (localStorage.getItem('activeParticipant')) {
    let meetingId = JSON.parse(localStorage.getItem('activeParticipant')).meetingId
    if (meetingId != cname || isModerator) {
      localStorage.removeItem('activeParticipant')
    }
  }
  let audioMute = true
  if (audio === "a_on") {
    audioMute = false
  }
  let videoMute = true
  if (video === "v_on") {
    videoMute = false
  }

  const getMeetingsFromMeetingId = async (token, meeting_id) => {
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let result = await fetch(backendMeetingApi + "/" + meeting_id, {
        method: 'GET',
        headers: myHeaders,
      })
      const data = await result.json()
      return data
    } catch (error) {
      console.log(error)
    }
  }


  const getScopeData = async (token, scopeId) => {
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let result = await fetch(getAllScopesApi + "/" + scopeId, {
        method: 'GET',
        headers: myHeaders,
      })
      const data = await result.json()
      return data
    } catch (error) {
      console.log(error)
    }
  }


  const getFeatureData = async (token, scopeId) => {
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let result = await fetch(getScope_featureList + "/" + scopeId, {
        method: 'GET',
        headers: myHeaders,
      })
      const data = await result.json()
      return data
    } catch (error) {
      console.log(error)
    }
  }

  const getFeaturesFromMeetingId = async (token, meeting_id) => {
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let result = await fetch(getFeatureFromMeetingIdApi, {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify({
          current_meeting_id: meeting_id,
        })
      })
      const data = await result.json()
      return data
    } catch (error) {
      console.log(error)
    }
  }


  const loadJitsiScript = () => {
    let resolveLoadJitsiScriptPromise = null;
    const loadJitsiScriptPromise = new Promise(resolve => {
      resolveLoadJitsiScriptPromise = resolve;
    });

    const script = document.createElement("script");
    script.src = "https://" + telware_webinar_meet + "/external_api.js";
    script.async = true;
    script.onload = () => resolveLoadJitsiScriptPromise(true);
    document.body.appendChild(script);
    return loadJitsiScriptPromise;
  };

  meetSocket.onmessage = function (e) {
    const activeParticipantSocketData = JSON.parse(e.data)
    if (activeParticipantSocketData.action == 'dispose') {
      localStorage.removeItem('activeParticipant')
      localStorage.removeItem('current_meeting_data')
      jitsi.executeCommand('hangup');
      if (isAuthenticated) {
        document.location.href = '/';
      } else {
        document.location.href = endMeetingRedirectUrl;
      }
    }
    else if (activeParticipantSocketData.action == 'moderatorChange') {
      let mod_data = activeParticipantSocketData.participantData.filter(function (elem) {
        return elem.role == 'moderator';
      })
      if (mod_data.participantId != selfId.id) {
        // setIsModerater(false)
        // isModerator = false
        // jitsi.executeCommand('toggleLobby', false);
      }
      localStorage.setItem('activeParticipant', JSON.stringify(activeParticipantSocketData))
    }
    else {
      localStorage.setItem('activeParticipant', JSON.stringify(activeParticipantSocketData))
    }
  }

  meetSocket.onclose = function (e) {
    console.error("Socket closed unexpectedly")
  }

  const getWebinarMeeting = async (token) => {
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let result = await fetch(webinarMeeting + "/" + decoded_token.sch_ref_id, {
        method: 'GET',
        headers: myHeaders
      })
      const data = await result.json()
      return data
    } catch (error) {
      console.log(error)
    }
  }

  const createBackendMeeting = async (token, scheduled_meeting) => {
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let result = await fetch(backendMeetingApi, {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify({
          meeting_id: cname,
          meeting_name: scheduled_meeting.title,
          oc_user: scheduled_meeting.oc_user,
          current_attendees: 1, // NOTE: Need to check 
          total_attendees: 1, // NOTE: Need to check 
          auth_user: scheduled_meeting.oc_user == OneCloudGuestUserID ? false : true,
          max_limit_reached: false,
          status: 'I',
          is_webinar: true,
          meeting_url: meetingUrl,
          sch_ref_id: decoded_token.sch_ref_id
        }),
      })
      const data = await result.json()
      return data
    } catch (error) {
      console.log(error)
    }
  }

  const initialiseJitsi = async () => {
    if (isWebinar) {
      let dateNow = new Date();
      if (tokenExp < dateNow.getTime()) {
        toast.dismiss();
        toast.error("Meeting link, Expired!", {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
        await new Promise(resolve => setTimeout(resolve, 500));
        document.location.href = '/';
      }
    }

    let token = await getAuthToken()
    const ongoingMeeting = await getMeetingsFromMeetingId(token, cname)
    localStorage.setItem('current_meeting_data',
      JSON.stringify({ 'detail': ongoingMeeting.detail })
    )
    var featureListData = {}
    if (isModerator) {
      let featureList = await getFeatureData(token, decodedToken.user.webinar_scope);

      var moderatorScope = Object.keys(featureList.Result)

      let hidden_domain = Object.keys(featureList.Result[moderatorScope].config_param).includes("hiddenDomain")

      let featureData_enable_chat = featureList.Result[moderatorScope].config_param.toolbarButtons.value.includes('chat')
      let featureData_hide_viewers = featureList.Result[moderatorScope].config_param.toolbarButtons.value.includes('chat')

      if (decodedToken.webinar_config.enable_chat) {
        if (!featureData_enable_chat) {
          featureList.Result[moderatorScope].config_param.toolbarButtons.value.push('chat')
        }
      }
      else if (!decodedToken.webinar_config.enable_chat) {
        if (featureData_enable_chat) {
          let feature_data = featureList.Result[moderatorScope].config_param.toolbarButtons.value.split(", ")

          let chatIndex = featureList.Result[moderatorScope].config_param.toolbarButtons.value.indexOf('chat')


          let val = feature_data.splice(chatIndex, 1)

          let data = feature_data.join(', ')


          featureList.Result[moderatorScope].config_param.toolbarButtons.value = data;
         



        }
      }
      if (decodedToken.webinar_config.hide_viewers) {

        if (!hidden_domain) {

          featureList.Result[moderatorScope].config_param["hiddenDomain"] = "guest.meet-east1.myonecloud.com"
        }
      } else if (!decodedToken.webinar_config.hide_viewers) {
        if (hidden_domain) {

          let feature_list = featureList.Result[moderatorScope].config_param
          delete feature_list["hiddenDomain"];
        }

      }
      let OcScopeData = await getScopeData(token, decodedToken.user.webinar_scope)
      OcScopeData = OcScopeData.Result
      featureList = featureList.Result
      featureListData = featureList[OcScopeData.name]
    }
    else {
      let featureList = await getFeatureData(token, WebinarParticipantId);

      var attendeeScope = Object.keys(featureList.Result)

      let hidden_domain = Object.keys(featureList.Result[attendeeScope].config_param).includes("hiddenDomain")

      let featureData_enable_chat = featureList.Result[attendeeScope].config_param.toolbarButtons.value.includes('chat')
      // let featureData_hide_viewers = featureList.Result[attendeeScope].config_param.toolbarButtons.value.includes('chat')

      if (decodedToken.webinar_config.enable_chat) {
        if (!featureData_enable_chat) {
          featureList.Result[attendeeScope].config_param.toolbarButtons.value.push('chat')
        }
      }
      else if (!decodedToken.webinar_config.enable_chat) {
        if (featureData_enable_chat) {
          let feature_data = featureList.Result[attendeeScope].config_param.toolbarButtons.value.split(", ")

          let chatIndex = featureList.Result[attendeeScope].config_param.toolbarButtons.value.indexOf('chat')
          chatIndex = chatIndex.toString()[0];


          let val = feature_data.splice(chatIndex, 1)

          let data = feature_data.join(', ')



          featureList.Result[attendeeScope].config_param.toolbarButtons.value = data;



        }
      }
      if (decodedToken.webinar_config.hide_viewers) {

        if (!hidden_domain) {

          featureList.Result[attendeeScope].config_param["hiddenDomain"] = "guest.meet-east1.myonecloud.com"
        }
      } else if (!decodedToken.webinar_config.hide_viewers) {
        if (hidden_domain) {

          let feature_list = featureList.Result[attendeeScope].config_param
          delete feature_list["hiddenDomain"];
        }

      }
      let OcScopeData = await getScopeData(token, WebinarParticipantId);
      OcScopeData = OcScopeData.Result
      featureList = featureList.Result
      featureListData = featureList[OcScopeData.name]
    }


    if (isWebinar && !isModerator) {
      let OneCloudMaxUserLimit = 0;
      let GuestMaxUserLimit = 0;
      const meeting = await getMeetingsFromMeetingId(token, cname);
      if (meeting.multiple == false && meeting.detail.auth_user == false) {
        GuestMaxUserLimit = featureListData.web_participants
      }
      else if (meeting.multiple == false && meeting.detail.auth_user == true) {
        OneCloudMaxUserLimit = featureListData.web_participants
      }
      if (Object.keys(meeting.detail).length < 1) {
      }
      if (meeting.detail.oc_user == OneCloudGuestUserID && meeting.detail.current_attendees >= GuestMaxUserLimit) {
        setCheckMeetingForSchedule(true)
        toast.dismiss();
        toast.error(MESSAGES.maxParticipant, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
        return null
      } else if (meeting.detail.oc_user != OneCloudGuestUserID && meeting.detail.current_attendees >= OneCloudMaxUserLimit) {
        setCheckMeetingForSchedule(true)
        toast.dismiss();
        toast.error(MESSAGES.maxParticipant, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
        return null
      }
    }

    if (!window.JitsiMeetExternalAPI) {
      await loadJitsiScript();
    }
    var config_param_options = {}
    var videoParticipantLimit = featureListData.video_participants
    var recordings = featureListData.recordings
    if (videoParticipantLimit > 0) {
      config_param_options["channelLastN"] = videoParticipantLimit
    }
    if (isAuthenticated) {
      config_param_options["startWithAudioMuted"] = !apiUserDetail.settings.is_audio;
      config_param_options["startWithVideoMuted"] = !apiUserDetail.settings.is_video;
    } else {
      config_param_options["startWithAudioMuted"] = audioMute;
      config_param_options["startWithVideoMuted"] = videoMute;
    }

    var config_param = featureListData.config_param


    Object.entries(config_param).map((elem) => {
      let key = elem[0]
      let elem_value = elem[1]
      let parse_data;
      if (elem_value.type === "Array") {
        parse_data = elem_value.value.split(", ")
      }
      else if (elem_value.type === "Number") {
        parse_data = parseInt(elem_value.value)
      }
      else if (elem_value.type === "String") {
        parse_data = elem_value.value.toString()
      }
      else if (elem_value.type === "Boolean") {
        parse_data = Boolean(elem_value.value)
      }
      else if (elem_value.type === "Object") {
        // let obdata = '{' + elem_value.value + '}';
        // parse_data = elem_value.value.split(", ")
        // let entries = [];
        // parse_data.map((elem) =>{
        //   let item = elem.split(":");
        //   entries.push(item)
        // })
        // parse_data = Object.fromEntries(entries);
        parse_data = JSON.parse(elem_value.value)
      }
      config_param_options[key] = parse_data;
    })
    //console.log(parse_data ,"config_param_options[key]")
    if (recordings) {
      if (Object.keys(config_param_options).includes('toolbarButtons')) {
        config_param_options['toolbarButtons'].push('recording');
      } else {
        config_param_options['toolbarButtons'] = ['recording']
      }

    }
    // if (2==2){
    //   if (Object.keys(featureListData.config_param.toolbarButtons.value).includes('chat')){
    //     config_param_options['toolbarButtons'].push('recording');
    //   }else{
    //     config_param_options['toolbarButtons'] = ['recording']
    //   }

    // }

    const option = {
      parentNode: document.getElementById(jitsiContainerId),
      roomName: cname,
      configOverwrite: config_param_options,
    }
    if (isModerator) {
      option.jwt = jwt_token
    }
    if (isWebinar && decodedToken.user.id !== OneCloudGuestUserID && isModerator) {
      option.userInfo = {
        email: decodedToken.user.email,
        displayName: decodedToken.user.display_name
      }
    }
    if (!isWebinar && isAuthenticated && isModerator) {
      option.userInfo = {
        email: apiUserDetail.email,
        displayName: apiUserDetail.display_name
      }
    }
    if (isAuthenticated && !isModerator) {
      option.userInfo = {
        email: apiUserDetail.email,
        displayName: apiUserDetail.display_name
      }
    }

    if (isModerator && isAuthenticated) {
      // option.interfaceConfigOverwrite.TOOLBAR_BUTTONS.push('recording')
    }

    const meetAPI = new window.JitsiMeetExternalAPI(telware_webinar_meet, option);

    if (isWebinar && isModerator) {
      let token = await getAuthToken()
      let scheduled_meeting = await getWebinarMeeting(token)
      let checkMeetingsFromMeetingId = await getMeetingsFromMeetingId(token, cname)
      currentMeeting = checkMeetingsFromMeetingId.detail
      if (checkMeetingsFromMeetingId.multiple == false && Object.keys(checkMeetingsFromMeetingId.detail).length == 0) {

        let createBackendOnMeeting = await createBackendMeeting(token, scheduled_meeting)
        currentMeeting = createBackendOnMeeting.detail

      }
      meetAPI.executeCommand('subject', currentMeeting.meeting_name)
    }
    if (!isWebinar && isModerator) {
      let ongoingMeeting = JSON.parse(localStorage.getItem('current_meeting_data'))
      meetAPI.executeCommand('subject', ongoingMeeting.detail.meeting_name)
    }

    meetAPI.addEventListener('participantRoleChanged', async function (event) {

      let token = await getAuthToken()
      selfId = event
      if (event.role === 'moderator') {
        meetAPI.executeCommand('toggleLobby', false);
        isModerator = true
        if (isModerator && isWebinar && meetingPassword !== "") {

          meetAPI.executeCommand('password', meetingPassword);
        }
        // if (isModerator && isWebinar && decoded_token.webinar_config.enable_chat) {

        //   meetAPI.executeCommand('toggleChat')
        // }

        if (isModerator && isWebinar && decoded_token.webinar_config.record_meeting) {
          meetAPI.executeCommand('startRecording', {
            mode: 'file',//recording mode, either `file` or `stream`.
            // dropboxToken: string, //dropbox oauth2 token.
            // shouldShare: boolean, //whether the recording should be shared with the participants or not. Only applies to certain jitsi meet deploys.
            // rtmpStreamKey: string, //the RTMP stream key.
            // rtmpBroadcastID: string, //the RTMP broadcast ID.
            // youtubeStreamKey: string, //the youtube stream key.
            // youtubeBroadcastID: string //the youtube broacast ID.
          });

          //meetAPI.executeCommand('toggleChat')
        }



        // if (isModerator && isWebinar && meetingPassword !== "") {
        //   console.log("password::::", meetingPassword)
        //   meetAPI.executeCommand('password', meetingPassword);
        // }
        if (isModerator && isAuthenticated && !isWebinar) {
          if (meetingPassword !== "") {
            meetAPI.executeCommand('password', meetingPassword);
          }
        }
        if (isModerator && isAuthenticated && !isWebinar) {
          if (meetingPassword !== "") {
            meetAPI.executeCommand('toggleChat', false);
          }
        }
        // meetAPI.executeCommand('toggleLobby', true);
        const meeting = await getMeetingsFromMeetingId(token, cname)
        const moderators = meeting.detail.moderators;
        moderators.push(selfId.id)

        if (localStorage.getItem('activeParticipant')) {
          activeParticipant = JSON.parse(localStorage.getItem('activeParticipant'));
          currentMeeting = meeting.detail
          localStorage.setItem('current_meeting_data', JSON.stringify(
            { "detail": meeting.detail }
          ))
          activeParticipant.participantData.map((elem) => {
            if (moderators.includes(elem.participantId)) {
              elem.role = 'moderator'
            }
            else {
              elem.role = 'participant'
            }
            return elem
          })
          meetSocket.send(JSON.stringify({
            'participantData': activeParticipant.participantData,
            'action': 'moderatorChange',
            'meetingId': cname
          }))
        } else {
          activeParticipant = meetAPI.getParticipantsInfo()
          activeParticipant.map((elem) => {
            if (moderators.includes(elem.participantId)) {
              elem.role = 'moderator'
            }
            else {
              elem.role = 'participant'
            }
            return elem
          })
          meetSocket.send(JSON.stringify({
            'participantData': activeParticipant,
            'action': 'moderatorChange',
            'meetingId': cname
          }))
        }
        let meetingObj = {
          moderators: moderators
        }
        meetingObj.id = meeting.detail.id
        let updateMeetingData = updateMeetingsFromMeetingId(token, meetingObj)
      }
    });

    meetAPI.addEventListener('participantLeft', async function (event) {

      let token = await getAuthToken()
      if (isModerator && isWebinar) {
        let meetingObj = {
          current_attendees: meetAPI.getNumberOfParticipants() > 0 ? meetAPI.getNumberOfParticipants() : 0
        }
        meetingObj.id = currentMeeting.id
        let updateMeetingData = updateMeetingsFromMeetingId(token, meetingObj)
      } else if (isModerator && !isWebinar) {
        let meetingObj = {
          current_attendees: meetAPI.getNumberOfParticipants() > 0 ? meetAPI.getNumberOfParticipants() : 0
        }
        meetingObj.id = currentMeetingState.detail.id
        let updateMeetingData = updateMeetingsFromMeetingId(token, meetingObj)
      }
    });

    async function updateMeetingsFromMeetingId(token, meetingObj) {
      try {
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        myHeaders.append('Authorization', 'Bearer ' + token.access);
        let result = await fetch(backendMeetingApi, {
          method: 'PUT',
          headers: myHeaders,
          body: JSON.stringify(meetingObj),
        })
        const data = await result.json()
        return data
      } catch (error) {
        console.log(error)
      }
    }

    meetAPI.addEventListener("participantJoined", async function (object) {

      let token = await getAuthToken()
      if (isModerator) {
        if (localStorage.getItem('activeParticipant')) {
          activeParticipant = JSON.parse(localStorage.getItem('activeParticipant'))
          let participant = activeParticipant.participantData.filter(function (elem) {
            return elem.participantId == object.id;
          })
          if (participant.length == 0) {
            const newJoinee = {
              displayName: object.displayName,
              formattedDisplayName: object.formattedDisplayName,
              avatarURL: '',
              participantId: object.id,
              role: 'participant',
            }
            activeParticipant.participantData.push(newJoinee)
          }
          let selfParticipantDetail = activeParticipant.participantData.map((elem) => {
            if (elem.participantId == selfId.id) {
              elem.role = "moderator"
            }
          })
          meetSocket.send(JSON.stringify({
            'participantData': activeParticipant.participantData,
            'action': 'broadcast',
            'meetingId': cname
          }))
        }
      }
      let meetingObj = {
        current_attendees: meetAPI.getNumberOfParticipants()
      }
      if (isModerator && isWebinar) {
        meetingObj.id = currentMeeting.id
        let updateMeetingData = updateMeetingsFromMeetingId(token, meetingObj)
      } else if (isModerator && !isWebinar) {
        meetingObj.id = currentMeetingState.detail.id
        let updateMeetingData = updateMeetingsFromMeetingId(token, meetingObj)
      }
    });

    async function close_meeting() {
      let token = await getAuthToken()
      const my_id = selfId.id;
      activeParticipant = JSON.parse(localStorage.getItem("activeParticipant"))
      let participant_data = activeParticipant.participantData.filter((elem) => {
        return elem.participantId !== my_id;
      })

      let moderators = participant_data.filter((elem) => {
        return elem.role == 'moderator';
      })

      if (moderators.length == 0) {
        meetSocket.send(JSON.stringify({
          'participantData': participant_data,
          'action': 'dispose',
          'meetingId': cname
        }))
        let meetingObj = {
          status: 'C',
          current_attendees: 0
        }
        if (isWebinar) {
          meetingObj.id = currentMeeting.id
          let updateMeetingData = updateMeetingsFromMeetingId(token, meetingObj)
        } else {
          meetingObj.id = currentMeetingState.detail.id
          let updateMeetingData = updateMeetingsFromMeetingId(token, meetingObj)
        }
      }
      else if (moderators.length >= 1) {
        meetSocket.send(JSON.stringify({
          'participantData': participant_data,
          'action': 'broadcast',
          'meetingId': cname
        }))
      }
      localStorage.removeItem('activeParticipant')
      localStorage.removeItem('current_meeting_data')

      if (isAuthenticated) {
        document.location.href = '/';
      } else {
        document.location.href = endMeetingRedirectUrl;
      }
    }
    meetAPI.addListener('readyToClose', close_meeting);
    setJitsi(meetAPI);
  };

  useEffect(() => {
    async function fetchData() {
      let token = await getAuthToken();
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);

      const requestOptions = {
        method: 'GET',
        headers: myHeaders
      };
      if (isAuthenticated) {
        fetch(getAllScopesApi + "/" + apiUserDetail.oc_scope, requestOptions)
          .then(results => results.json())
          .then(data => {
            OcScopeData = data.Result;
          });

        fetch(getScope_featureList + "/" + apiUserDetail.oc_scope, requestOptions)
          .then(results => results.json())
          .then(data => {
            featureList = data.Result;
          });
      } else {
        fetch(getAllScopesApi + "/" + GuestScopeId, requestOptions)
          .then(results => results.json())
          .then(data => {
            OcScopeData = data.Result;
          });
        fetch(getScope_featureList + "/" + GuestScopeId, requestOptions)
          .then(results => results.json())
          .then(data => {
            featureList = data.Result;
          });
      }
    }
    // fetchData();
    initialiseJitsi();
    if (!(isWebinar && !isModerator)) {
      return () => jitsi.dispose();
    }
  }, []);

  var url = guestWebinarApp + cname;
  history.pushState(null, null, url);
  return (
    <div>
      {checkMeetingForSchedule ? (
        <Redirect to='/' />
      ) : (
          <div id={jitsiContainerId} style={{ height: "100vh", width: "100%" }} ></div>
        )}
    </div>
  );
};

export default StartConference;
