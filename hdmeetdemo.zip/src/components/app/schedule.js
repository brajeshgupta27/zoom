import React, { Component, Fragment } from 'react';
import './conf.css';
import TimezonePicker from 'react-bootstrap-timezone-picker';
import 'react-bootstrap-timezone-picker/dist/react-bootstrap-timezone-picker.min.css';
import { ReactMultiEmail, isEmail } from 'react-multi-email';
import { AvForm, AvField } from 'availity-reactstrap-validation';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Toast from 'react-bootstrap/Toast'
import 'react-multi-email/style.css';
import moment from 'moment';
import {onlytoken,schedule,Baseurl_app} from '../../constant/index'
toast.configure() 

class Schedule extends Component {
    constructor(props) {
        super(props);
        this.state = {
          meeting_id: '',
          scheduled_time: '',
          duration: '',
          timezone: '',
          host_name:'',
          host_email: '',
          emails: [],
          invitation_link: '',
          host_invitation_link: '',
        };
    
        // this.handleChange = this.handleChange.bind(this);
        this.myStartSubmitHandler = this.myStartSubmitHandler.bind(this);
        // this.myJoinSubmitHandler = this.myJoinSubmitHandler.bind(this);
        // this.guestLogin = this.guestLogin.bind(this);
        // this.ucUserLogin = this.ucUserLogin.bind(this);
      }

  updateFormValue = (event) => {
    this.setState({
      [event.target.name]: event.target.value
    });
  }
  
  
  updateUsers = (value) => {
    // this.setState({
    //   users_ids: value.length > 0 ? value.map(x => x.users_id) : []
    // });
    this.setState({
      emails: value
    });
  }

  updateTimezone = (value) => {
    this.setState({
      timezone: value
    });
  }

      myStartSubmitHandler = async (e) => {
        e.preventDefault();
    const start_time = new Date(this.state.scheduled_time).getTime();
    const end_time = Number(new Date(this.state.scheduled_time).getTime()) + Number(this.state.duration) * 60000;
    
    this.setState({
        invitation_link: encodeURI(Baseurl_app +"/app/" + btoa(this.state.meeting_id) + "/" + btoa(this.state.host_name) + "/" + btoa(start_time) + "/" + btoa(end_time) + "/" + btoa('false')),
        host_invitation_link: encodeURI(Baseurl_app +"/app/" + btoa(this.state.meeting_id) + "/" + btoa(this.state.host_name) + "/" + btoa(start_time) + "/" + btoa(end_time)+ "/" + btoa('true')),
    })
    let schedule_obj = {
        meeting_id: this.state.meeting_id,
        schedule_time : this.state.scheduled_time,
        duration: this.state.duration,
        timezone: this.state.timezone,
        host_email: this.state.host_email,
        host_name:this.state.host_name,
        loading: false,
        participants: this.state.emails,
        invitation_link: this.state.invitation_link,
        host_invitation_link: this.state.host_invitation_link,
    };
    
    try{
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
  
        let data = await fetch(onlytoken, {
          method: 'POST',
          headers: myHeaders,
          body: JSON.stringify({ username: 'hdmeet', password: '@#$asd123'}),
        }).then((response) => response.json())
            .then(data => {
              
              this.submitData(data, schedule_obj)
          });
      } catch(error){
        console.log(error)
      }  


      }

  submitData = async (token, schedule_obj) => {
      
    try{
    const myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    myHeaders.append('Authorization', 'Token ' + token.token);
    
    await fetch(schedule, {
      method: 'POST',
      headers: myHeaders,
        body: JSON.stringify(schedule_obj),
      })
      .then(res => {
       
          if(res.status == "201"){
            toast.dismiss();
            toast.success("Meeting has been scheduled, please check your email account.");
            
            this.resetForm();
            //schedule_obj={};
          }else{
            toast.dismiss();
            toast.error("Invalid form, Meeting was not scheduled, please try again.");
            
            //toast.dismiss();
          }
        
      }).catch(function(err) {
        
            toast.dismiss();
      });
    } catch(error){
        
        toast.dismiss();
        toast.error(error, {
            autoClose: false,
            hideProgressBar: true
        });
      } 
}

    resetForm = () => {

        document.location.href="/app?redirect=true";
        
        this.setState({
          meeting_id: '',
          scheduled_time: '',
          duration: '',
          timezone: '',
          host_name:'',
          host_email: '',
          emails: [],
          invitation_link: '',
          host_invitation_link: '',
        })
        
    }

    
    render() {

        
        return (
            <Fragment>
                <div class="main_sec">
                    <div class="container">
                        <div class="row inner_sec">
                            <div class="col-md-2">
                            </div>

                            <div class="col-md-8">
                                <div className="mb-5">
                                    <div class="schedule_text">
                                        <h4>Schedule a Conference</h4>
                                    </div>
                                    <div class="card_sec">
                                    <AvForm onValidSubmit={this.myStartSubmitHandler}>
                                            <AvField
                                                name="meeting_id"
                                                label="Meeting name"
                                                type="text"
                                                validate={{
                                                    required: { value: true, errorMessage: 'Please enter meeting id.'}
                                                }}
                                                placeholder="1234567879"
                                                value={this.state.meeting_id.trim().replace(" ", "")}
                                                onChange={this.updateFormValue}
                                                required
                                                // disabled={loading}
                                            />
                                            <div class="row pt-2">
                                                <div class="col-md-8">
                                            <AvField
                                                name="scheduled_time"
                                                label="Date & Time"
                                                type="datetime-local"
                                                validate={{
                                                    required: { value: true, errorMessage: 'Please enter scheduled date and time.'},
                                                    /**TODO: Validation on date */
                                                    // min: {value: moment().format('DD-MM-YYYYTHH:MM') , errorMessage: 'Selected date is beyond range.'}
                                                }
                                                }
                                                // min={new Date().toISOString()}
                                                placeholder=""
                                                value={this.state.scheduled_time}
                                                onChange={this.updateFormValue}
                                                // disabled={loading}
                                            />
                                            </div>
                                            <div class="col-md-4">
                                            
                                            <AvField
                                                name="duration"
                                                label="Duration"
                                                type="number"
                                                min="0"
                                                // max="180"
                                                validate={{
                                                    required: { value: true, errorMessage: 'Please enter meeting duration.'},
                                                    max: {value: 180},
                                                    min: {value: 0},
                                                    }
                                                    // {max: {value: 180}},
                                                    // {min: {value: 0}},
                                                }
                                                placeholder="In mins"
                                                value={this.state.duration.trim()}
                                                onChange={this.updateFormValue}
                                                // disabled={loading}
                                            />
                                            </div>
                                            </div>
                                            <div className="pt-2">
                                            <label>Time Zone</label>
                                            <TimezonePicker
                                            absolute      = {true}
                                            // defaultValue  = "Europe/Moscow"
                                            placeholder   = "Select timezone..."
                                            onChange      = {this.updateTimezone}
                                            />
                                            </div>
                                            <div className="pt-2">
                                            <AvField
                                                name="host_name"
                                                label="Host Name"
                                                className="pt-3"
                                                type="text"
                                                errorMessage="Please enter a valid name."
                                                validate={{
                                                    required: { value: true }
                                                }}
                                                value={this.state.host_name.trim()}
                                                onChange={this.updateFormValue}
                                                // disabled={loading}
                                            />
                                            </div>
                                            <div className="pt-2">
                                            <AvField
                                                name="host_email"
                                                label="Host Email"
                                                className="pt-3"
                                                type="text"
                                                errorMessage="Please enter a valid email address."
                                                validate={{
                                                    required: { value: true },
                                                    email: { value: true }
                                                }}
                                                value={this.state.host_email.trim()}
                                                onChange={this.updateFormValue}
                                                // disabled={loading}
                                            />
                                            </div>
                                            <div className="pt-2">
                                            <label htmlFor="emails">Email Addresses</label>
                                            <ReactMultiEmail
                                                name="emails"
                                                id="emails"
                                                className={`${this.state.emails.length === 0 && this.state.showErrors ? 'is-invalid': ''}`}
                                                emails={this.state.emails}
                                                onChange={this.updateUsers}
                                                validateEmail={email => {
                                                    return isEmail(email);
                                                }}
                                                getLabel={(email, index, removeEmail) => {
                                                    return <div data-tag key={index}>
                                                    {email}
                                                    <span data-tag-handle onClick={() => removeEmail(index)}>&times;</span>
                                                    </div>;
                                                }}
                                            />
                                            </div>
                                            <div class="text-center mt-5 pt-2">
                                            <input
                                                type="submit"
                                                // onClick={this.myStartSubmitHandler}
                                                className="btn conf_btn"
                                                value="Submit" />
                                            </div>
                                            </AvForm>
                                          
                                        
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="col-md-2">
                            </div>
                        </div>
                    </div>
                </div>
            </Fragment>
        );
    }
}

export default Schedule;