import React, { Component } from 'react';
import './conf.css';
import { withRouter } from 'react-router-dom';
import Schedule from './schedule';
import {onlytoken,gettoken, isModeratorApi} from '../../constant/index'
import AvForm from 'availity-reactstrap-validation/lib/AvForm';
import AvInput from 'availity-reactstrap-validation/lib/AvInput';
import AvField from 'availity-reactstrap-validation/lib/AvField';
import { toast } from 'react-toastify';

class Conf extends Component {
  constructor(props) {
    super(props);
    this.state = {
      cname: this.props.computedMatch.params.host_type ? (atob(this.props.computedMatch.params.host_type) === "true") ? ((this.props.computedMatch.params.meeting_id) ? atob(this.props.computedMatch.params.meeting_id) : 
              Math.floor(Math.random() * 900000000 + 100000000)) : '' : (Math.floor(Math.random() * 900000000 + 100000000)),
      value: '',
      dispname: this.props.computedMatch.params.host_type ? (atob(this.props.computedMatch.params.host_type) === "true") ? ((this.props.computedMatch.params.host_name) ? atob(this.props.computedMatch.params.host_name) : '') : '' : '',
      joincname: this.props.computedMatch.params.host_type ? ((atob(this.props.computedMatch.params.host_type) === "false") ? ((this.props.computedMatch.params.meeting_id) ? atob(this.props.computedMatch.params.meeting_id) : 
              Math.floor(Math.random() * 900000000 + 100000000)) : '') : '',
      joincpassword: '',
      joindispname: this.props.computedMatch.params.host_type ? ((atob(this.props.computedMatch.params.host_type)=== "false") ? ((this.props.computedMatch.params.host_name) ? atob(this.props.computedMatch.params.host_name) : '') : '') : '',
      invalid_time: false,
      schedule: false,
      start: true,
      isModerator:'',
      landing: false,
      s_audio: 'a_on',
      s_video: 'v_on',
      j_audio: 'a_on',
      j_video: 'v_on',
    };

    this.handleChange = this.handleChange.bind(this);
    this.myStartSubmitHandler = this.myStartSubmitHandler.bind(this);
    this.myJoinSubmitHandler = this.myJoinSubmitHandler.bind(this);
    this.guestLogin = this.guestLogin.bind(this);
    this.ucUserLogin = this.ucUserLogin.bind(this);
  }

  componentDidMount(){
    const query = new URLSearchParams(this.props.location.search);
    const redirect = query.get('redirect')
    if(redirect == "true"){
      this.setState({
        schedule: true,
        start: false,
        landing: false
      });
      history.pushState(null, null, "/app");
      toast.dismiss();
      toast.success("Meeting has been scheduled, please check your email account.");
           

    }

    if((this.props.computedMatch.params.start) && (this.props.computedMatch.params.end)){
      const current_time = new Date().getTime();
      if(current_time < atob(this.props.computedMatch.params.start) || atob(this.props.computedMatch.params.end) < current_time){
        this.setState({
          invalid_time: true
        });
        alert("Meeting cannot be started");
      }
  }
}

  getAuthToken = async (participant) => {

    try{
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');

      let data = await fetch(onlytoken, {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify({ username: 'hdmeet', password: '@#$asd123'}),
      }).then((response) => response.json())
          .then(data => {            
            this.getJwtToken(data, participant)
        });
    } catch(error){
      console.log(error)
    }

}

  getModerator = async (token) => {
    try{
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Token ' + token.token);
     
      await fetch(isModeratorApi, { 
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify({ conference_name: this.state.joincname, password: this.state.joincpassword }),
      }).then((response) => response.json())
      .then(data2 => {
        
        if(data2.moderator === true){
        this.setState({
          isModerator: true
        })
      } else {
        this.setState({
          isModerator: false
        })
      }
    });
    } catch(error){
      console.log(error)
    }
  }

  getJwtToken = async (token, participant) => {
    let room_name = this.state.cname
    let moderator = true
    if(participant === "join" && this.state.isModerator !== true){
      room_name = this.state.joincname
      moderator = false
     
    }
    if(participant === "join"){
      room_name = this.state.joincname
    }

    try{
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      
      myHeaders.append('Authorization', 'Bearer' + token.access);

      await fetch(gettoken, { 
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify({ room: room_name, is_mod: moderator}),
      }).then((response) => response.json())
      .then(data2 => {
        
        this.redirectConf(data2, participant);
    });
    } catch(error){
      console.log(error)
    }
  }

  redirectConf = (token, participant) => {
    if(participant === 'start'){
    this.props.history.push('/startconference/' + this.state.cname + '/' + this.state.dispname+ '/' + this.state.s_audio+ '/' + this.state.s_video +  '/' + token.jwt_token);
    }
    else if(participant === 'join'){
      this.props.history.push('/startconference/' + this.state.joincname + '/' + this.state.joindispname + '/' + this.state.j_audio+ '/' + this.state.j_video + '/' + token.jwt_token);
    }
  }




  handleChange(event) {
    if(event.target.name === "s_audio"){
      let audio_mute = "a_on"
      if(event.target.checked){
        audio_mute = "a_off"     
      }  
      this.setState({
        [event.target.name]: audio_mute
      });  

    }else if(event.target.name === "s_video"){
      let video_mute = "v_on"
      if(event.target.checked){
        video_mute = "v_off"     
      }  
      this.setState({
        [event.target.name]: video_mute
      });  

    }else if(event.target.name === "j_audio"){
      let audio_mute = "a_on"
      if(event.target.checked){
        audio_mute = "a_off"     
      }  
      this.setState({
        [event.target.name]: audio_mute
      });  

    }else if(event.target.name === "j_video"){
      let video_mute = "v_on"
      if(event.target.checked){
        video_mute = "v_off"     
      }  
      this.setState({
        [event.target.name]: video_mute
      });  

    }else{
      const value = event.target.value;
      this.setState({
        [event.target.name]: value
      });
    }    
  }

  myStartSubmitHandler = async () => {
    let token  = await this.getAuthToken('start');
  }

  myJoinSubmitHandler = async () => {
    let token  = await this.getAuthToken('join');
  }

  scheduleMeeting = () => {
   
    this.setState({
      schedule: true,
      start: false,
      landing: false
    });
  }

  guestLogin = () => {
    
    this.setState({
      schedule: false,
      start: true,
      landing: false,
    });
  }

  ucUserLogin = () => {
    
    this.props.history.push('/login/');

  }

  render() {
    return (
      <div className="wrapper confe">
        <header>
          <nav className="navbar navbar-expand-sm">
            <a className="navbar-brand" href="/"><img src="/telware.png" alt="Telware Logo" height="50" /></a>
          </nav>
        </header>
        {this.state.start && <section className="main_sec">
          <div className="container">

            <div className="text_sec">
              <h3>Collaborate across multiple devices.</h3>
              <h3>Build better customer relationships whether working from home or the office.</h3>
            </div>

            <div className="row inner_sec">
              <div className="col-md-4">
                <h4>Start Conference</h4>
                <div className="card_sec">
                  <AvForm onValidSubmit = {this.myStartSubmitHandler}>
                    <div className="form-group">
                      <AvField
                        className="form-control"
                        placeholder="123456789"
                        type="text"
                        name="cname"
                        validate={{
                          required: { value: true, errorMessage: 'Enter a conference name.' }
                        }}
                        value={this.state.cname}
                        readonly />
                    </div>
                    <div className="form-group">
                      <AvField
                        type="text"
                        name="dispname"
                        validate={{
                          required: { value: true, errorMessage: 'Enter a display name.' },
                          pattern: { value : '/^[a-zA-Z0-9 ,-]+$/', errorMessage: 'No Special characters allowed.'}
                        }}
                        value={this.state.dispname}
                        onChange={this.handleChange}
                        className="form-control"
                        placeholder="Your Name" />
                    </div>
                    <div className=" form-group">
                      <label className="mr-3">Mute Audio</label>
                      <label className="switch">
                        <input id="muteAudioConf" name="s_audio" onChange={this.handleChange}  type="checkbox"  />
                        <span className="slider round"></span>
                      </label>
                    </div>
                    <div className=" form-group">
                    <label className="mr-3">Mute Video</label>
                      <label className="switch">
                      <input id="muteVedioConf" name="s_video" onChange={this.handleChange} type="checkbox" />
                        <span className="slider round"></span>
                      </label>
                    </div>
                    <div className="text-center mt-5 pt-4">
                      <input
                        type="submit"
                        className="btn conf_btn"
                        name="start_conf"
                        value="Start" 
                        disabled={this.state.invalid_time ||
                          (this.props.computedMatch.params.host_type ? 
                          (atob(this.props.computedMatch.params.host_type) === "false") : false)}/>
                    </div>
                  </AvForm>
                </div>
              </div>
              <div className="col-md-4">
                <div className="or_text"><span>OR</span></div>
              </div>
              <div className="col-md-4">
                <h4>Join Conference</h4>
                <div className="card_sec">
                  <AvForm onValidSubmit = {this.myJoinSubmitHandler}>
                    <div className="form-group">
                      <AvField
                        type="text"
                        name="joincname"
                        validate={{
                          required: { value: true, errorMessage: 'Enter a conference name.' }
                        }}
                        value={this.state.joincname}
                        onChange={this.handleChange}
                        placeholder="Conference Name"
                        required
                        className="form-control" />
                    </div>
                    <div className="form-group">
                      <AvField
                        type="password"
                        name="joincpassword"
                        value={this.state.joincpassword}
                        onChange={this.handleChange}
                        className="form-control"
                        placeholder="Conference Password" />
                    </div>
                    <div className="form-group">
                      <AvField
                        type="text"
                        name="joindispname"
                        validate={{
                          required: { value: true, errorMessage: 'Enter a display name.' },
                          pattern: { value : '/^[a-zA-Z0-9 ,-]+$/', errorMessage: 'No Special characters allowed.'}
                        }}
                        value={this.state.joindispname}
                        onChange={this.handleChange}
                        placeholder="Your Name"
                        className="form-control" />
                    </div>

                    <div className=" form-group">
                      <label className="mr-3">Mute Audio</label>
                      <label className="switch">
                        <input name="j_audio" onChange={this.handleChange}  type="checkbox"  />
                        <span className="slider round"></span>
                      </label>
                    </div>
                    <div className=" form-group">
                      <label className="mr-3">Mute Video</label>
                      <label className="switch">
                        <input name="j_video" onChange={this.handleChange} type="checkbox" />
                        <span className="slider round"></span>
                      </label>
                    </div>
                    
                    <div className="text-center">
                      <input
                        type="submit"
                        value="Join"
                        className="btn conf_btn"
                        name="joinconf_submit"
                        disabled={this.state.invalid_time || 
                          (this.props.computedMatch.params.host_type ? 
                          (atob(this.props.computedMatch.params.host_type) === "true") : false)} />
                    </div>
                  </AvForm>
                </div>
              </div>
            </div>
            <div className="text-center text-primary bottom-text my-3" onClick={this.scheduleMeeting}>Schedule a conference</div>
          </div>
        </section>}
        {this.state.schedule && <Schedule />}
      </div>
    );
  }
}

export default withRouter(Conf);