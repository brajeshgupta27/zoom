import React, { Component } from 'react';
import {
  Redirect,
  Route,
} from "react-router-dom";

class PrivateRoute extends Component {

    constructor(props) {
        super(props);
        this.state = {
          isAuthenticated: localStorage.getItem('isAuthenticated') ? localStorage.getItem('isAuthenticated') : false,
        };
      }

    render() {
        const Component = this.props.component;
        const {...rest} = this.props
        return (
            <Route render={props =>
                !this.state.isAuthenticated ? (
                  <Redirect to='/'/>
                ) : (
                  <Component {...props} {...rest}/>
                )
              }
              />
        );
    }
}

export default PrivateRoute;