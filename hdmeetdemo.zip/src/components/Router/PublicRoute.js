import React, { Component } from 'react';
import {
  Redirect,
  Route,
} from "react-router-dom";

class PublicRoute extends Component {

    constructor(props) {
        super(props);
        this.state = {
          isAuth: true,
        };
      }
    

    componentWillMount() {
        let token = sessionStorage.getItem('token');
            if(token){                
                let tokenExpiration = Number(sessionStorage.getItem('ExpireTime')) + 
                                        Number(sessionStorage.getItem('CurrentDate'));
                let dateNow = new Date();
                if(tokenExpiration < dateNow.getTime()/1000){
                    this.setState({
                        isAuth: false
                    })
                }else{
                    this.setState({
                        isAuth: true
                    });
                }
            } else {
                this.setState({
                    isAuth: false
                })
            }
      }

    render() {
        const Component = this.props.component;
        const {...rest} = this.props;
        return (
            <Route render={props =>
                !this.state.isAuth ? (
                  <Component {...props} {...rest} />
                ) : (
                  <Redirect to='/home'/>
                )
              }
              />
        );
    }
}

export default PublicRoute;