// import 'bootstrap/dist/css/bootstrap.css';
// import React from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';

// import ReactDOM from 'react-dom';
// import App from './App';
// import "@fortawesome/fontawesome-free/css/all.min.css";
// import './index.css';
// import swDev from './swDev'

// ReactDOM.render(
//   <App />,
//   document.getElementById('root')
// );

// swDev();



import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
ReactDOM.render(
 <React.StrictMode>
   <App />
 </React.StrictMode>,
 document.getElementById('root')
);
serviceWorker.register();