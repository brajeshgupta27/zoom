import React, { Component } from 'react';
import Background from '../assets/images/background.png';
import './newDesign.css';
import { AvForm, AvField } from 'availity-reactstrap-validation';
import { Link } from 'react-router-dom'
import Header from '../no-auth/header';
import {
    ONE_CLOUD,
    nsApiUrl,
    ocSuperUser,
    ocSuperPassword,
    getOrCreateOcUser,
    getRecentLoggedInUser,
    resetOneCloudPasswordUrl,
    getRecordingUrl,
    userToken
} from '../constant/index';
import { MESSAGES } from '../constant/messages';
import { getAuthToken } from '../helpers/auth-header';

class LoginPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            is_loginForm_visiable: true,
            is_passwordForm_visiable: false,
            is_multiUser_visiable: false,
            one_cloud_access_token: '',
            user_email: '',
            user_password: '',
            access_token: '',
            users_list: [],
            one_cloud_user_name: '',
            error_msg: MESSAGES.inCorrectUser,
            passwordError_msg: MESSAGES.inCorrectPassword,
            isAuthenticated: localStorage.getItem('isAuthenticated') ? localStorage.getItem('isAuthenticated') : false,
            userToken: localStorage.getItem('userToken') ? JSON.parse(localStorage.getItem('userToken')) : "",
            showError: false,
            recentLoggedInUserData: {},
            meetingUrlLink: localStorage.getItem('meetingUrlLink') ? localStorage.getItem('meetingUrlLink') : '',
            loginWithEmail: true,
            
        }
        this.loginHandler = this.loginHandler.bind(this);
        this.authLoginHandler = this.authLoginHandler.bind(this);
        this.showPasswordForm_visiable = this.showPasswordForm_visiable.bind(this);
        this.getOneCloudOauth = this.getOneCloudOauth.bind(this);
        this.handleChangeLoginType = this.handleChangeLoginType.bind(this);
    }

    componentWillMount = () => {
        let path = `/user/dashboard`;
        { localStorage.getItem('isAuthenticated') ? this.props.history.push(path) : null }

    }

    loginHandler = async (e) => {
        //e.preventDefault();
        this.setState({
            showError: false,
        })
        if(this.state.loginWithEmail){
            let token = await getAuthToken();
            const authData = await this.getOneCloudOauth(ocSuperUser, ocSuperPassword)
            this.setState({
                access_token: authData.access_token
            })
            const usersData = await this.getOneCloudUsers()
            const recentUser = await this.getRecentLoggedInUser(token);
            this.setState({
                recentLoggedInUserData: recentUser
            })
        }else{
            this.setState({
                is_passwordForm_visiable: true,
                is_loginForm_visiable: false,
                is_multiUser_visiable: false,
                showError: false,
            })
        }
    }

    handleChangeLoginType(event) {
        if(event.target.checked){
            this.setState({
                loginWithEmail: false,
                one_cloud_user_name: ''
            });
        }else{
            this.setState({
                loginWithEmail: true,
                user_email: ''
            });
        }
    }

    getRecentLoggedInUser = async (token) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(getRecentLoggedInUser + this.state.user_email, {
                method: 'GET',
                headers: myHeaders
            })
            const recentLoggedInUserData = await result.json()
            return recentLoggedInUserData
        } catch (error) {
            console.log(error)
        }
    }

    getOneCloudUsers = async () => {
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        myHeaders.append('Authorization', 'Bearer ' + this.state.access_token);
        // myHeaders.append('Access-Control-Allow-Headers', '*');

        let fields = {
            format: ONE_CLOUD.format,
            email: this.state.user_email
        }
        let result = await fetch(nsApiUrl + "/?object=subscriber&action=read", {
            method: 'POST',
            headers: myHeaders,
            body: JSON.stringify(fields),
        })
        const data = await result.json()
        this.setState({
            users_list: data,
        })

        if (this.state.users_list.length == 0) {
            this.setState({
                is_loginForm_visiable: true,
                is_multiUser_visiable: false,
                is_passwordForm_visiable: false,
                showError: true,
            })
        } else if (this.state.users_list.length == 1) {
            this.setState({
                one_cloud_user_name: this.state.users_list[0].subscriber_login,
                is_passwordForm_visiable: true,
                is_loginForm_visiable: false,
                is_multiUser_visiable: false,
                showError: false,
            })
        } else {
            this.setState({
                is_multiUser_visiable: true,
                is_passwordForm_visiable: false,
                is_loginForm_visiable: false,
                showError: false,
            })
        }
    }

    getOneCloudOauth = async (onecloud_username, onecloud_password) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            // myHeaders.append('Access-Control-Allow-Headers', '*');

            let fields = {
                format: ONE_CLOUD.format,
                grant_type: ONE_CLOUD.grant_type,
                client_id: ONE_CLOUD.client_id,
                client_secret: ONE_CLOUD.client_secret,
                username: onecloud_username,
                password: onecloud_password,
            }
            let result = await fetch(nsApiUrl + "/oauth2/token", {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify(fields),
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log("ERROR", error)
        }
    }

    authLoginHandler = async (e) => {
        //e.preventDefault();
        let token = await getAuthToken();
        try {
            const authData = await this.getOneCloudOauth(this.state.one_cloud_user_name, this.state.user_password)
            this.setState({
                isAuthenticated: true,
                showError: false
            })
            let apiUserDetail = await this.getOneCloudUserDetail(token, authData)
            let userToken = await this.createUpdateAuthToken(token, authData) // Use to get and save userToken for meeting url validation
            localStorage.setItem('userToken', JSON.stringify(userToken));
            localStorage.setItem('isAuthenticated', true);
            let dateNow = new Date();
            localStorage.setItem('checkLastLogin', dateNow.getTime());
            localStorage.setItem('authUserData', JSON.stringify(authData));
            localStorage.setItem("apiUserDetail", JSON.stringify(apiUserDetail));
            let meetingUrlLink = apiUserDetail.current_meeting_id
            localStorage.setItem("meetingUrlLink", meetingUrlLink);
            this.props.history.push('/user/dashboard');
        } catch (error) {
            this.setState({
                isAuthenticated: false,
                showError: true
            })
            localStorage.clear()
        }
    }

    getMeetingUrlLink = async (apiUserDetail) => {
        let domainName = apiUserDetail.domain
        let userName = apiUserDetail.user
        let meetingUrlLink = domainName + "-" + userName
        localStorage.setItem("meetingUrlLink", meetingUrlLink)
        this.setState({
            meetingUrlLink: meetingUrlLink
        })
        return meetingUrlLink
    }

    showPasswordForm_visiable = () => {
        this.setState({
            is_passwordForm_visiable: true,
            is_multiUser_visiable: false,
            is_loginForm_visiable: false,
        })
    }

    createUpdateAuthToken = async (token, authData) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(userToken, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify({
                    username: authData.username
                }),
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log(error)
        }
    }

    getOneCloudUserDetail = async (token, authData) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(getOrCreateOcUser, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify({
                    username: authData.username,
                    user: authData.user,
                    email: authData.user_email,
                    scope: authData.scope,
                    uid: authData.uid,
                    domain: authData.domain,
                    display_name: authData.displayName,
                    meeting_ids: [authData.domain + "-" + authData.user],
                    current_meeting_id: authData.domain + "-" + authData.user,
                    territory: authData.territory,
                }),
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log(error)
        }
    }

    updateFormValue = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        });
    }

    getSubscriber = (e) => {
        this.setState({
            one_cloud_user_name: e.target.value
        })
    }

    backToLogin() {
        this.setState({
            is_passwordForm_visiable: false,
            is_multiUser_visiable: false,
            is_loginForm_visiable: true,
            showError: false,
            loginWithEmail: true,
            users_list: []
        });
    }
    render() {
        return (
            <div className="loginpage"  >
                <div className="mainContainer">
                    <Header />
                   
                    <div className="dbMeetingContainer scheduleContainer">
                        <div id="login">
                            <div className="container">
                                <div id="login-row" className="row justify-content-center align-items-center">
                                    <div id="login-box" className="col-md-12">
                                        {this.state.is_loginForm_visiable ?
                                            <AvForm id="login-form" className="form" action="" method="post" onValidSubmit={this.loginHandler}>
                                                <div className="form-group">
                                                    <div className="toggle_User_Email">
                                                        <div className="AudioButton">
                                                            <label className="mr-1">{MESSAGES.email}</label>
                                                            <label className="switch">
                                                                <input
                                                                    type="checkbox"
                                                                    name="userOrEmail"
                                                                    defaultChecked={false}
                                                                    onChange={this.handleChangeLoginType}
                                                                />
                                                                <span className="slider round"></span>
                                                            </label>
                                                            <label className="ml-1">{MESSAGES.oneCloudUser}</label>
                                                        </div>
                                                    </div>

                                                    {this.state.loginWithEmail ?
                                                    <AvField
                                                        name="user_email"
                                                        label="Email"
                                                        className="form-control"
                                                        type="text"
                                                        errorMessage="Please enter a valid email address."
                                                        validate={{
                                                            required: { value: true },
                                                            email: { value: true }
                                                        }}
                                                        value={this.state.user_email.trim()}
                                                        onChange={this.updateFormValue}
                                                    />
                                                    :
                                                    <AvField
                                                        name="one_cloud_user_name"
                                                        label="OneCloud User"
                                                        className="form-control"
                                                        type="text"
                                                        errorMessage="Please enter a valid User Name."
                                                        validate={{
                                                            required: { value: true, errorMessage: 'No space & special characters allowed.' },
                                                            pattern: { value: '/^[a-zA-Z0-9,-_]+$/', errorMessage: 'No space & special characters allowed.' }
                                                        }}
                                                        value={this.state.one_cloud_user_name.trim()}
                                                        onChange={this.updateFormValue}
                                                    />
                                                }
                                                </div>
                                                {this.state.showError ? <label style={{ color: 'red' }}> {this.state.error_msg}</label> : null}
                                                <div className="form-group text-center">
                                                    <input type="submit" name="submit" className="login-btn" value="NEXT" />
                                                </div>

                                                <div id="register-link" className="text-center">
                                                    <Link to="/" className="go-back">{MESSAGES.goback}</Link><br/>
                                                    <Link to="/user/forgotpassword" className="go-back" >{MESSAGES.forgotYourPassword}</Link>
                                                </div>
                                            </AvForm>
                                            : null
                                        }

                                        {
                                            this.state.is_passwordForm_visiable ?
                                                <AvForm id="login-form" className="form" action="" method="post" onValidSubmit={this.authLoginHandler}>
                                                    <div className="form-group">
                                                        <div className="form-group">
                                                            <AvField
                                                                name="user_password"
                                                                label="Password"
                                                                className="form-control"
                                                                type="password"
                                                                autoComplete="true"
                                                                errorMessage="Please enter a valid password."
                                                                validate={{
                                                                    required: { value: true }
                                                                }}
                                                                value={this.state.user_password.trim()}
                                                                onChange={this.updateFormValue}
                                                            />
                                                        </div>
                                                        {this.state.showError ? <label style={{ color: 'red' }}> {this.state.passwordError_msg}</label> : null}
                                                    </div>
                                                    <div className="form-group text-center" >
                                                        <input type="submit" name="submit" className="login-btn" value="LOGIN" />
                                                    </div>

                                                    <div id="register-link" className="text-center">
                                                        <a href="#" className="go-back" onClick={() => this.backToLogin()} >{MESSAGES.backToLogin}</a><br></br>
                                                        <Link to="/user/forgotpassword" className="go-back" >{MESSAGES.forgotYourPassword}</Link>
                                                    </div>
                                                </AvForm>
                                                : null
                                        }
                                        {
                                            this.state.is_multiUser_visiable ?
                                                <AvForm id="" className="form" action="" method="post" onValidSubmit={this.showPasswordForm_visiable}>
                                                    <div className="user-accounts">
                                                        <p className="user-accounts-title">{MESSAGES.selectAnAccountToLogInWith}</p>
                                                        {Object.keys(this.state.recentLoggedInUserData).length == 0 ?
                                                            null
                                                            : <div className="recent-account">
                                                                <p className="user-accounts-titlepara">{MESSAGES.recentlyUsedAccount}</p>
                                                                <ul>
                                                                    <li className="account-listItem">
                                                                        <div className="form-check">
                                                                            <label className="form-check-label">
                                                                                <input type="radio" className="form-check-input" name="optradio" value={this.state.recentLoggedInUserData.user_name} onChange={this.getSubscriber} />{this.state.recentLoggedInUserData.display_name}
                                                                            </label><br />
                                                                            <span>{this.state.recentLoggedInUserData.user_name}</span><br />
                                                                            <span>{this.state.recentLoggedInUserData.domain}</span>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>}

                                                        <div className="account-list">
                                                            <p className="user-accounts-titlepara">{MESSAGES.allAccounts}</p>
                                                            <ul>
                                                                {
                                                                    // this.state.users_list.length > 0 ?
                                                                    this.state.users_list.map((keyName, i) => (
                                                                        <li className="account-listItem" key={i}>
                                                                            <div className="form-check">
                                                                                <label className="form-check-label">
                                                                                    <input type="radio" className="form-check-input" name="optradio" value={keyName.subscriber_login} onChange={this.getSubscriber} />{keyName.first_name + " " + keyName.last_name}
                                                                                </label><br />
                                                                                <span>{keyName.subscriber_login}</span><br />
                                                                                <span>{keyName.domain}</span>
                                                                            </div>
                                                                        </li>
                                                                    ))
                                                                }
                                                            </ul>
                                                        </div>

                                                        <div className="form-group text-center">
                                                            <input type="submit" name="submit" className="login-btn" value="LOGIN" />
                                                        </div>
                                                        <div id="register-link" className="text-center">
                                                            <p className="go-back m-0">{MESSAGES.connectDifferentAccount}</p>
                                                            <a href="#" className="go-back" onClick={() => this.backToLogin()} >{MESSAGES.backToLogin}</a>
                                                        </div>
                                                    </div>
                                                </AvForm>
                                                : null
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default LoginPage;