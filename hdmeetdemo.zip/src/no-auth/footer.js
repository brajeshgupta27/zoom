import React, { Component } from 'react';
import './newDesign.css';
import {
    versionTag,
    termsOfService,
    privacyPolicy,
} from '../constant/index'
import { MESSAGES } from '../constant/messages';

class Footer extends Component {
    render() {
        return (
            <div className="footer">
                <p className="copyRight">{MESSAGES.versionType}{versionTag}{MESSAGES.copyright}
                <span className="spacer">|</span>
                <a href={termsOfService} className="footerLinks" target="_blank">Terms of Service</a>
                <span className="spacer">|</span>
                <a href={privacyPolicy} className="footerLinks" target="_blank">Privacy Policy</a>                
                </p>
            </div>
        );
    }
}

export default Footer;
