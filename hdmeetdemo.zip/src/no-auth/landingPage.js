import React, { Component } from 'react';
import Background from '../assets/images/background.png';
import StartMeetingIcon from '../assets/images/StartMeetingIcon.png';
import ScheduleIcon from '../assets/images/ScheduleIcon.png';
import JoinIcon from '../assets/images/JoinIcon.svg';
import CopyIcon from '../assets/images/copyIcon.png';
import EmailIcon from '../assets/images/emailIcon.png';
import AppleStoreIcon from '../assets/images/App-Store.png';
import GoogleStoreIcon from '../assets/images/Google-Playstore.png';
import InputAdornment from '@material-ui/core/InputAdornment';
import { MDBInput, MDBIcon } from "mdbreact";
import Input from '@material-ui/core/Input';
import './newDesign.css';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { AvForm, AvField } from 'availity-reactstrap-validation';
import ScheduleMeet from './ScheduleMeeting';
import Header from '../no-auth/header';
import Logo from '../assets/images/Logo_HDMeet.png';
import { Link, withRouter } from 'react-router-dom';
import WatchModal from '../no-auth/webinarSchedule/WatchModal';
import TimeZoneModal from "../no-auth/webinarSchedule/TimeZoneModal";
import moment from 'moment';
import Loder from './loader';

import { toast } from 'react-toastify';
import Footer from "./footer"
import {
    Card,
    Table,
    Container,
    Row,
    Col,
    Modal,
    Button,
    Dropdown,
} from "react-bootstrap";
import jstz from 'jstz';
import {
    gettoken,
    Baseurl_invite,
    Baseurl_self,
    appleStoreUrl,
    googleStoreUrl,
    backendMeetingApi,
    OneCloudGuestUserID,
    // GuestMaxUserLimit,
    // OneCloudMaxUserLimit,
    Baseurl_app,
    getFeatureFromMeetingIdApi,
    onlytoken,
    schedule,
    userName,
    password,


} from '../constant/index';

import { getAuthToken } from '../helpers/auth-header';
import { MESSAGES } from '../constant/messages';
import meetingReg from './meetingRegComponent/meetingReg';
import axios from 'axios';

class LandingPage extends Component {
    constructor(props) {

        super(props);
        this.state = {
            cname: this.props.computedMatch.params.host_type ? (atob(this.props.computedMatch.params.host_type) === "true") ? ((this.props.computedMatch.params.meeting_id) ? atob(this.props.computedMatch.params.meeting_id) :
                Math.floor(Math.random() * 900000000 + 100000000)) : '' : (Math.floor(Math.random() * 900000000 + 100000000)),
            // value: '', NOTE:: will be used later
            // dispname: 'name', NOTE:: will be used later
            joincname: this.props.computedMatch.params.meeting_id ? this.props.computedMatch.params.meeting_id : "",
            // joincpassword: '', NOTE:: will be used later
            // joindispname: this.props.computedMatch.params.host_type ? ((atob(this.props.computedMatch.params.host_type) === "false") ? ((this.props.computedMatch.params.host_name) ? atob(this.props.computedMatch.params.host_name) : '') : '') : '',

            s_audio: this.getCookie('s_audio') !== null ? this.getCookie('s_audio') : 'a_on',
            s_video: this.getCookie('s_video') !== null ? this.getCookie('s_video') : 'v_on',
            isAudioChecked: true,
            isVideoChecked: true,
            invalid_time: false,
            schedule: false,
            start: true,
            isModerator: false,
            landing: false,
            meetingId: '',
            joinMeetingPopup: this.props.computedMatch.params.meeting_id ? true : false,
            scheduleMeetingPopup: false,
            invitation_url: '',
            copied: false,
            isAuthenticated: localStorage.getItem('isAuthenticated') ? localStorage.getItem('isAuthenticated') : false,
            current_meeting_data: {},
            meetingUrl: '',
            openModalShowReg: false,
            showWatchModal: false,
            openClock: false,
            inputType: true,
            time: new Date().toLocaleString('en-US', {
                hour: '2-digit',
                minute: '2-digit', hour12: true
            }).toLowerCase(),
            showModal: false,
            selectedTimezone: (Intl.DateTimeFormat().resolvedOptions().timeZone + moment.tz(Intl.DateTimeFormat().resolvedOptions().timeZone).format(" z Z") + "GMT"),
            selectedDisplayTimezone: (Intl.DateTimeFormat().resolvedOptions().timeZone + moment.tz(Intl.DateTimeFormat().resolvedOptions().timeZone).format(" z Z") + "GMT").split(" ")[1],
            attCurrentValue: '',
            attendeesError: '',
            attendees: [],
            title: '',
            description: '',
            date: '',

            duration: '15',
            zone: Intl.DateTimeFormat().resolvedOptions().timeZone + moment.tz(Intl.DateTimeFormat().resolvedOptions().timeZone).format(" z Z") + "GMT".split(" ")[1],
            password: '',
            reqPassCode: '',
            modrator: [],
            requirePass: false,
            meeting_id: Math.floor(Math.random() * 900000000 + 100000000),
            titleError: '',
            attendeesError: '',
            zoneError: '',
            durationError: '',
            hostEmailError: '',
            loaderStart:'false',


        };

        this.handleChange = this.handleChange.bind(this);
        this.myStartSubmitHandler = this.myStartSubmitHandler.bind(this);
        this.myJoinSubmitHandler = this.myJoinSubmitHandler.bind(this);
        this.invitation_urlWithJWT = this.invitation_urlWithJWT.bind(this);
        this.getCookie = this.getCookie.bind(this);
    }
    openWatch = () => {

        this.setState({ openClock: !this.state.openClock })

        this.setState({ showWatchModal: !this.state.showWatchModal }, () => {

        })
    }
    setTime = (e) => {

        this.setState({ time: e.target.value })
    }

    getTimePickerDate = () => {
        this.setState({ openClock: !this.state.openClock })
        this.setState({ inputType: false })

        this.setState({ showWatchModal: !this.state.showWatchModal })
    }
    takeTime = (timeVal) => {

        this.setState({ time: timeVal })

    }
    closeTimeZoneModal = (val) => {
        this.setState({ showModal: false })
        this.setState({ selectedTimezone: val })
        // setSelectedTimezone(val)
        var abbr_tz = val.split(" ")[1]
        this.setState({ selectedDisplayTimezone: abbr_tz })

        //setSelectedDisplayTimezone(abbr_tz)

    }
    handleTimeZoneModal = () => {
        this.setState({ showModal: true })


    }

    getAttendees = (e) => {
        var emailRegex = /\S+@\S+\.\S+/;
        let attenendes = e.target.value;
        this.setState({ attCurrentValue: attenendes })
        // setAttCurrentValue(attenendes)

        if (emailRegex.test(attenendes)) {
            this.setState({ attendeesError: '' })
            // setAttendeesError('');

        } else {
            this.setState({ attendeesError: 'Please enter a valid email!' })
            //setAttendeesError('Please enter a valid email!');
        }

    }
    handleTestAttende = (e) => {
        var emailRegex = /\S+@\S+\.\S+/;
        if (!emailRegex.test(this.state.attCurrentValue)) {
            this.setState({ attendeesError: 'Please enter a valid email!' })
            // setAttendeesError('Please enter a valid email!');
        }
        if (emailRegex.test(this.state.attCurrentValue)) {
            if (e.which == 13 || e.which == 44) {
                this.setState({ attendees: [...this.state.attendees, this.state.attCurrentValue] })
                // setAttendees([...attendees, attCurrentValue])
                this.setState({ attCurrentValue: '' })
                // setAttCurrentValue("")
            }
        }
    }


    getTitle = (e) => {
        this.setState({ title: e.target.value })

    }
    getDesc = (e) => {
        this.setState({ description: e.target.value })

    }
    getDate = (e) => {
        this.setState({ date: e.target.value })

    }
    getTime = (e) => {
        this.setState({ time: e.target.value })


    }
    getZone = (e) => {
        this.setState({ zone: e.target.value })

    }
    getPssword = (e) => {
        this.setState({ password: e.target.value })
        password
    }
    getDuration = (e) => {
        this.setState({ duration: e.target.value })

    }
    getReqPass = () => {
        this.setState({ requirePass: !this.state.requirePass })
    }
    getHostEmail = (e) => {
        this.setState({ modrator: e.target.value })

    }

    scheduleSubmit = async () => {

        var dt = moment(this.state.time, ["h:mm A"]).format("HH:mm");

        var datesRemovedZone = `${this.state.date}T${dt}`


        var BrtimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone + moment.tz(Intl.DateTimeFormat().resolvedOptions().timeZone).format(" z Z") + "GMT"
        var abbr_default_tz = BrtimeZone.split(" ")[1]
        const invitation_link = encodeURI(Baseurl_invite + "/" + this.state.meeting_id);
        const host_invitation_link = encodeURI(Baseurl_self + "/" + this.state.meeting_id);
        let schedule_obj = {
            "meeting_id": this.state.meeting_id,
            "start_time": datesRemovedZone,
            "end_time": "",
            "timezone": BrtimeZone,
            "host_email": this.state.modrator,
            // "moderators": moderators,
            "duration": this.state.duration,
            "host_name": "",
            "participants": this.state.attendees,
            "invitation_link": invitation_link,
            "host_invitation_link": host_invitation_link,
            "subject": this.state.title,
            "oc_user": localStorage.getItem("isAuthenticated") ? this.state.apiUserDetail.id : OneCloudGuestUserID,
            "meeting_password": this.state.getPssword,

            "require_passcode": this.state.requirePass,
        };


        let error = false;
        if (this.state.title == "") {
            error = true

            this.setState({ titleError: 'Please Enter Title' })
           
        }
        if (this.state.zone == "") {
            this.setState({ zoneError: 'Please Select Zone' })
        }
        if (this.state.modrator.length == 0) {
            error = true
            this.setState({ attendeesError: 'Please Enter Attendees' })

            // hostEmailError:''
        }
        if (this.state.attendees.length == 0) {
            this.setState({ hostEmailError: 'Please Enter Host Email' })
            error = true
        }
        if (error == false) {
         
            this.setState({loaderStart:true})
            const token = await getAuthToken();
            axios.post(schedule, schedule_obj, {
                headers: {
                    'Authorization': `Bearer ${token.access}`
                }
            })

                .then((response) => {

                    this.setState({loaderStart:false})

                    toast.dismiss();
                    toast.success("Your conference scheduled successfully", {
                        position: "top-right",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
this.setState({ openModalShowReg: false})
                    
                }, (error) => {
                    this.setState({loaderStart:false})
                    toast.error("Something went wrong please try again later", {
                        position: "top-right",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                    });
                    console.log(error);
                    this.setState({ openModalShowReg: false})
                });
        }

    }
    // closeMeetconf = () => {
    //     setShowModalConfMeet(false)
    //     props.setModaCloselData()
    // }
    getCookie(name) {
        var dc = document.cookie;
        var prefix = name + "=";
        var begin = dc.indexOf("; " + prefix);
        if (begin == -1) {
            begin = dc.indexOf(prefix);
            if (begin != 0) return null;
        }
        else {
            begin += 2;
            var end = document.cookie.indexOf(";", begin);
            if (end == -1) {
                end = dc.length;
            }
        }
        return decodeURI(dc.substring(begin + prefix.length, end));
    }

    closeRegModal = () => {
        this.setState({ openModalShowReg: !this.state.openModalShowReg })
    }

    componentDidMount() {
        const query = new URLSearchParams(this.props.location.search);
        const token = query.get('token')
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear();
       
    
    
        today = yyyy + '-' + mm + '-' + dd;
        this.setState({date:today})
        if (token && this.props.computedMatch.params.meeting_id) {

            this.props.history.push('/startconference/' + this.props.computedMatch.params.meeting_id + '/a_on/v_on/' + token);
        }

        if (this.props.computedMatch.params.host_type) {

            this.setState({ joincname: atob(this.props.computedMatch.params.meeting_id) })
        }

        if ((this.props.computedMatch.params.start) && (this.props.computedMatch.params.end)) {

            const current_time = new Date().getTime();
            if (current_time < atob(this.props.computedMatch.params.start) || atob(this.props.computedMatch.params.end) < current_time) {
                this.setState({
                    invalid_time: true
                });

                toast.dismiss();
                toast.error("Meeting cannot be started", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            } else if (this.props.computedMatch.params.host_type) {

                let moderator = false
                if (atob(this.props.computedMatch.params.host_type) == "true") {
                    moderator = true
                }
                this.setState({
                    joincname: atob(this.props.computedMatch.params.meeting_id),
                    isModerator: moderator
                })
            }
        }
        if (this.props.computedMatch.params.host_type) {

            this.props.history.push('/' + atob(this.props.computedMatch.params.meeting_id));
        }
    }

    invitation_urlWithJWT = async () => {
        let token = await getAuthToken();
        let data = await this.getJwtToken(token, 'start', true);
        let invitation_url = Baseurl_invite + '/startconference/' + this.state.cname + '/' + this.state.s_audio + '/' + this.state.s_video + '/' + data.jwt_token
        this.setState({ invitation_url: invitation_url })
    }

    componentDidUpdate() {
        if (this.state.copied) {
            this.timeout = setTimeout(() => {
                this.setState({ copied: false });
            }, 1000);
        }
    }

    componentWillUnmount() {
        clearTimeout(this.timeout);
    }

    showJoinMeeting = () => {
        this.setState({ scheduleMeetingPopup: false })
        this.setState({ joinMeetingPopup: true })
        // this.joinMeetingInput.current.focus();
    }
    showScheduleMeeting = () => {
        this.setState({ joinMeetingPopup: false })
        this.setState({ scheduleMeetingPopup: true })
    }
    popupBoxCancelBtn = (e) => {
        e.stopPropagation()
        this.setState({ joincname: '' })
        this.setState({ joinMeetingPopup: false })
        this.setState({ scheduleMeetingPopup: false })
    }

    myStartSubmitHandler = async () => {

        let token = await getAuthToken();
        let getMeetingsFromMeetingId = await this.getMeetingsFromMeetingId(token, this.state.cname)
        if (getMeetingsFromMeetingId.multiple == false && Object.keys(getMeetingsFromMeetingId.detail).length == 0) {
            let data = await this.getJwtToken(token, 'start');
            const createMeetingUrl = Baseurl_app + '/startconference/' + this.state.cname + '/' + this.state.s_audio + '/' + this.state.s_video + '/' + data.jwt_token
            this.setState({
                meetingUrl: createMeetingUrl
            })
            let current_meeting_data = await this.createBackendMeeting(token)
            this.setState({
                current_meeting_data: current_meeting_data
            })
            localStorage.setItem("current_meeting_data", JSON.stringify(current_meeting_data))
            this.redirectConf(data, 'start')
        } else if (getMeetingsFromMeetingId.multiple == false && Object.keys(getMeetingsFromMeetingId.detail).length > 0) {
            toast.dismiss();
            toast.error("Meeting Already In-Progress for given meetingID", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        } else {
            toast.dismiss(); //NOTE: future possiablities
            toast.error("Meeting Already In-Progress for given meetingID", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }

    myJoinSubmitHandler = async () => {
        let OneCloudMaxUserLimit = 0;
        let GuestMaxUserLimit = 0;
        let token = await getAuthToken();
        let getMeetingsFromMeetingId = await this.getMeetingsFromMeetingId(token, this.state.joincname)
        let getFeatureFromMeetingId = await this.getFeatureFromMeetingId(token, this.state.joincname)

        if (getMeetingsFromMeetingId.multiple == false && getMeetingsFromMeetingId.detail.auth_user == false) {
            GuestMaxUserLimit = getFeatureFromMeetingId.Result.web_participants
        }
        else if (getMeetingsFromMeetingId.multiple == false && getMeetingsFromMeetingId.detail.auth_user == true) {
            OneCloudMaxUserLimit = getFeatureFromMeetingId.Result.web_participants
        }

        if (getMeetingsFromMeetingId.multiple == false && Object.keys(getMeetingsFromMeetingId.detail).length == 0) {
            let data = await this.getJwtToken(token, 'join');
            this.redirectConf(data, 'join')
        } else if ((getMeetingsFromMeetingId.multiple == false
            && Object.keys(getMeetingsFromMeetingId.detail).length > 0)
            && getMeetingsFromMeetingId.detail.status == "I") {
            if (getMeetingsFromMeetingId.detail.auth_user == false && getMeetingsFromMeetingId.detail.current_attendees < GuestMaxUserLimit) {
                let data = await this.getJwtToken(token, 'join');
                this.redirectConf(data, 'join')
            } else if (getMeetingsFromMeetingId.detail.auth_user == true && getMeetingsFromMeetingId.detail.current_attendees < OneCloudMaxUserLimit) {
                let data = await this.getJwtToken(token, 'join');
                this.redirectConf(data, 'join')
            } else {
                toast.dismiss();
                toast.error(MESSAGES.maxParticipant, {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            }
        } else {
            toast.dismiss();
            toast.error("Cannot join the meeting", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }


    getMeetingsFromMeetingId = async (token, meeting_id) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(backendMeetingApi + "/" + meeting_id, {
                method: 'GET',
                headers: myHeaders,
            })
            const data = await result.json()

            return data
        } catch (error) {
            console.log(error)
        }
    }

    getFeatureFromMeetingId = async (token, meeting_id) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(getFeatureFromMeetingIdApi, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify({
                    current_meeting_id: meeting_id,
                })
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log(error)
        }
    }


    createBackendMeeting = async (token) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(backendMeetingApi, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify({
                    meeting_id: this.state.cname,
                    meeting_name: "GuestRoom",
                    oc_user: OneCloudGuestUserID,
                    current_attendees: 1, // NOTE: Need to check 
                    total_attendees: 1, // NOTE: Need to check 
                    auth_user: false,
                    max_limit_reached: false,
                    status: 'I',
                    is_scheduled: false,
                    meeting_url: this.state.meetingUrl
                }),
            })
            const data = await result.json()

            return data
        } catch (error) {
            console.log(error)
        }
    }

    getJwtToken = async (token, participant, isSixMonthExpiry = false) => {
        let room_name = this.state.cname
        let moderator = true
        if (participant === "join") {
            room_name = this.state.joincname
            moderator = false
        }
        let obj
        if (isSixMonthExpiry) {
            const timezone = jstz.determine();
            obj = {
                room: room_name,
                is_mod: moderator,
                isSixMonthExpiry: true,
                timeZone: timezone.name()
            }

        } else {
            obj = {
                room: room_name,
                is_mod: moderator,
                isSixMonthExpiry: false
            }
        }
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(gettoken, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify(obj),
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log(error)
        }
    }

    redirectConf = (data, participant) => {
        let cname;
        if (participant === 'start') {
            cname = this.state.cname
        }
        else if (participant === 'join') {
            cname = this.state.joincname
        }
        this.props.history.push('/startconference/' + cname + '/' + this.state.s_audio + '/' + this.state.s_video + '/' + data.jwt_token);
    }
    removeEmailAttende = (email) => {

        var indexVal = this.state.attendees.indexOf(email)

        if (indexVal > -1) {

            this.state.attendees.splice(indexVal, 1);
            this.setState({ attendees: [...this.state.attendees] })
            // setAttendees([...attendees]);

        }


    }
    //scheduleObj

    //}
    // Set a Cookie
    setCookie = (cName, cValue, expDays) => {
        let date = new Date();
        date.setTime(date.getTime() + (expDays * 24 * 60 * 60 * 1000));
        const expires = "expires=" + date.toUTCString();
        document.cookie = cName + "=" + cValue + "; " + expires + "; path=/";
    }


    handleChange(event) {
        if (event.target.name === "s_audio") {
            let audio_mute = "a_off"
            if (event.target.checked) {
                audio_mute = "a_on";
            } else {
                audio_mute = "a_off";
            }
            this.setState({
                [event.target.name]: audio_mute,
                isAudioChecked: !this.state.isAudioChecked,
            });
            this.setCookie('s_audio', audio_mute, 30);

        } else if (event.target.name === "s_video") {
            let video_mute = "v_off"
            if (event.target.checked) {
                video_mute = "v_on"
            } else {
                video_mute = "v_off"
            }
            this.setState({
                [event.target.name]: video_mute,
                isVideoChecked: !this.state.isVideoChecked,
            });
            this.setCookie('s_video', video_mute, 30);
        } else {
            const value = event.target.value;
            this.setState({
                [event.target.name]: value
            });
        }
    }
    scheduleMeeting = () => {
        this.props.history.push('/schedule/meeting/');
    }

    render() {
        return (

            <React.Fragment>
                <Header />
                <div className="meetings-Wrapper">
                    {this.state.showWatchModal === true ?
                        <div class="modal-dialog modal-lg" >
                            <WatchModal showWatchModal={this.state.showWatchModal}
                                closeMeetconf={this.closeMeetconf}
                                getTimePickerDate={this.getTimePickerDate}
                                takeTime={this.takeTime}
                                landingPage={true}
                                openClock={this.state.openClock}
                            />

                        </div>
                        : ""}

                </div>
                <div className="meetings-Wrapper">
                    {this.state.showModal === true ?
                        <div class="modal-dialog modal-lg" >
                            <TimeZoneModal showModal={this.state.showModal} closeTimeZoneModal={this.closeTimeZoneModal} />

                        </div>
                        : ""}

                </div>

                {!this.state.isAuthenticated ?
                    <div className="">
                        <div className="login-form">
                            <div id="form-wrapper" className="form-wrapper">
                                <div className="logo-Name">
                                    {this.state.isAuthenticated ?
                                        <Link to="/user/dashboard">
                                            <img className="logoImageLandingPage" src={Logo} alt="hdmeet Logo" />
                                        </Link>
                                        :
                                        <Link to="/">
                                            <img className="logoImageLandingPage" src={Logo} alt="hdmeet Logo" />
                                        </Link>
                                    }
                                </div>

                                <div className="d-flex justify-content-center">
                                    <div className="mt-3" style={{ fontSize: "20px" }}>Wecome to HDMeet</div>
                                </div>
                                <div className="d-flex justify-content-center">
                                    <div className="" style={{ fontSize: "16px", color: "#959595" }}>
                                        Anytime, any where video conferencing.</div>
                                </div>
                                <div className="d-flex justify-content-center">
                                    <div className="StartMeet mt-3 btn" onClick={this.myStartSubmitHandler}
                                    >Start New Meeting</div>
                                </div>
                                <div className="d-flex justify-content-center">
                                    <div className="JoinMeet mt-3 btn" onClick={this.showJoinMeeting}>
                                        Join Meeting
                                        </div>
                                </div>
                                <div className={`popupBox JoinMeetingPopup  lpagePopUpbox ${this.state.joinMeetingPopup ? "d-block" : ''}`}>
                                    <AvForm className="" onValidSubmit={this.myJoinSubmitHandler}>
                                        <AvField
                                            name="joincname"
                                            className="form-control mt-1"
                                            type="text"
                                            errorMessage="Please enter a valid ID."
                                            placeholder="Enter HDMeet ID"
                                            // ref={this.joinMeetingInput}
                                            validate={{
                                                required: { value: true, errorMessage: 'No space & special characters allowed.' },
                                                pattern: { value: '/^[a-zA-Z0-9,-_]+$/', errorMessage: 'No space & special characters allowed.' }
                                            }}
                                            value={this.state.joincname}
                                            onChange={this.handleChange}
                                        />
                                        <div className="AudioVideoSection inJoinpopup">
                                            <div className="AudioButton mr-3">
                                                <label className="mr-1" style={{ color: '#0c5794' }}>{MESSAGES.audio}</label>
                                                <label className="switch">
                                                    <input id="muteAudioConf"
                                                        type="checkbox"
                                                        name="s_audio"
                                                        // value={this.state.s_audio}
                                                        checked={this.state.s_audio === 'a_on' ? this.state.isAudioChecked : false}
                                                        onChange={this.handleChange}
                                                    />
                                                    <span className="slider round"></span>
                                                </label>
                                            </div>

                                            <div className="VedioButton">
                                                <label className="mr-1" style={{ color: '#0c5794' }}>{MESSAGES.video}</label>
                                                <label className="switch">
                                                    <input id="muteVedioConf"
                                                        type="checkbox"
                                                        name="s_video"
                                                        checked={this.state.s_video === 'v_on' ? this.state.isVideoChecked : false}
                                                        onChange={this.handleChange}
                                                    />
                                                    <span className="slider round"></span>
                                                </label>
                                            </div>
                                        </div>
                                        <div className="button d-inline-block popupBoxCancelBtn mr-3" onClick={this.popupBoxCancelBtn}>{MESSAGES.cancel}</div>
                                        <button className="popupJoinBtn">{MESSAGES.joinMeeting}</button>
                                    </AvForm>

                                </div>

                                <div className="d-flex justify-content-center">
                                    <div className="JoinMeet mt-3 btn"
                                        onClick={() => this.closeRegModal()}
                                    >Schedule Meeting</div>
                                </div>
                                <div className="d-flex justify-content-around w-100 webinarPermition mt-4 mb-4" style={{ fontSize: "12px" }}>
                                    <div className="float-left mb-3"><span className="ml-3">Audio</span>
                                        <br />
                                        <span className="mr-2 d-inline">off</span>

                                        <label className="switch">
                                            <input className="mt-2"
                                                id="muteAudioConf"
                                                type="checkbox"
                                                name="s_audio"
                                                checked={this.state.s_audio === 'a_on' ? this.state.isAudioChecked : false}
                                                onChange={this.handleChange}

                                            />
                                            <span className="slider round"></span>
                                        </label>

                                        <span className="ml-1 d-inline">on</span>

                                    </div>
                                    <div className="float-left"><span className="ml-3">Video</span>
                                        <br />
                                        <span className="mr-2 d-inline">off</span>

                                        <label className="switch">
                                            <input className="mt-2"
                                                id="muteVedioConf"
                                                type="checkbox"
                                                name="s_video"
                                                checked={this.state.s_video === 'v_on' ? this.state.isVideoChecked : false}
                                                onChange={this.handleChange}

                                            />
                                            <span className="slider round"></span>
                                        </label>

                                        <span className="ml-1 d-inline">on</span>

                                    </div>
                                </div>


                            </div>
                            <p className="text-center mt-5 mb-4">Download for your mobile device</p>
                            <div className="d-flex StoreBtn justify-content-center">
                                <div>
                                    <a target="_blank" href={appleStoreUrl}>
                                        <img src={AppleStoreIcon} className=" storeIcon mr-5" alt="Apple-Store-Icon" />
                                    </a>
                                </div>
                                <div>
                                    <a target="_blank" href={googleStoreUrl}>
                                        <img src={GoogleStoreIcon} className="storeIcon" alt="Google-Store-Icon" />
                                    </a>
                                </div>
                            </div>
                            <p className="text-center login-footer mt-5">Telware Corporation @2021. All Rights Reserved <br />HDMeet Release v1.1.0 | <a className="termLink" href="https://www.telware.com/terms-of-service" target="_blank">Terms of service </a>| <a className="termLink" href="https://www.telware.com/learn/hdmeet-privacy-policy" target="_blank">Privacy Policy</a></p>
                        </div>
                        <Modal
                            show={this.state.openModalShowReg}
                            onHide={() => this.setState({ showAddUserModal: false, showDomainTable: false })}
                            // dialogClassName="modal-90w"
                            size="xl"
                            aria-labelledby="contained-modal-title-vcenter"

                        >
                            <Modal.Header onClick={() => this.closeRegModal()} closeButton style={{ background: "#18508D" }}>
                                <Modal.Title style={{ lineHeight: 1, color: "#fff" }}  >Schedule meeting</Modal.Title>
                            </Modal.Header>

                            <Modal.Body>

                                <div className="container-fluid removeMargin">
                                    <div className="row">
                                        <div className="col-md-12 col-sm-12 d-flex">
                                            <div className="col-md-6 col-sm-12">
                                                <div className="mt-3" style={{
                                                    color: "#474747", fontSize: "24px"
                                                }} >Great! You would like to set up a meeting.</div>
                                                <div className="mt-2" style={{
                                                    color: "#474747", fontSize: "16px"
                                                }}>Meeting Setup</div>
                                                <div className="form-group">
                                                    <div className="text-danger" style={{ textAlign: "left" }}>{this.state.titleError}</div>
                                                    <input type="email"

                                                        className="form-control"
                                                        id="exampleInputEmail1"
                                                        aria-describedby="emailHelp"
                                                        placeholder="Title of Meeting"
                                                        onChange={(e) => this.getTitle(e)}


                                                    />



                                                </div>
                                                <div className="form-group">

                                                    <input type="email"

                                                        className="form-control"
                                                        id="exampleInputEmail1"
                                                        aria-describedby="emailHelp"
                                                        placeholder="Description"
                                                        onChange={(e) => this.getDesc(e)}


                                                    />



                                                </div>
                                                <div className="">
                                                    <div className="row">

                                                        <div className="col-md-6 col-lg-4">
                                                            <div className="text-danger" style={{ textAlign: "left" }}>{this.state.zoneError}</div>
                                                            <div className="text-danger" style={{ textAlign: "left" }}>{this.state.durationError}</div>
                                                            <input id="" type="date"
                                                                value={this.state.date}
                                                                className="form-control"
                                                                style={{ Width: "100%" }}
                                                                //  onChange={(date)=>this.getDate(date)}
                                                                onChange={(e) => this.getDate(e)}

                                                            />


                                                            <p className="schedularText">Date</p>
                                                        </div>
                                                        {this.state.loaderStart===true &&
                                                            <div>
                                                                <Loder />
                                                            </div>
                                                        }
                                                        <div className="col-md-6 col-lg-3">



                                                            <Input
                                                                // type={inputType === true ? "time" : ""}
                                                                style={{ width: "116%", height: "43%" }}
                                                                type="text"
                                                                className="form-control hourWidth"
                                                                name="searchText"
                                                                value={this.state.time}
                                                                placeholder="hh:mm AM"
                                                                onChange={(e) => this.setTime(e)}
                                                                startAdornment={

                                                                    <InputAdornment position="start">
                                                                        <MDBIcon far
                                                                            onClick={() => this.openWatch()}
                                                                            icon="clock" />
                                                                    </InputAdornment>
                                                                }
                                                            />


                                                            <p className="schedularText">Hour</p>
                                                        </div>




                                                        <div className="col-md-6 col-lg-3">

                                                            <select className="custom-select durationDiv ml-0 form-control"
                                                                id="inputGroupSelect01"
                                                                style={{ width: "100%", height: "33px" }}
                                                                onChange={(e) => this.getDuration(e)}
                                                            >
                                                                <option selected>15 min</option>
                                                                <option value="30">30 min</option>
                                                                <option value="45">45 min</option>
                                                                <option value="60">01 hour 00 min</option>
                                                                <option value="75">01 hour 15 min</option>
                                                                <option value="90">01 hour 30 min</option>
                                                                <option value="105">01 hour 45 min</option>
                                                                <option value="120">02 hour 00 min</option>
                                                                <option value="135">02 hour 15 min</option>
                                                                <option value="150">02 hour 30 min</option>
                                                                <option value="165">02 hour 45 min</option>
                                                                <option value="180">03 hour 00 min</option>
                                                                <option value="195">03 hour 15 min</option>
                                                                <option value="210">03 hour 30 min</option>
                                                                <option value="225">03 hour 45 min</option>
                                                                <option value="240">04 hour 00 min</option>
                                                                <option value="255">04 hour 15 min</option>
                                                                <option value="270">04 hour 30 min</option>
                                                                <option value="285">04 hour 45 min</option>
                                                                <option value="300">05 hour 00 min</option>
                                                                <option value="315">05 hour 15 min</option>
                                                                <option value="330">05 hour 30 min</option>
                                                                <option value="345">05 hour 45 min</option>
                                                                <option value="360">06 hour 00 min</option>
                                                                <option value="375">06 hour 15 min</option>
                                                                <option value="390">06 hour 30 min</option>
                                                                <option value="405">06 hour 45 min</option>
                                                                <option value="420">07 hour 00 min</option>
                                                                <option value="435">07 hour 15 min</option>
                                                                <option value="450">07 hour 30 min</option>
                                                                <option value="465">07 hour 45 min</option>
                                                                <option value="480">08 hour 00 min</option>
                                                            </select>
                                                            <p className="schedularText">Duration</p>
                                                        </div>



                                                        <div className="col-md-6 col-lg-2">
                                                            <input className="form-control"
                                                                value={this.state.selectedDisplayTimezone}
                                                                onClick={() => this.handleTimeZoneModal()}
                                                                type="text"
                                                                placeholder="Time Zone"
                                                                style={{ width: "100%", height: "32px" }}
                                                            />





                                                            <p className="schedularText">Zone</p>
                                                        </div>





                                                    </div>

                                                </div>
                                                <div className="d-flex mt-3" style={{ fontSize: "12px" }}>
                                                    <div>Meeting Type </div>
                                                    <div><input className="redioBtn ml-3"
                                                        type="radio"
                                                        name="selectType"
                                                        checked={true}

                                                    /></div>
                                                    <div className="ml-3">Conference</div>
                                                </div>
                                                <div className="form-group mb-0 mt-3">

                                                    <input type="text"
                                                        // value={meeting_password}
                                                        className="form-control"
                                                        id="exampleInputEmail1"
                                                        aria-describedby="emailHelp"
                                                        placeholder="Password"
                                                        onChange={(e) => this.getReqPass(e)}
                                                        style={{ height: "35px" }}

                                                    />

                                                </div>
                                                <div className="d-flex">
                                                    <div className="col-xl-4 col-md-4 col-sm-12 text-left mt-2">
                                                        <p className="mpass ml-0">Meeting Password</p>
                                                    </div>
                                                    <div className="col-xl-7 col-md-7 col-sm-12 text-right mt-2 ml-5" style={{ fontSize: "12px" }}>
                                                        <span className="mpass mt-2 " >Require Password</span>
                                                        <span className=" mr-2 ml-2 mt-2">Off</span>
                                                        <label className="switch">
                                                            <input className="mt-2"
                                                                onChange={() => this.getReqPass()}
                                                                type="checkbox" />
                                                            <span className="slider round"></span>
                                                        </label>
                                                        <span className="ml-1">On</span>


                                                    </div>
                                                </div>
                                            </div>
                                            <div class=""><div class="vline mt-4 ml-4"></div></div>
                                            <div className=" col-xl-5 col-md-5 col-sm-12 mt-5 ml-4">
                                                <div className="form-group mt-4">

                                                    <div className="text-danger" style={{ textAlign: "left" }}>{this.state.hostEmailError}</div>
                                                    <label className="float-left" style={{ fontSize: "16px" }}>Your Email Address (Host)</label>
                                                    <input type="email"
                                                        className="form-control"
                                                        id="exampleInputEmail1"
                                                        aria-describedby="emailHelp"
                                                        placeholder="Add by email"
                                                        value={this.state.modrator}
                                                        onChange={(e) => this.getHostEmail(e)}

                                                    />

                                                </div>

                                                <div className="form-group mt-4">

                                                    <div className="text-danger" style={{ textAlign: "left" }}>{this.state.attendeesError}</div>
                                                    <label className="float-left" style={{ fontSize: "16px" }}>Add Attendees</label>
                                                    <input type="email"
                                                        className="form-control"
                                                        id="exampleInputEmail1"
                                                        aria-describedby="emailHelp"
                                                        placeholder="Add by email"
                                                        value={this.state.attCurrentValue}
                                                        onChange={(e) => this.getAttendees(e)}
                                                        onKeyPress={(e) => this.handleTestAttende(e)}
                                                    />

                                                </div>

                                                <ul className="addemail">
                                                    {this.state.attendees.length > 0 && this.state.attendees.map((moder, index) => {
                                                        return (<li>
                                                            <div>
                                                                <div className="d-flex align-items-center">
                                                                    {/* <div className="pothoFrame">
                                                           
                                                        </div> */}
                                                                    <div className="ml-2" style={{ fontSize: "14px" }}>
                                                                        {moder}
                                                                        <i className="fas fa-times"
                                                                            onClick={() => this.removeEmailAttende(moder)}>
                                                                        </i> </div>
                                                                </div>
                                                            </div>
                                                        </li>)

                                                    })}
                                                </ul>
                                                <div className="row">
                                                    <div className="col-md-12 btndownLpage justify-content-start mt-2">

                                                        <button type="button"
                                                            style={{ width: "40%", background: "#38A6DE", borderRadius: "8px", color: "#fff" }}
                                                            class="btn float-left"
                                                            onClick={() => this.scheduleSubmit()}
                                                        >Save</button>

                                                        <button type="button"
                                                            style={{ width: "40%", background: "#757575", borderRadius: "8px", color: "#fff" }}
                                                            class="btn float-right"
                                                            data-dismiss="modal"
                                                            onClick={() => this.closeRegModal()}
                                                        >Close
                                                        </button>
                                                        <br />
                                                        <div className="d-flex w-100 mt-4 text-center justify-content-center">
                                                            <CopyToClipboard text={this.state.invitation_url}
                                                                onCopy={() => this.setState({ copied: true })}>
                                                                <p className="" style={{ color: "#38A6DE" }} onClick={this.invitation_urlWithJWT}>
                                                                    <i
                                                                        class="fa fa-clone"  aria-hidden="true">
                                                                    </i>

                                                Or just copy the link of your free meeting
                                                <br/>
                                                <span className="text-success">{this.state.copied===true && "copied"}</span>
                                            </p>
                                                            </CopyToClipboard>

                                                        </div>
                                                    </div>

                                                </div>


                                            </div>

                                        </div>
                                    </div>

                                </div>




                            </Modal.Body>
                        </Modal>
                        {/* <Footer /> */}
                    </div>
                    : this.props.history.push('/user/dashboard/' + this.state.joincname)}

            </React.Fragment>
        );
    }
}

export default LandingPage;