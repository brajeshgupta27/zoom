import React, { Component } from 'react';
import Logo from '../assets/images/Logo_HDMeet.png';
import SettingIcon from '../assets/images/seeting.png';
import MeetingUrlDropdown from '../assets/images/meetingUrlDropdown.png';
import './newDesign.css';
import { Link, withRouter } from 'react-router-dom';
import { Baseurl_app, supportUrl } from '../constant/index';
import Edit_Icon from '../assets/images/pencil.png'
// import Edit_Icon from '../assets/images/editIcon.png';
import Check_Icon from '../assets/images/checkIcon.png';
import Check_Icon_Blue from '../assets/images/checkIconBlue.png';
import { toast } from 'react-toastify';
import { checkMeetingExistApi, config, updateCurrentMeetingApi, getScope_featureList } from '../constant/index';
import { getAuthToken } from '../helpers/auth-header';
import ReactTooltip from 'react-tooltip';
import { MESSAGES } from '../constant/messages';

class Header extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isAuthenticated: localStorage.getItem('isAuthenticated') ? localStorage.getItem('isAuthenticated') : false,
            apiUserDetail: localStorage.getItem('apiUserDetail') ? JSON.parse(localStorage.getItem('apiUserDetail')) : '',
            meetingUrlLink: localStorage.getItem('meetingUrlLink') ? localStorage.getItem('meetingUrlLink') : '',
            isEdit: false,
            inValidMeetingUrl: true,
            selectedMeetingOption: null,
            isSettingVisible: false,
            toggleAudio: localStorage.getItem('apiUserDetail') ? (!JSON.parse(localStorage.getItem('apiUserDetail')).settings ? false : JSON.parse(localStorage.getItem('apiUserDetail')).settings.is_audio) : false,
            toggleVideo: localStorage.getItem('apiUserDetail') ? (!JSON.parse(localStorage.getItem('apiUserDetail')).settings ? false : JSON.parse(localStorage.getItem('apiUserDetail')).settings.is_video) : false,
            toggleTranscribe: localStorage.getItem('apiUserDetail') ? (!JSON.parse(localStorage.getItem('apiUserDetail')).settings ? false : JSON.parse(localStorage.getItem('apiUserDetail')).settings.is_transcribe) : false,
            toggleLobby: localStorage.getItem('apiUserDetail') ? (!JSON.parse(localStorage.getItem('apiUserDetail')).settings ? false : JSON.parse(localStorage.getItem('apiUserDetail')).settings.is_lobby) : false,
            toggleMeetingPassword: localStorage.getItem('apiUserDetail') ? (!JSON.parse(localStorage.getItem('apiUserDetail')).settings ? false : JSON.parse(localStorage.getItem('apiUserDetail')).settings.is_password) : false,
            meetingPassword: localStorage.getItem('apiUserDetail') ? (!JSON.parse(localStorage.getItem('apiUserDetail')).settings ? '' : JSON.parse(localStorage.getItem('apiUserDetail')).settings.password) : "",
            meetingIdCount:null,
        };
        this.handleLoginClick = this.handleLoginClick.bind(this);
        this.handleLogoutClick = this.handleLogoutClick.bind(this);
        this.showHideSetting = this.showHideSetting.bind(this);
    }

    handleLoginClick() {
        let path = `/user/login`;
        this.props.history.push(path)
    }

    handleChange = (event) => {
        const regex = /^[0-9\b]+$/;
        if (event.target.value === '' || regex.test(event.target.value)) {
            this.setState({
                [event.target.name]: event.target.value
            }, () => {
                let meetingPassword = this.state.toggleMeetingPassword ? this.state.meetingPassword : ''
                if (this.props.currentMeetingPassword) {
                    this.props.currentMeetingPassword(meetingPassword)
                }
            });
        } else {
            toast.dismiss();
            toast.warning("Only numbers are allowed.", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }

    handleLogoutClick() {
        this.setState({ isAuthenticated: false });
        localStorage.setItem('isAuthenticated', false);
        localStorage.clear();
        this.props.history.push('/')
    }

    updateFormValue = (event) => {
        if (event.target.value.match("^[a-zA-Z0-9\-_]*$") != null) {
            if (event.target.value.length == 0) {
                this.setState({
                    meetingUrlLink: '',
                    inValidMeetingUrl: false // this state will be used to hide and show the error message
                });
            } else {
                this.setState({
                    inValidMeetingUrl: true,
                    meetingUrlLink: event.target.value
                });
            }
        } else {
            this.setState({
                inValidMeetingUrl: false
            });
        }
    }

    showHideSetting = (event) => {
        const { isSettingVisible } = this.state;
        this.setState({
            isSettingVisible: !isSettingVisible,
        });
        if (this.state.apiUserDetail.settings == false) {
            this.createSettingOption()
        }
    }

    handleToggleChange(event) {
        const {
            toggleAudio,
            toggleVideo,
            toggleTranscribe,
            toggleLobby,
            toggleMeetingPassword
        } = this.state;

        if (event.target.name === "toggleAudio") {
            this.setState({
                [event.target.name]: !toggleAudio
            }, () => {
                this.updateSettingOption('audio', this.state.toggleAudio)
            });
        } else if (event.target.name === "toggleVideo") {
            this.setState({
                [event.target.name]: !toggleVideo
            }, () => {
                this.updateSettingOption('video', this.state.toggleVideo)
            });
        }
        else if (event.target.name === "toggleTranscribe") {
            this.setState({
                [event.target.name]: !toggleTranscribe
            }, () => {
                this.updateSettingOption('transcribe', this.state.toggleTranscribe)
            });
        } else if (event.target.name === "toggleLobby") {
            this.setState({
                [event.target.name]: !toggleLobby
            }, () => {
                this.updateSettingOption('lobby', this.state.toggleLobby)
            });
        } else if (event.target.name === "toggleMeetingPassword") {
            this.setState({
                [event.target.name]: !toggleMeetingPassword
            }, () => {
                this.updateSettingOption('password', this.state.toggleMeetingPassword)
                let meetingPassword = this.state.toggleMeetingPassword ? this.state.meetingPassword : ''
                if (this.props.currentMeetingPassword) {
                    this.props.currentMeetingPassword(meetingPassword)
                }
            });
        }
    }

    updateCurrentMeetingApiUrl = async () => {
        let obj = {}
        let token = await getAuthToken();
        obj = {
            "username": this.state.apiUserDetail.username,
            "current_meeting_id": this.state.meetingUrlLink,
        }
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(updateCurrentMeetingApi, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify(obj),
            })
            const data = await result.json()
            this.setState({
                meetingUrlLink: data.current_meeting_id
            })
            localStorage.setItem("meetingUrlLink", data.current_meeting_id)
        } catch (error) {
            console.log(error)
        }
    }


    selectedMeetingUrl = (value) => {
        this.setState({
            meetingUrlLink: value,
            inValidMeetingUrl: true
        })
        this.updateCurrentMeetingApiUrl()
        this.setState({
            isEdit: false
        });
    }

    featureDetailsList = async (token, oc_scope) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(getScope_featureList + "/" + oc_scope, {
                method: 'GET',
                headers: myHeaders,
            })
            const data = await result.json()
            Object.entries(data.Result).map((key)=>{
               let value = key[1]
                this.setState({
                    meetingIdCount: value.custom_meeting_url
                })
            })
        } catch (error) {
            console.log(error)
        }
    }

    updateMeetingLink = async (event) => {
        this.setState({
            isEdit: false
        });
        let token = await getAuthToken();
        let featureDetailsList = await this.featureDetailsList(token, this.state.apiUserDetail.oc_scope);
        if (this.state.apiUserDetail.meeting_ids.length < this.state.meetingIdCount) {
            if (!this.state.apiUserDetail.meeting_ids.includes(this.state.meetingUrlLink)) {
                this.checkMeetingExist(token);
            } else {
                this.setState({
                    meetingUrlLink: localStorage.getItem('meetingUrlLink')
                })
                toast.dismiss();
                toast.warning("Sorry! provided meeting ID already exist", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            }
        } else {
            this.setState({
                meetingUrlLink: localStorage.getItem('meetingUrlLink')
            })
            toast.dismiss();
            toast.warning(`Sorry! you cannot create a new meeting. You have hit your max limit of ${ this.state.meetingIdCount} meeting ID's`, {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }

    checkMeetingExist = async (token) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(checkMeetingExistApi, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify({ user_id: this.state.apiUserDetail.id, meeting_id: this.state.meetingUrlLink }),
            })
            const data = await result.json()
            if (data.can_create) {
                localStorage.setItem("meetingUrlLink", this.state.meetingUrlLink);
                let existingEntries = JSON.parse(localStorage.getItem("apiUserDetail"));
                existingEntries.meeting_ids.push(this.state.meetingUrlLink)
                localStorage.setItem("apiUserDetail", JSON.stringify(existingEntries))
                this.setState({
                    apiUserDetail: existingEntries
                })
                toast.dismiss();
                toast.success("Meeting link successfully changed", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            } else {
                if (this.state.meetingUrlLink == localStorage.getItem('meetingUrlLink')) {
                    return
                }
                toast.dismiss();
                toast.error(this.state.meetingUrlLink + " " + "meeting link already exist, Try something else", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                this.setState({
                    meetingUrlLink: localStorage.getItem('meetingUrlLink')
                });
            }
            return data
        } catch (error) {
            console.log(error)
        }
    }

    updateSettingOption = async (name, value) => {
        let obj = {}
        let token = await getAuthToken();
        let keyName;
        if (name === 'audio') {
            keyName = 'is_audio'
            const data = obj[keyName] = value
        } else if (name === 'video') {
            keyName = 'is_video'
            const data = obj[keyName] = value
        } else if (name === 'transcribe') {
            keyName = 'is_transcribe'
            const data = obj[keyName] = value
        } else if (name === 'lobby') {
            keyName = 'is_lobby'
            const data = obj[keyName] = value
        } else if (name === 'password') {
            keyName = 'is_password'
            const data = obj[keyName] = value
        } else if (name === 'meetingPassword') {
            if (value.toString().length < 6) {
                toast.dismiss();
                toast.warning("Minimum 6 digits should be entered.", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                return
            } else {
                keyName = 'password'
                const data = obj[keyName] = value
                toast.dismiss();
                toast.success("Meeting password have been successfully updated.", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                this.setState({
                    isSettingVisible: !this.state.isSettingVisible,
                })
            }
        }
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(config + '/' + this.state.apiUserDetail.id, {
                method: 'PUT',
                headers: myHeaders,
                body: JSON.stringify(obj),
            })
            const data = await result.json()
            let existingEntries = JSON.parse(localStorage.getItem("apiUserDetail"));
            existingEntries.settings = data
            localStorage.setItem("apiUserDetail", JSON.stringify(existingEntries))
            return data
        } catch (error) {
            console.log(error)
        }
    }

    createSettingOption = async () => {
        let obj = {}
        let token = await getAuthToken();
        obj = {
            "is_audio": false,
            "is_video": false,
            "is_transcribe": false,
            "is_lobby": false,
            "is_password": false,
            "password": "",
            "oc_user": this.state.apiUserDetail.id
        }
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(config, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify(obj),
            })
            const data = await result.json()
            let existingEntries = JSON.parse(localStorage.getItem("apiUserDetail"));
            existingEntries.settings = data
            localStorage.setItem("apiUserDetail", JSON.stringify(existingEntries))
            this.setState({
                apiUserDetail: existingEntries
            })
        } catch (error) {
            console.log(error)
        }
    }

    render() {
        const { selectedMeetingOption } = this.state;
        const isAuthenticated = this.state.isAuthenticated;
        let button;
        if (isAuthenticated) {
            button = <a href="" className="loginBtn text-dark" style={{fontSize: "16px"}} onClick={this.handleLogoutClick}>{MESSAGES.Logout}</a>;
        } else {
            button = <a href="" className="loginBtn text-dark" style={{fontSize: "16px"}} onClick={this.handleLoginClick}>Already have a HDMeet account? Log in</a>;
        }

        return (
            <header className="headerContainer mx-3">
                <div className="header-logo">
                    <div className="header-left-part">
                        <div className="logo-Name">
                        {this.state.isAuthenticated &&
                            <Link to="/user/dashboard">
                                <img className="logoImage " src={Logo} alt="hdmeet Logo" />
                            </Link>
                            // :
                            // <Link to="/">
                            //     <img className="logoImage" src={Logo} alt="hdmeet Logo" />
                            // </Link>
                        }
                        </div>                        
                        <div className="right-side">
                                {this.state.isAuthenticated ?
                            <div>
                                <span className="user-meeting-headerLink textMargin" >{MESSAGES.meetingURL}{Baseurl_app + "/"}</span>
                                {this.state.isEdit ?
                                    <div style={{ display: "inline-flex", alignItems: "center", position: "relative" }}>
                                        <span className="meetingUrlDropDownHeader">
                                            {this.state.meetingUrlLink}
                                            <img src={MeetingUrlDropdown} alt="Meeting Url Dropdown Icon" />
                                        </span>
                                        {this.state.inValidMeetingUrl ?
                                            <img className="editIcons" src={Check_Icon} alt="checkIcon" data-tip={MESSAGES.saveIcon} data-for='saveIcon' onClick={this.updateMeetingLink} />
                                            :
                                            <span className="meetingUrlError">{MESSAGES.noSpaceSpecialCharactersAllowed}</span>
                                        }
                                        <ul className="meetingUrlListDropDown">
                                            <li className="meetingUrlInput">
                                                <input placeholder="Enter New Meeting ID" type="text" name="meetingUrlLink" onChange={this.updateFormValue} />
                                            </li>
                                            <li className="previousRoomLabel">Previous Rooms</li>
                                            {this.state.apiUserDetail.meeting_ids.map((meetingId, item) =>
                                                <li key={item} onClick={() => this.selectedMeetingUrl(meetingId)}>
                                                    {meetingId}
                                                </li>
                                            )}
                                        </ul>
                                    </div>
                                    :
                                    <div style={{ display: "inline-block" }}>
                                        <span className="user-meeting-headerLink">{this.state.meetingUrlLink}</span>
                                        <img className="editIcons" src={Edit_Icon} alt="editIcon" data-tip={MESSAGES.editIcon} data-for='editIcon' onClick={() => { this.setState({ isEdit: true }) }} />
                                    </div>
                                }
                            </div>
                            : null}
                        {
                            this.state.isAuthenticated ?
                                <div>
                                    <ReactTooltip id='saveIcon' />
                                    <ReactTooltip id='editIcon' />
                                </div>
                                : null
                        }
                        </div>
                    </div>
                    <div>
                        <div className="" style={{fontSize:"12px"}}>
                            <a href={supportUrl} target="_blank" className="text-dark mr-3"
                            style={{fontSize: "16px"}}>{MESSAGES.support}</a>
                            {/* NOTE: Below link is to show the dashboard button on navigation if user is logged in */}
                            {/* {localStorage.getItem("isAuthenticated") ? <Link className="text-white mr-5" onClick={() => this.props.history.push('/user/dashboard')}>Dashboard</Link> : null} */}
                            <span>{button}</span>
                            {this.state.isAuthenticated ?
                                <div className="settingContainer">
                                    <img src={SettingIcon} alt="settingIcon" className="dashboardSettingIcon" onClick={(event) => this.showHideSetting(event)} />
                                    {this.state.isSettingVisible ?
                                        <div className="settingOptions">
                                            <ul>
                                                {/* NOTE : Audio, Video, Transcribe, lobby feature is working but will be enabled later */}
                                                <li>
                                                    Start with Audio
                                            <div className="settingOptionSlider">
                                                        <label className="switch">
                                                            <input
                                                                type="checkbox"
                                                                name="toggleAudio"
                                                                defaultChecked={this.state.toggleAudio}
                                                                onChange={(event) => { this.handleToggleChange(event) }}
                                                            />
                                                            <span className="slider round"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                                <li>
                                                    Start with Video
                                            <div className="settingOptionSlider">
                                                        <label className="switch">
                                                            <input
                                                                type="checkbox"
                                                                name="toggleVideo"
                                                                defaultChecked={this.state.toggleVideo}
                                                                onChange={(event) => { this.handleToggleChange(event) }}
                                                            />
                                                            <span className="slider round"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                                {/* NOTE : Video, Transcribe feature is working but will be enabled later */}
                                                {/* <li>
                                                    Transcribe
                                            <div className="settingOptionSlider">
                                                        <label className="switch">
                                                            <input
                                                                type="checkbox"
                                                                name="toggleTranscribe"
                                                                defaultChecked={this.state.toggleTranscribe}
                                                                onChange={(event) => { this.handleToggleChange(event) }}
                                                            />
                                                            <span className="slider round"></span>
                                                        </label>
                                                    </div>
                                                </li> */}
                                                {/* <li>
                                                    Lobby
                                            <div className="settingOptionSlider">
                                                        <label className="switch">
                                                            <input
                                                                type="checkbox"
                                                                name="toggleLobby"
                                                                defaultChecked={this.state.toggleLobby}
                                                                onChange={(event) => { this.handleToggleChange(event) }}
                                                            />
                                                            <span className="slider round"></span>
                                                        </label>
                                                    </div>
                                                </li> */}
                                                <li>
                                                    Meeting Password
                                            <div className="settingOptionSlider">
                                                        <label className="switch">
                                                            <input
                                                                type="checkbox"
                                                                name="toggleMeetingPassword"
                                                                defaultChecked={this.state.toggleMeetingPassword}
                                                                onChange={(event) => { this.handleToggleChange(event) }}
                                                            />
                                                            <span className="slider round"></span>
                                                        </label>
                                                    </div>
                                                </li>
                                                {this.state.toggleMeetingPassword ?
                                                    <li>
                                                        <div className="defaultPasswordBox">
                                                            <input type="text" placeholder="Enter Password" name="meetingPassword" pattern="[0-9]*" minLength="6" value={this.state.meetingPassword} onChange={this.handleChange} />
                                                            <img className="setPasswordIcon" src={Check_Icon_Blue} alt="send" onClick={() => this.updateSettingOption('meetingPassword', this.state.meetingPassword)} />
                                                        </div>
                                                    </li>
                                                    : null}
                                            </ul>
                                        </div>
                                        : null}
                                </div>
                                : null}
                        </div>
                    </div>
                </div>
                
            </header>
        );
    }
}

export default withRouter(Header);