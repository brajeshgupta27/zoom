import * as React from 'react';
import Background from '../assets/images/background.png';
import DownloadIcon from '../assets/images/downloadIcon.png';
import DesktopBlueIcon from '../assets/images/desktopImg.png';
import SendIcon from '../assets/images/sendIcon.png';
import calamderImg from '../assets/images/calan.png';
import calamderImgBlue from '../assets/images/hoverCalendar.svg';
import deskTopImg from '../assets/images/desk.png';
import joinImg from '../assets/images/meet.png';
import joinImgBlue from '../assets/images/join.png';
import EditIcon from '../assets/images/pencil.png'
import axios from 'axios';
import './newDesign.css';
import Header from '../no-auth/header';
import Footer from '../no-auth/footer';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import moment from 'moment';
import { AvForm, AvField } from 'availity-reactstrap-validation';
import refreshIcon from '../assets/images/refreshIMg.png';
import plusIcon from '../assets/images/plusIcon.png';
import { toast } from 'react-toastify';
import ReactTooltip from 'react-tooltip';
import WebinarScheduleModal from './webinarSchedule/WebinarScheduleModal'
import AnalyticsModal from './webinarSchedule/AnalyticsModal'
import webinarSchedule from './webinarSchedule/WebinarSchedule'
import { ReactMultiEmail, isEmail } from 'react-multi-email';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { Link } from "react-router-dom";
// import Modal from '@material-ui/core/Modal';
import DatePicker from 'react-date-picker';
import {
    Card,
    Table,
    Container,
    Row,
    Col,
    Modal,
    Button,
    Dropdown,
} from "react-bootstrap";

// import CreateIcon from '@mui/icons-material/Create';
import {
    gettoken,
    backendMeetingApi,
    OneCloudMaxUserLimit,
    GuestMaxUserLimit,
    getOrCreateOcUser,
    Baseurl_app,
    serveFile,
    getRecordingUrl,
    schedule,
    getScope_featureList,
    getFeatureFromMeetingIdApi,
    downloadFile,
    webinarMeeting,
    webinarRegistrationCount,
    getWebinarList,
    getAttendeeDetails,
    downloadWebinarRecording

} from '../constant/index';
import { getAuthToken } from '../helpers/auth-header';
import { MESSAGES } from '../constant/messages';


class Dashboard extends React.Component {

    constructor(props) {
        super(props);
        let userDetail = localStorage.getItem("apiUserDetail") ? JSON.parse(localStorage.getItem("apiUserDetail")) : {};
        let userAuthDetail = localStorage.getItem("authUserData") ? JSON.parse(localStorage.getItem("authUserData")) : {};
        this.state = {
            cname: localStorage.getItem("meetingUrlLink") ? localStorage.getItem("meetingUrlLink") : '',
            joincname: this.props.computedMatch.params.meeting_id ? this.props.computedMatch.params.meeting_id : "",
            isAuthenticated: localStorage.getItem("isAuthenticated") ? localStorage.getItem("isAuthenticated") : false,
            user_detail: userDetail,
            isModerator: false,
            s_audio: 'a_on',
            s_video: 'v_on',
            user_auth_detail: userAuthDetail,
            users_meeting_details: localStorage.getItem('apiUserDetail') ? JSON.parse(localStorage.getItem("apiUserDetail")).meetings : {},
            users_scheduled_meeting_details: localStorage.getItem('apiUserDetail') ? JSON.parse(localStorage.getItem("apiUserDetail")).schedule_meetings : {},
            joinMeetingPopup: this.props.computedMatch.params.meeting_id ? true : false,
            current_meeting_data: {},
            meetingRecording: localStorage.getItem('meetingRecording') ? JSON.parse(localStorage.getItem('meetingRecording')) : {},
            meetingUrl: '',
            userToken: localStorage.getItem('userToken') ? JSON.parse(localStorage.getItem('userToken')) : "",
            showParticipantList: false,
            newInvitee: [],
            showMeetnigInviteListId: -1,
            meeting_password: localStorage.getItem('apiUserDetail') ? (!JSON.parse(localStorage.getItem('apiUserDetail')).settings ? '' : (JSON.parse(localStorage.getItem('apiUserDetail')).settings.is_password ? JSON.parse(localStorage.getItem('apiUserDetail')).settings.password : '')) : "",
            checkLastLogin: localStorage.getItem('checkLastLogin') ? localStorage.getItem('checkLastLogin') : '',
            showRecordingDetails: false,
            LoaderMsg: false,
            showContent: false,
            fetching_Data: MESSAGES.fetchingRecordingMsg,
            fetureListData: "",
            countOfProgess: 0,
            percent: 0,
            reverse: false,
            webinarData: "",
            show: false,
            analyticsShow: false,
            copy: false,
            index: null,
            webinarId: "",
            meetingId: "",
            dayValue: "",
            dayValueTo: "",
            month: "",
            monthTo: "",
            yearfrm: "",
            yearTo: "",
            years: [],
            webinarPast: [],
            filterPastWebinar: null,
            setIsShown: false,
            setIsShownDesktop: false,
            setIsShownSchedule: false,
            webinareditID: '',
            confirmChangeScopeModal: false,
            deleteConfId: '',
            openModalShowReg: false,
            regDetail: ""
        };


        this.createdDate = this.createdDate.bind(this);
        this.getRecordingDuration = this.getRecordingDuration.bind(this);
        this.meetingDuration = this.meetingDuration.bind(this);
        this.meetingAttendees = this.meetingAttendees.bind(this);
        this.meetingInvites = this.meetingInvites.bind(this);
        this.showParticipantList = this.showParticipantList.bind(this);
        this.myStartSubmitHandler = this.myStartSubmitHandler.bind(this);
        this.myJoinSubmitHandler = this.myJoinSubmitHandler.bind(this);
        this.download_file = this.download_file.bind(this);
    }



    getYears = () => {

        var year1 = moment().format('YYYY');
        var year2 = moment().year();
        var twoDigitYear = parseInt(year2.toString().substr(-2));
        twoDigitYear = twoDigitYear + 1;

        let filteredYear = [];
        for (let i = twoDigitYear - 7; i <= twoDigitYear; i++) {
            filteredYear.push(i)

        }

        this.setState({ years: filteredYear })

    }

    tempFunc = (index) => {

        this.setState({ copy: true, index }, () => {


        })
    }
    async componentDidMount() {
        this.getYears();
        if (this.state.checkLastLogin == '') {
            localStorage.clear()
            document.location.href = '/';
        } else {
            const loginTimeLimit = 60 * 60 * 1000 * 24 * 10
            const dateNow = new Date();
            const currentTime = dateNow.getTime()
            if (currentTime - parseInt(this.state.checkLastLogin) > loginTimeLimit) {
                localStorage.clear()
                document.location.href = '/';
            }
        }
        ReactTooltip.rebuild()

        let token = await getAuthToken();
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        myHeaders.append('Authorization', 'Bearer ' + token.access);

        const requestOptions = {
            method: 'GET',
            headers: myHeaders
        };

        fetch(getScope_featureList + "/" + this.state.user_detail.oc_scope, requestOptions)
            .then(results => results.json())
            .then(data => {
                this.setState({
                    fetureListData: data.Result
                })
            });

        axios.get(`${getWebinarList}/${this.state.user_detail.id}`, {
            headers: {
                'Authorization': `Bearer ${token.access}`
            }
        })
            .then(res => {
                const webinardata = res.data;

                this.setState({ webinarData: webinardata });
            })


    }

    getRegCount(id) {
        axios.get(`${webinarRegistrationCount}/${id}`)
            .then(res => {
                const webinardata = res.data;
                this.setState({ webinarData: webinardata });
            })

    }
    showJoinMeeting = () => {
        this.setState({ joinMeetingPopup: true })
    }

    getOneCloudUserDetail = async (token, userData) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(getOrCreateOcUser, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify({
                    username: userData.username
                }),
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log(error)
        }
    }

    updateMeeting = async () => {

        let token = await getAuthToken();
        let userData = await this.getOneCloudUserDetail(token, this.state.user_detail)
        this.setState({
            users_meeting_details: userData.meetings,
            users_scheduled_meeting_details: userData.schedule_meetings
        })
        localStorage.setItem('apiUserDetail', JSON.stringify(userData))
        ReactTooltip.rebuild()
    }

    updateWebinar = async () => {

        let token = await getAuthToken();
        axios.get(`${getWebinarList}/${this.state.user_detail.id}`, {
            headers: {
                'Authorization': `Bearer ${token.access}`
            }
        })
            .then(res => {
                const webinardata = res.data;

                this.setState({ webinarData: webinardata });
            })
            .catch(error => {
                console.log(error)
            })
    }

    updateInvitee = async (schMeetingData) => {
        if (this.state.newInvitee.length == 0) {
            toast.dismiss();
            toast.warning(MESSAGES.inviteEmailEmpty, {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        } else {
            let token = await getAuthToken();
            try {
                this.setState({
                    showParticipantList: false,
                })
                toast.dismiss();
                toast.warning(MESSAGES.sendingEmailInvites, {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                const myHeaders = new Headers();
                myHeaders.append('Content-Type', 'application/json');
                myHeaders.append('Authorization', 'Bearer ' + token.access);
                let result = await fetch(schedule + '/' + schMeetingData.id, {
                    method: 'PUT',
                    headers: myHeaders,
                    body: JSON.stringify({
                        meeting_id: schMeetingData.meeting_id,
                        participants: this.state.newInvitee,
                        start_time: schMeetingData.start_time,
                        invitation_link: schMeetingData.invitation_link,
                        timezone: schMeetingData.timezone,
                        end_time: schMeetingData.end_time,
                        duration: schMeetingData.duration
                    }),
                })

                toast.dismiss();
                toast.success(MESSAGES.participantAddedSuccessfully, {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                this.updateMeeting()
            } catch (error) {
                console.log(error)
                toast.dismiss();
                toast.error('Invite not send, please try after few minutes.', {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            }
        }
    }


    updateRecording = async () => {
        let token = await getAuthToken();
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(getRecordingUrl, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify({
                    username: this.state.user_auth_detail.username
                }),
            })
            const data = await result.json()
            this.setState({
                meetingRecording: data
            })
            localStorage.setItem('meetingRecording', JSON.stringify(data));
        } catch (error) {
            console.log(error)
        }
        ReactTooltip.rebuild()
    }

    showScheduleMeeting = () => {
        this.setState({ joinMeetingPopup: false })
    }
    reverseDate = () => {
        this.setState({ reverse: true })
    }

    openAnalytics = (id, meetId) => {
        this.setState({ analyticsShow: true })
        this.setState({ webinarId: id })
        this.setState({ meetingId: meetId })
    }
    closeAnalytics = () => {

        this.setState({ analyticsShow: false })
    }
    reverseDate = () => {
        this.setState({ reverse: true })
    }
    getDay = (e) => {
        this.setState({ dayValue: e.target.value })

    }
    getDayTo = (e) => {
        this.setState({ dayValueTo: e.target.value })

    }
    getMonth = (e) => {
        let monthval = e.target.value
        this.setState({ month: monthval })

    }
    getMonthTo = (e) => {
        let monthval = e.target.value
        this.setState({ monthTo: monthval })

    }


    getyearfrm = (e) => {
        let monthval = e.target.value
        this.setState({ yearfrm: monthval })

    }
    getyearTo = (e) => {
        let monthval = e.target.value
        this.setState({ yearTo: monthval })

    }

    filterData = () => {
        // this.setState({filterValue:1})
        var monthNumber = moment().month(this.state.month).format("M");
        monthNumber = monthNumber.length === 2 ? monthNumber : `0${monthNumber}`

        var monthNumberTodate = moment().month(this.state.monthTo).format("M");
        monthNumberTodate = monthNumberTodate.length === 2 ? monthNumberTodate : `0${monthNumberTodate}`

        let fromDate = `20${this.state.yearfrm}-${monthNumber}-${this.state.dayValue}`

        let toDate = `20${this.state.yearTo}-${monthNumberTodate}-${this.state.dayValueTo}`
        var d = new Date();
        var currentIsoDate = d.toISOString();
        let pastWebinar = this.state.webinarData && this.state.webinarData.filter(webinar => webinar.start_time < currentIsoDate)
        let filterPastWebinar = pastWebinar.filter(fromdate => fromdate.start_time >= fromDate && fromdate.start_time <= toDate)
        // return filterPastWebinar
        this.setState({ filterPastWebinar }, () => {

        })


    }
    // getYears =()=>{

    //     for(let i=15; i<=21;i++){
    //         year.push(i)
    //     }

    // }
    showRegDetails = async (id) => {
        this.setState({ openModalShowReg: !this.state.openModalShowReg })
        let token = await getAuthToken();
        axios.get(`${getAttendeeDetails}/${id}`, {
            headers: {
                'Authorization': `Bearer ${token.access}`
            }
        })
            .then(res => {

                if (Object.keys(res.data.Result).length == 0) {
                    this.setState({ regDetail: [] }, () => {
                    })
                }
                else {
                    this.setState({ regDetail: res.data.Result }, () => {
                    })

                }
                // const webinardata = res.data;

                // this.setState({ webinarData: webinardata });
            })


    }

    closeRegModal = () => {
        this.setState({ openModalShowReg: !this.state.openModalShowReg })
    }
    setModalData = (id) => {

        this.setState({ show: true })
        if (id) {
            this.setState({ webinareditID: id }, () => {

            })
        }

    }
    setModaCloselData = () => {

        this.setState({ show: false })


    }

    deleteWebinarConf = (id) => {

        this.setState({ confirmChangeScopeModal: true })
        this.setState({ deleteConfId: id })


    }
    deleteWebinar = async (decision) => {

        this.setState({ confirmChangeScopeModal: false })
        if (decision) {
            const token = await getAuthToken();
            axios.delete(`${webinarMeeting}/${this.state.deleteConfId}`, {
                headers: {
                    'Authorization': `Bearer ${token.access}`
                }
            })
                .then((response) => {



                })
        }
        window.location.reload();

    }


    popupBoxCancelBtn = (e) => {
        e.stopPropagation()
        this.setState({ joinMeetingPopup: false })
    }

    myStartSubmitHandler = async () => {
        let token = await getAuthToken();
        let getMeetingsFromMeetingId = await this.getMeetingsFromMeetingId(token, localStorage.getItem("meetingUrlLink"))
        if (getMeetingsFromMeetingId.multiple == false && Object.keys(getMeetingsFromMeetingId.detail).length == 0) {
            let data = await this.getJwtToken(token, 'start', this.state.meeting_password);
            const createMeetingUrl = Baseurl_app + '/startconference/' + this.state.cname + '/' + this.state.s_audio + '/' + this.state.s_video + '/' + data.jwt_token
            this.setState({
                meetingUrl: createMeetingUrl
            })
            let current_meeting_data = await this.createBackendMeeting(token, data)
            this.setState({
                current_meeting_data: current_meeting_data
            })
            localStorage.setItem("current_meeting_data", JSON.stringify(current_meeting_data))
            this.redirectConf(data, 'start')
        } else if (getMeetingsFromMeetingId.multiple == false && Object.keys(getMeetingsFromMeetingId.detail).length > 0) {
            let data = await this.getJwtToken(token, 'start', this.state.meeting_password);
            let current_meeting_data = getMeetingsFromMeetingId
            this.setState({
                current_meeting_data: getMeetingsFromMeetingId
            })
            localStorage.setItem("current_meeting_data", JSON.stringify(current_meeting_data))
            this.redirectConf(data, 'start')
        } else {
            toast.dismiss();
            toast.error(MESSAGES.meetingAlreadyInProgress, {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }

    myJoinSubmitHandler = async () => {
        let OneCloudMaxUserLimit = 0;
        let GuestMaxUserLimit = 0;
        let token = await getAuthToken();
        let getMeetingsFromMeetingId = await this.getMeetingsFromMeetingId(token, this.state.joincname)
        let getFeatureFromMeetingId = await this.getFeatureFromMeetingId(token, this.state.joincname)

        if (getMeetingsFromMeetingId.multiple == false && getMeetingsFromMeetingId.detail.auth_user == false) {
            GuestMaxUserLimit = getFeatureFromMeetingId.Result.web_participants
        }
        else if (getMeetingsFromMeetingId.multiple == false && getMeetingsFromMeetingId.detail.auth_user == true) {
            OneCloudMaxUserLimit = getFeatureFromMeetingId.Result.web_participants
        }

        if (getMeetingsFromMeetingId.multiple == false && Object.keys(getMeetingsFromMeetingId.detail).length == 0) {
            if (this.state.cname === this.state.joincname) {
                toast.dismiss();
                toast.error(MESSAGES.useStartMeeting, {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            } else {
                let data = await this.getJwtToken(token, 'join', this.state.meeting_password);
                this.redirectConf(data, 'join')
            }
        } else if (getMeetingsFromMeetingId.multiple == false && Object.keys(getMeetingsFromMeetingId.detail).length > 0 && getMeetingsFromMeetingId.detail.status == "I") {
            if (getMeetingsFromMeetingId.detail.auth_user == false && getMeetingsFromMeetingId.detail.current_attendees < GuestMaxUserLimit) {
                let data = await this.getJwtToken(token, 'join', this.state.meeting_password);
                this.redirectConf(data, 'join')
            } else if (getMeetingsFromMeetingId.detail.auth_user == true && getMeetingsFromMeetingId.detail.current_attendees < OneCloudMaxUserLimit) {
                if (this.state.joincname == localStorage.getItem('meetingUrlLink')) {
                    let data = await this.getJwtToken(token, 'start', this.state.meeting_password);
                    this.redirectConf(data, 'start')
                } else {
                    let data = await this.getJwtToken(token, 'join', this.state.meeting_password);
                    this.redirectConf(data, 'join')
                }

            } else {
                toast.dismiss();
                toast.error(MESSAGES.maxParticipant, {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            }
        } else {
            toast.dismiss();
            toast.error(MESSAGES.cannotJoinMeeting, {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }

    getMeetingsFromMeetingId = async (token, meeting_id) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(backendMeetingApi + "/" + meeting_id, {
                method: 'GET',
                headers: myHeaders,
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log(error)
        }
    }

    getFeatureFromMeetingId = async (token, meeting_id) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(getFeatureFromMeetingIdApi, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify({
                    current_meeting_id: meeting_id,
                })
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log(error)
        }
    }

    createBackendMeeting = async (token, meetingUrl) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(backendMeetingApi, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify({
                    meeting_id: localStorage.getItem("meetingUrlLink"),
                    meeting_name: this.state.user_detail.display_name + "'s Room",
                    oc_user: this.state.user_detail.id,
                    current_attendees: 1, // NOTE: Need to check 
                    total_attendees: 1, // NOTE: Need to check 
                    auth_user: true,
                    max_limit_reached: false,
                    status: 'I',
                    is_scheduled: false,
                    meeting_url: this.state.meetingUrl
                }),
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log(error)
        }
    }

    updateBackendMeeting = async (token, meeting_obj) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(backendMeetingApi + '/' + '4', {
                method: 'PUT',
                headers: myHeaders,
                body: JSON.stringify(meeting_obj),
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log(error)
        }
    }

    getJwtToken = async (token, participant, meeting_password) => {
        let room_name = localStorage.getItem("meetingUrlLink")
        let moderator = true
        if (participant === "join") {
            room_name = this.state.joincname
            moderator = false
        }
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(gettoken, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify({
                    room: room_name,
                    is_mod: moderator,
                    meeting_password: meeting_password
                }),
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log(error)
        }
    }

    redirectConf = (token, participant) => {
        let cname;
        if (participant === 'start') {
            cname = localStorage.getItem("meetingUrlLink")
        }
        else if (participant === 'join') {
            cname = this.state.joincname
        }
        this.props.history.push('/startconference/' + cname + '/' + this.state.s_audio + '/' + this.state.s_video + '/' + token.jwt_token);
    }

    handleChange = (event) => {
        const value = event.target.value;
        this.setState({
            [event.target.name]: value
        });
    }

    createdDate = (createdDate) => {
        let formatedCreatedDate = moment(createdDate).format('dddd, MMMM DD YYYY');
        return formatedCreatedDate;
    }
    createdDateWthoutTime = (createdDate) => {
        let formatedCreatedDate = moment(createdDate).format('MM/DD/YY');
        return formatedCreatedDate;
    }
    createdTime = (createdDate, mins) => {

        let startTime = moment(createdDate).format('h:mmA');

        var date = moment(startTime, "hh:mm A")
            .add(mins, 'minutes')
            .format('h:mmA');

        return `${startTime}-${date}`;

    }
    createdTimeMeet = (createdDate) => {
        let startTime = moment(createdDate).format('h:mm A');
        return startTime;
    }

    getTimeFromMins(mins) {
        var hours = Math.floor(mins / 60);
        var minutes = mins % 60;
        if (minutes.toString().length === 1) {

            minutes = `0${minutes}`
        }
        return hours + ":" + minutes;

    }
    getRecordingDuration = (duration) => {
        duration = parseFloat(duration) * 1000
        const tempTime = moment.duration(duration);
        if (tempTime.hours() > 0 && tempTime.minutes() > 0) { return tempTime.hours() + " hr " + tempTime.minutes() + " min" }
        else if (tempTime.hours() > 0 && tempTime.minutes() == 0) { return tempTime.hours() + " hr" }
        else if (tempTime.minutes() > 0 && tempTime.seconds() > 0) { return tempTime.minutes() + " min " + tempTime.seconds() + " sec" }
        else if (tempTime.minutes() > 0 && tempTime.seconds() == 0) { return tempTime.minutes() + " min " }
        else if (tempTime.seconds() > 0) { return tempTime.seconds() + " sec " }
        else { return "0" + " sec " }
    }



    download_file = (e, filePath, fileName, id_) => {
        e.preventDefault();
        try {
            const link = document.createElement('a');
            link.href = `${downloadFile}/${id_}/${this.state.userToken.token}`;
            document.body.appendChild(link);
            link.click();
            link.parentNode.removeChild(link);
        } catch (error) {
            console.log(error)
        }
    }



    meetingDuration = (startTime, endTime) => {
        const now = new Date(startTime)
        const then = new Date(endTime)
        const duration = then.getTime() - now.getTime()
        const tempTime = moment.duration(duration);
        if (tempTime.hours() > 0 && tempTime.minutes() > 0) { return tempTime.hours() + " hr " + tempTime.minutes() + " min" }
        else if (tempTime.hours() > 0 && tempTime.minutes() == 0) { return tempTime.hours() + " hr" }
        else if (tempTime.minutes() > 0 && tempTime.seconds() > 0) { return tempTime.minutes() + " min " + tempTime.seconds() + " sec" }
        else if (tempTime.minutes() > 0 && tempTime.seconds() == 0) { return tempTime.minutes() + " min " }
        else if (tempTime.seconds() > 0) { return tempTime.seconds() + " sec " }
        else { return "0" + " sec " }
    }

    meetingAttendees = (total_attendees) => {
        if (total_attendees <= 1) {
            return total_attendees + " Attendee"
        } else {
            return total_attendees + " Attendees"
        }
    }

    meetingInvites = (total_attendees) => {
        if (total_attendees <= 1) {
            return total_attendees + " Invite"
        } else {
            return total_attendees + " Invites"
        }
    }

    showParticipantList = (event, keyId) => {
        const { showParticipantList } = this.state;
        this.setState({
            newInvitee: [],
            showMeetnigInviteListId: keyId,
            showParticipantList: !showParticipantList,
        });
    }

    updateUsers = (value) => {
        this.setState({
            newInvitee: value
        });
    }

    handleIsPassword = (passwordStatus) => {
        this.setState({
            meeting_password: passwordStatus
        });
    }

    fetchMeetingRecording = async (index) => {
        if (index == 1) {
            this.setState({
                LoaderMsg: true,
                showContent: false,
                fetching_Data: MESSAGES.fetchingRecordingMsg
            })
            let token = await getAuthToken();
            await this.getMeetingRecording(token, this.state.user_auth_detail.username);
        }
        ReactTooltip.rebuild()
    }


    getMeetingRecording = async (token, username) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(getRecordingUrl, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify({
                    username: username
                }),
            })
            if (result.status === 200) {
                const data = await result.json()
                this.setState({
                    LoaderMsg: false,
                    showContent: true,
                    meetingRecording: data,
                    showRecordingDetails: true,
                })
                localStorage.setItem('meetingRecording', JSON.stringify(data));
                return data
            } else {
                toast.dismiss();
                toast.error(MESSAGES.fetchingRecordingErrorMsg, {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                this.setState({
                    LoaderMsg: true,
                    showContent: false,
                    fetching_Data: MESSAGES.fetchingRecordingErrorMsg
                })
                return
            }
        } catch (error) {
        }
    }

    render() {


        let userId = JSON.stringify(this.state.webinarData)
        var currentIsoDate = moment().format('YYYY-MM-DDTHH:mm:ss');

        var myDate = new Date("2012-02-10T13:19:11+0000");
        var result = myDate.getTime();
       

        var upcomingwebniar=[]

      
      
        var pastWebinar = []

        let pastWebinar_ = this.state.webinarData && this.state.webinarData.map(webinar => {
            
            var time = new Date(webinar.start_time);
            
            time.setMinutes(time.getMinutes() + webinar.duration);
            var newEndTime = time;
            var currentdateTime = new Date();
            
            if (newEndTime < currentdateTime) {

                pastWebinar.push(webinar);
            }
            else{
                upcomingwebniar.push(webinar);
            }

          
        })









        let { users_scheduled_meeting_details, users_meeting_details } = this.state
        const inProgressMeetings = users_meeting_details.filter((meeting_inProgress) => {
            return meeting_inProgress.status == "I"
        })
        const inProgressNotScheduledMeetings = inProgressMeetings.filter((meeting_inProgress) => {
            return meeting_inProgress.is_scheduled == false
        })
        const isScheduledProgressMeeting = inProgressMeetings.filter((scheduled_meeting) => {
            return scheduled_meeting.is_scheduled == true
        })
        const myMeetingsData = [];
        isScheduledProgressMeeting.forEach(elem => {
            users_scheduled_meeting_details = users_scheduled_meeting_details.filter(s_elem => {
                return s_elem.id != elem.sch_ref_id
            })
            myMeetingsData.push(elem)
        })
        myMeetingsData.push(...users_scheduled_meeting_details)
        myMeetingsData.push(...inProgressNotScheduledMeetings)

        return (
            <div>
                <div className="appContainer" >

                    <div className="mainContainer">
                        <Header currentMeetingPassword={this.handleIsPassword} />


                    </div>



                    <div className="container-fluid meetings-Wrapper">
                        {this.state.show === true ?
                            <div class="modal-dialog modal-lg" >


                                <WebinarScheduleModal show={this.state.show}
                                    setModaCloselData={this.setModaCloselData}
                                    webinarID={this.state.webinareditID}
                                />

                                {/* </Modal> */}
                            </div>
                            : ""}

                        <div className="meetings-Wrapper">
                            {this.state.analyticsShow === true ?
                                <div class="modal-dialog modal-lg" >
                                    <AnalyticsModal
                                        analyticsShow={this.state.analyticsShow}
                                        closeAnalytics={this.closeAnalytics}
                                        webinarId={this.state.webinarId}
                                        meetingId={this.state.meetingId}
                                    />

                                </div>
                                : ""}

                        </div>
                        <div className="meetings-container" >

                            <div className="col-sm-12 col-md-2 meetings-button meetings-button1 img-fluid"
                                onClick={this.myStartSubmitHandler}>


                                <  img className={this.state.setIsShownDesktop ? "imddesktopBlue" : "imddesktop"}
                                    onMouseEnter={() => this.setState({ setIsShownDesktop: true })}
                                    onMouseLeave={() => this.setState({ setIsShownDesktop: false })}
                                    src={this.state.setIsShownDesktop ? DesktopBlueIcon : deskTopImg} />
                                <br />


                                <span className="text-dark" style={{ marginTop: "5px", fontSize: "14px" }}>{MESSAGES.startMeeting}</span></div>

                            <div className="col-sm-12 col-md-2 meetings-button img-fluid"
                                onClick={this.setModalData}>
                                <img className="imgcal"
                                    onMouseEnter={() => this.setState({ setIsShownSchedule: true })}
                                    onMouseLeave={() => this.setState({ setIsShownSchedule: false })}
                                    src={this.state.setIsShownSchedule ? calamderImgBlue : calamderImg} />
                                <br />
                                <span className="text-dark textMenu">Schedule Meeting</span>

                            </div>
                            {/* <div className="col-sm-12 col-md-2 meetings-button img-fluid" onClick={() => this.props.history.push('/schedule/meeting/')}><img className="imgcal" src={calamderImg} />
                                    <br />
                                    <span className="text-dark textMenu">{MESSAGES.scheduleMeeting}</span>

                                </div> */}

                            <div className="col-sm-12 col-md-2 meetings-button img-fluid" onClick={this.showJoinMeeting}>
                                <img className="joinmeet"
                                    onMouseEnter={() => this.setState({ setIsShown: true })}
                                    onMouseLeave={() => this.setState({ setIsShown: false })}
                                    src={this.state.setIsShown ? joinImgBlue : joinImg} />
                                <br />
                                <span className="text-dark textMenu">{MESSAGES.joinMeeting}</span>
                                <div className={`popupBox JoinMeetingPopup ${this.state.joinMeetingPopup ? "d-block" : ''}`}>
                                    <AvForm className="" onValidSubmit={this.myJoinSubmitHandler}>
                                        <AvField
                                            name="joincname"
                                            className="form-control mt-1"
                                            type="text"
                                            errorMessage="Please enter a valid ID."
                                            placeholder="Enter HDMeet ID"
                                            validate={{
                                                required: { value: true, errorMessage: 'No space & special characters allowed.' },
                                                pattern: { value: '/^[a-zA-Z0-9,-_]+$/', errorMessage: 'No space & special characters allowed.' }
                                            }}
                                            value={this.state.joincname}
                                            onChange={this.handleChange}
                                            autoFocus
                                        />
                                        <div className="button d-inline-block popupBoxCancelBtn mr-3" onClick={this.popupBoxCancelBtn}>{MESSAGES.cancel}</div>
                                        <button className="popupJoinBtn textMenu" >{MESSAGES.joinMeeting}</button>
                                    </AvForm>
                                </div>
                            </div>

                            {/* <div className="col-sm-12 col-md-2 meetings-button img-fluid" onClick={this.setModalData}><img className="imgcal" src={calamderImg} />
                                    <br />
                                    <span className="text-dark textMenu">Schedule Meeting 1</span>

                                </div> */}

                        </div>
                    </div>

                    <div className="mainContainer container">
                        <div className="dbMeetingContainer dashboard-container">
                            <div>
                                <Tabs
                                    defaultIndex={0}
                                    onSelect={this.fetchMeetingRecording}
                                >
                                    <TabList className="tab-box">
                                        <Tab>{MESSAGES.myMeeting}</Tab>
                                        <Tab>{MESSAGES.recordings}</Tab>
                                        <Tab>{MESSAGES.transcripts}</Tab>
                                        <Tab>{MESSAGES.webniar}</Tab>
                                    </TabList>

                                    <TabPanel className="dashboard-upcoming">
                                        <a className="refreshBtn"

                                            onClick={this.updateMeeting}
                                            data-tip={MESSAGES.refreshIcon}
                                            data-for='refreshIcon'>
                                            <img className="refreshBtnCursor"

                                                src={refreshIcon} alt="update Scheduled Meetings" />
                                        </a>
                                        <div className="webinarTable">

                                            <div className="row" style={{ overflowX: "auto" }}>
                                                <div className="col-12">
                                                    <div className="col-12" style={{
                                                        paddingLeft: "0px",
                                                        paddingTop: "29px",
                                                        paddingRight: "0px"
                                                    }}>
                                                        {Object.keys(myMeetingsData).length == 0 ?
                                                            <div style={{ width: "100%" }}>
                                                                <h5 className="p-2 text-dark webinarTitle" style={{ background: "#ECF1FA", lineHeight: 2.5, fontSize: "12px", marginBottom: "27px" }}> No Upcoming Meetings For Now</h5>
                                                                <h5 style={{ background: "#ECF1FA" }} className="p-2 text-dark webinarTitle" style={{ fontSize: "12px" }} > Start a Meeting by Clicking "Schedule Meeting" Button</h5>
                                                            </div> :
                                                            <div style={{ width: "100%" }}>
                                                                <p style={{ color: "#000000", fontSize: "14px", fontWeight: 500, paddingLeft: "8px" }}>Upcoming Meetings</p>
                                                                <table className="table table-striped  table-borderless text-dark">

                                                                    <thead className="webinarheader">
                                                                        <tr>

                                                                            <th style={{ fontWeight: 400 }} scope="col">Date</th>
                                                                            <th style={{ fontWeight: 400 }} scope="col">Time</th>
                                                                            <th style={{ fontWeight: 400 }} scope="col">Meeting Name</th>
                                                                            <th style={{ fontWeight: 400 }} scope="col">Duration of Meeting</th>
                                                                            <th style={{ fontWeight: 400 }} scope="col">Number of Registrations</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody class="webinarbody">
                                                                        {Object.keys(myMeetingsData).slice(0, 10).map((keyName, keyId) => {
                                                                            return (
                                                                                <tr key={keyId}>
                                                                                    <td > {myMeetingsData[keyName].hasOwnProperty('is_scheduled') ?
                                                                                        this.createdDate(myMeetingsData[keyName].date_created)
                                                                                        :
                                                                                        this.createdDate(myMeetingsData[keyName].start_time)
                                                                                    }
                                                                                    </td>
                                                                                    <td >{myMeetingsData[keyName].hasOwnProperty('is_scheduled') ?
                                                                                        this.createdTimeMeet(myMeetingsData[keyName].date_created)
                                                                                        :
                                                                                        this.createdTimeMeet(myMeetingsData[keyName].start_time)
                                                                                    }
                                                                                    </td>
                                                                                    <td> {myMeetingsData[keyName].hasOwnProperty('is_scheduled') ?
                                                                                        <a
                                                                                            href={myMeetingsData[keyName].meeting_url}
                                                                                            className="rejoinMeetingLink"
                                                                                            data-tip="Click here to start this meeting"
                                                                                            data-for='inProgress'>
                                                                                            {myMeetingsData[keyName].meeting_name == null ? this.state.user_auth_detail.displayName : myMeetingsData[keyName].meeting_name}
                                                                                        </a>
                                                                                        :
                                                                                        <a
                                                                                            href={myMeetingsData[keyName].host_invitation_link}
                                                                                            className="rejoinMeetingLink"
                                                                                            data-tip="Click here to start this meeting"
                                                                                            data-for='inProgress' >
                                                                                            {myMeetingsData[keyName].subject == null ? this.state.user_auth_detail.displayName : myMeetingsData[keyName].subject}
                                                                                        </a>
                                                                                    }
                                                                                    </td>
                                                                                    <td>{myMeetingsData[keyName].hasOwnProperty('status') ?
                                                                                        <span>{myMeetingsData[keyName].status == "I" ? "In Progress"
                                                                                            : this.meetingDuration(myMeetingsData[keyName].date_created, myMeetingsData[keyName].date_ended)
                                                                                        }</span>
                                                                                        : <span>
                                                                                            {this.meetingDuration(myMeetingsData[keyName].start_time, myMeetingsData[keyName].end_time)}
                                                                                        </span>
                                                                                    }</td>
                                                                                    <td>{myMeetingsData[keyName].hasOwnProperty('total_attendees') ?
                                                                                        <span>{this.meetingAttendees(myMeetingsData[keyName].total_attendees)}</span>
                                                                                        :
                                                                                        <div>
                                                                                            <span>{this.meetingInvites(myMeetingsData[keyName].participants.length)}</span>
                                                                                            <a onClick={(event) => this.showParticipantList(event, keyId)} data-tip="Add Participant" data-for="addIcon"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>
                                                                                            {this.state.showParticipantList && this.state.showMeetnigInviteListId == keyId ?
                                                                                                <div className="addParticipant">
                                                                                                    <div style={{ display: 'flex', borderBottom: '1px solid #dcdcdc', position: 'relative' }}>

                                                                                                        <ReactMultiEmail
                                                                                                            name="emails"
                                                                                                            id="emails"
                                                                                                            emails={this.state.newInvitee}
                                                                                                            onChange={this.updateUsers}
                                                                                                            onBlur={this.validateInput}
                                                                                                            placeholder="Add New Attendees"
                                                                                                            validateEmail={email => {
                                                                                                                return isEmail(email);
                                                                                                            }}
                                                                                                            getLabel={(email, index, removeEmail) => {
                                                                                                                return <div data-tag key={index}>
                                                                                                                    {email}
                                                                                                                    <span data-tag-handle onClick={() => removeEmail(index)}>&times;</span>
                                                                                                                </div>;
                                                                                                            }}
                                                                                                        />
                                                                                                        <span className="addInviteeBtn" onClick={() => this.updateInvitee(myMeetingsData[keyName])}><img src={SendIcon} alt="send invitee"></img></span>

                                                                                                    </div>
                                                                                                    <ul className="participantListSection">
                                                                                                        {myMeetingsData[keyName].participants.map((participant, item) =>
                                                                                                            <li key={item}>
                                                                                                                {participant}
                                                                                                            </li>
                                                                                                        )}
                                                                                                    </ul>
                                                                                                </div>
                                                                                                : null}
                                                                                        </div>
                                                                                    }
                                                                                    </td>

                                                                                </tr>
                                                                            )
                                                                        })}
                                                                    </tbody>

                                                                </table>

                                                            </div>

                                                        }
                                                        <div className="mt-4" style={{ width: "100%" }}>
                                                            <p className="pl-2" style={{ color: "#000000", fontSize: "14px", fontWeight: 500 }}>Past Meetings</p>
                                                            <table table className="table table-striped  table-borderless text-dark past-table">
                                                                <thead className="webinarheader">

                                                                    <tr >
                                                                        <th style={{ fontWeight: 400 }} scope="col">Date</th>
                                                                        <th style={{ fontWeight: 400 }} scope="col">Time</th>
                                                                        <th style={{ fontWeight: 400 }} scope="col">Meeting Name</th>
                                                                        <th style={{ fontWeight: 400 }} scope="col">Duration of Meeting</th>
                                                                        <th style={{ fontWeight: 400 }} scope="col">Number of Attendees</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody tbody className="webinarbody">
                                                                    {Object.keys(users_meeting_details).length == 0 ? <h5>{MESSAGES.noMeeting}</h5> :
                                                                        Object.keys(users_meeting_details).filter(meeting => users_meeting_details[meeting].status == "C").slice(0, 3).map((keyName, i) => (
                                                                            <tr key={i}>
                                                                                <td scope="row">{this.createdDate(users_meeting_details[keyName].date_created)}</td>
                                                                                <td>{this.createdTimeMeet(users_meeting_details[keyName].date_created)}</td>
                                                                                <td className="showLimited">{users_meeting_details[keyName].meeting_name == "" || users_meeting_details[keyName].meeting_name == null ? "-"
                                                                                    : users_meeting_details[keyName].meeting_name
                                                                                }</td>
                                                                                <td>{users_meeting_details[keyName].status == "I" ? "In Progress"
                                                                                    : this.meetingDuration(users_meeting_details[keyName].date_created, users_meeting_details[keyName].date_ended)
                                                                                }</td>
                                                                                <td>{this.meetingAttendees(users_meeting_details[keyName].total_attendees)}</td>


                                                                            </tr>
                                                                        ))
                                                                    }
                                                                </tbody>
                                                            </table>
                                                            {/* <div className="seeAll"> See All Past Meetings</div> */}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>

                                    <TabPanel>
                                        <div className="tab-content-container">
                                            {this.state.LoaderMsg ?
                                                <div className="text-center">{this.state.fetching_Data}</div>
                                                : null}
                                            {this.state.showContent ?
                                                <div>
                                                    <div className="text-right">
                                                        <a style={{ cursor: "pointer" }}
                                                            data-tip={MESSAGES.refreshIcon} data-for='refreshIcon'><img style={{ width: "15px", marginRight: "-11px" }} src={refreshIcon} alt="update Scheduled Meetings" /></a>
                                                    </div>
                                                    <table className="table table-borderless text-dark">

                                                        <tr style={{ borderTop: "none", cursor: "pointer" }}>
                                                            <th onClick={this.reverseDate} scope="col">Date/Time <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-down-up" viewBox="0 0 16 16">
                                                                <path fill-rule="evenodd" d="M11.5 15a.5.5 0 0 0 .5-.5V2.707l3.146 3.147a.5.5 0 0 0 .708-.708l-4-4a.5.5 0 0 0-.708 0l-4 4a.5.5 0 1 0 .708.708L11 2.707V14.5a.5.5 0 0 0 .5.5zm-7-14a.5.5 0 0 1 .5.5v11.793l3.146-3.147a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 .708-.708L4 13.293V1.5a.5.5 0 0 1 .5-.5z" />
                                                            </svg></th>
                                                            <th scope="col">Meeting ID</th>
                                                            <th scope="col">Duration</th>
                                                            <th scope="col">Recording</th>
                                                        </tr>
                                                        {
                                                            this.state.meetingRecording.recordings.length == 0 ? <h5>{MESSAGES.noMeeting}</h5> :
                                                                this.state.reverse === false ? this.state.meetingRecording.recordings.map((elem, item) => {
                                                                    return (
                                                                        <tbody className="tbody">
                                                                            <tr className="text-dark forgerborder">
                                                                                <td >{this.createdDate(elem.recording_date)}</td>
                                                                                <td>{elem.meeting_id}</td>
                                                                                <td>{this.getRecordingDuration(elem.duration)}</td>
                                                                                <td><a href={elem.url} target='_blank' className="downloadMeetingBtn" onClick={(e) => this.download_file(e, elem.file_path, elem.name, elem.id, "download")}>{MESSAGES.recording} <img src={DownloadIcon} className="ml-1" alt="download recording" /></a></td>
                                                                            </tr>
                                                                        </tbody>)
                                                                }) : this.state.reverse === true ? this.state.meetingRecording.recordings.reverse().map((elem, item) => {
                                                                    return (
                                                                        <tbody className="tbody">
                                                                            <tr className="text-dark forgerborder">
                                                                                <td >{this.createdDate(elem.recording_date)}</td>
                                                                                <td>{elem.meeting_id}</td>
                                                                                <td>{this.getRecordingDuration(elem.duration)}</td>
                                                                                <td><a href={elem.url} target='_blank' className="downloadMeetingBtn" onClick={(e) => this.download_file(e, elem.file_path, elem.name, elem.id, "download")}>{MESSAGES.recording} <img src={DownloadIcon} className="ml-1" alt="download recording" /></a></td>
                                                                            </tr>
                                                                        </tbody>)
                                                                }) : null}
                                                    </table>
                                                </div>
                                                : null}
                                        </div>
                                    </TabPanel>
                                    <TabPanel>
                                        <div>
                                            <h5 className="d-flex justify-contant-start ml-5 text-dark">Upcoming transcripts</h5>

                                        </div>
                                    </TabPanel>
                                    <TabPanel className="upcoming-webinars">
                                        <a href="" className="refreshBtn" onClick={this.updateWebinar} ><img src={refreshIcon} alt="update Scheduled Meetings" className="refreshBtnCursor" /></a>
                                        <div className="webinarTable">
                                            <div className="row" style={{ overflowX: "auto" }}>
                                                <div className="col-12">

                                                    <h5 className="p-2 mt-4 text-dark webinarTitle"> Upcoming Webinars</h5>

                                                    {upcomingwebniar && upcomingwebniar == 0 ?
                                                        <div className="text-dark pl-2">You do not have any upcoming webinar scheduled</div> :
                                                        <div className="table-responsive">
                                                            <table className="table table-striped  table-borderless text-dark">
                                                                <thead class="webinarheader" >
                                                                    <tr>
                                                                        <th style={{ fontWeight: 400 }} scope="col">Date</th>
                                                                        <th style={{ fontWeight: 400 }} scope="col">Time</th>
                                                                        <th style={{ fontWeight: 400 }} scope="col">Webinar Name</th>
                                                                        <th style={{ fontWeight: 400 }} scope="col">Registration Link</th>
                                                                        <th style={{ fontWeight: 400 }} scope="col">Number of Modetators</th>
                                                                        <th style={{ fontWeight: 400 }} scope="col">Number of Registrations</th>
                                                                        {/* <th scope="col"></th> */}
                                                                    </tr>
                                                                </thead>


                                                                <tbody class="webinarbody">
                                                                    {
                                                                        upcomingwebniar && upcomingwebniar.map((elem, index) => {

                                                                            return (
                                                                                <tr key={index}>

                                                                                    <td scope="row" >{this.createdDateWthoutTime(elem.start_time)}</td>


                                                                                    <td>{this.createdTime(elem.start_time, elem.duration)}</td>
                                                                                    <td >
                                                                                        <a data-placement="top" data-toggle="tooltip" title="Click here to start this webinar"
                                                                                            href={elem.webinar_meeting_url}
                                                                                            data-for='statWebinar'>
                                                                                            {elem.title}
                                                                                        </a>

                                                                                    </td>
                                                                                    {/* <td className="showLimited"

                                                                                            

                                                                                        >

                                                                                            
                                                                                            {elem.title}
    
                                                                                        </td> */}


                                                                                    <td
                                                                                        onClick={() => localStorage.setItem("webinarId", elem.id)}
                                                                                    style={{padding:".35rem" }}
                                                                                    ><Link style={{ color: "#38A6DE" }}

                                                                                        to={"/register/" + elem.registration_link.slice(elem.registration_link.lastIndexOf('/') + 1, elem.registration_link.length)}

                                                                                    >
                                                                                            {elem.registration_link}
                                                                                        </Link>
                                                                                        <CopyToClipboard text={elem.registration_link}
                                                                                        >
                                                                                            <i
                                                                                                onClick={() => this.tempFunc(index)} class="fa fa-clone" style={{ color: "#38A6DE" }} aria-hidden="true">
                                                                                            </i>

                                                                                        </CopyToClipboard>
                                                                                        {this.state.copy === true && this.state.index === index ? <span><p className="text-success">copied</p></span> : ""}
                                                                                    </td>

                                                                                    <td>{elem.moderators.length}</td>
                                                                                    <td>{elem.registration_count} <i onClick={() => this.showRegDetails(elem.id)}
                                                                                        className="fa fa-eye"
                                                                                        aria-hidden="true"></i></td>
                                                                                    <td style={{ width: "100px" }}>

                                                                                        <img
                                                                                            onClick={() => this.setModalData(elem.id)}
                                                                                            src={EditIcon} />
                                                                                       



                                                                                        <i class="fa fa-times ml-4" onClick={() => this.deleteWebinarConf(elem.id)} style={{ color: "red" }} aria-hidden="true"></i>

                                                                                    </td>
                                                                                </tr>

                                                                            )
                                                                        }

                                                                        )}
                                                                </tbody>


                                                            </table>
                                                        </div>
                                                    }
                                                </div>
                                            </div>



                                            <div className="row">
                                                <div className="col-12">
                                                    <h5 className="pl-2 p-1 text-dark webinarTitle mt-1">Past Webinars</h5>
                                                    <div className="d-flex mb-2">


                                                        <div className="p-1">
                                                            <button className="filterBtn"
                                                                onClick={() => this.filterData()}>Filter</button>
                                                        </div>

                                                        <div className="form-group ml-2 mt-1">

                                                            <select className="form-control " id="exampleFormControlSelect1" style={{ fontSize: "12px", width: "85%" }}
                                                                onChange={(e) => this.getMonth(e)}
                                                            >

                                                                <option value="">mm</option>
                                                                <option value="Jan">January</option>
                                                                <option value="Feb">February</option>
                                                                <option value="Mar">March</option>
                                                                <option value="Apr">April</option>
                                                                <option value="May">May</option>
                                                                <option value="Jun">June</option>
                                                                <option value="Jul">July</option>
                                                                <option value="Aug">August</option>
                                                                <option value="Sep">September</option>
                                                                <option value="Oct">October</option>
                                                                <option value="Nov">November</option>
                                                                <option value="Dec">December</option>


                                                            </select>
                                                        </div>
                                                        <div className="form-group ml-2 mt-1">

                                                            <select className="form-control " id="exampleFormControlSelect1" style={{ fontSize: "12px" }}

                                                                onChange={(e) => this.getDay(e)}
                                                            >

                                                                <option value="">dd</option>
                                                                <option value="01">01</option>
                                                                <option value="02">02</option>
                                                                <option value="03">03</option>
                                                                <option value="04">04</option>
                                                                <option value="05">05</option>
                                                                <option value="06">06</option>
                                                                <option value="07">07</option>
                                                                <option value="08">08</option>
                                                                <option value="09">09</option>
                                                                <option value="10">10</option>
                                                                <option value="11">11</option>
                                                                <option value="12">12</option>
                                                                <option value="13">13</option>
                                                                <option value="14">14</option>
                                                                <option value="15">15</option>
                                                                <option value="16">16</option>
                                                                <option value="17">17</option>
                                                                <option value="18">18</option>
                                                                <option value="19">19</option>
                                                                <option value="20">20</option>
                                                                <option value="21">21</option>
                                                                <option value="22">22</option>
                                                                <option value="23">23</option>
                                                                <option value="24">24</option>
                                                                <option value="25">25</option>
                                                                <option value="26">26</option>
                                                                <option value="27">27</option>
                                                                <option value="28">28</option>
                                                                <option value="29">29</option>
                                                                {[
                                                                    "Jan",
                                                                    "Mar",
                                                                    "Apr",
                                                                    "May",
                                                                    "Jun",
                                                                    "Jul",
                                                                    "Aug",
                                                                    "Sep",
                                                                    "Oct",
                                                                    "Nov",
                                                                    "Dec",
                                                                ].includes(this.state.month) ? (
                                                                        <option value="30">30</option>
                                                                    ) : (
                                                                        ""
                                                                    )}
                                                                {[
                                                                    "Jan",
                                                                    "Mar",
                                                                    "May",
                                                                    "Jul",
                                                                    "Aug",
                                                                    "Oct",
                                                                    "Dec",
                                                                ].includes(this.state.month) ? (
                                                                        <option value="31">31</option>
                                                                    ) : (
                                                                        ""
                                                                    )}
                                                            </select>

                                                        </div>
                                                        <div className="form-group ml-2 mt-1">

                                                            <select className="form-control " id="exampleFormControlSelect1" style={{ fontSize: "12px" }}
                                                                onChange={(e) => this.getyearfrm(e)}
                                                            >


                                                                <option >yy</option>
                                                                <option value={this.state.years[0]}>{this.state.years[0]}</option>
                                                                <option value={this.state.years[1]}>{this.state.years[1]}</option>
                                                                <option value={this.state.years[2]}>{this.state.years[2]}</option>
                                                                <option value={this.state.years[3]}>{this.state.years[3]}</option>
                                                                <option value={this.state.years[4]}>{this.state.years[4]}</option>
                                                                <option value={this.state.years[5]}>{this.state.years[5]}</option>
                                                                <option value={this.state.years[6]}>{this.state.years[6]}</option>


                                                            </select>
                                                        </div>
                                                        <div className="ml-2 mt-1" style={{ width: "16px", color: "black" }}>
                                                            <hr />
                                                        </div>


                                                        <div className="form-group ml-2 mt-1">

                                                            <select className="form-control " id="exampleFormControlSelect1" style={{ fontSize: "12px", width: "85%" }}
                                                                onChange={(e) => this.getMonthTo(e)}
                                                            >

                                                                <option value="">mm</option>
                                                                <option value="Jan">January</option>
                                                                <option value="Feb">February</option>
                                                                <option value="Mar">March</option>
                                                                <option value="Apr">April</option>
                                                                <option value="May">May</option>
                                                                <option value="Jun">June</option>
                                                                <option value="Jul">July</option>
                                                                <option value="Aug">August</option>
                                                                <option value="Sep">September</option>
                                                                <option value="Oct">October</option>
                                                                <option value="Nov">November</option>
                                                                <option value="Dec">December</option>


                                                            </select>
                                                        </div>
                                                        <div className="form-group ml-2 mt-1">

                                                            <select className="form-control " id="exampleFormControlSelect1" style={{ fontSize: "12px" }}

                                                                onChange={(e) => this.getDayTo(e)}
                                                            >

                                                                <option value="">dd</option>
                                                                <option value="01">01</option>
                                                                <option value="02">02</option>
                                                                <option value="03">03</option>
                                                                <option value="04">04</option>
                                                                <option value="05">05</option>
                                                                <option value="06">06</option>
                                                                <option value="07">07</option>
                                                                <option value="08">08</option>
                                                                <option value="09">09</option>
                                                                <option value="10">10</option>
                                                                <option value="11">11</option>
                                                                <option value="12">12</option>
                                                                <option value="13">13</option>
                                                                <option value="14">14</option>
                                                                <option value="15">15</option>
                                                                <option value="16">16</option>
                                                                <option value="17">17</option>
                                                                <option value="18">18</option>
                                                                <option value="19">19</option>
                                                                <option value="20">20</option>
                                                                <option value="21">21</option>
                                                                <option value="22">22</option>
                                                                <option value="23">23</option>
                                                                <option value="24">24</option>
                                                                <option value="25">25</option>
                                                                <option value="26">26</option>
                                                                <option value="27">27</option>
                                                                <option value="28">28</option>
                                                                <option value="29">29</option>
                                                                {[
                                                                    "Jan",
                                                                    "Mar",
                                                                    "Apr",
                                                                    "May",
                                                                    "Jun",
                                                                    "Jul",
                                                                    "Aug",
                                                                    "Sep",
                                                                    "Oct",
                                                                    "Nov",
                                                                    "Dec",
                                                                ].includes(this.state.monthTo) ? (
                                                                        <option value="30">30</option>
                                                                    ) : (
                                                                        ""
                                                                    )}
                                                                {[
                                                                    "Jan",
                                                                    "Mar",
                                                                    "May",
                                                                    "Jul",
                                                                    "Aug",
                                                                    "Oct",
                                                                    "Dec",
                                                                ].includes(this.state.monthTo) ? (
                                                                        <option value="31">31</option>
                                                                    ) : (
                                                                        ""
                                                                    )}
                                                            </select>

                                                        </div>
                                                        <div className="form-group ml-2 mt-1">

                                                            <select className="form-control " id="exampleFormControlSelect1" style={{ fontSize: "12px" }}
                                                                onChange={(e) => this.getyearTo(e)}
                                                            >
                                                                <option >yy</option>
                                                                <option value={this.state.years[0]}>{this.state.years[0]}</option>
                                                                <option value={this.state.years[1]}>{this.state.years[1]}</option>
                                                                <option value={this.state.years[2]}>{this.state.years[2]}</option>
                                                                <option value={this.state.years[3]}>{this.state.years[3]}</option>
                                                                <option value={this.state.years[4]}>{this.state.years[4]}</option>
                                                                <option value={this.state.years[5]}>{this.state.years[5]}</option>
                                                                <option value={this.state.years[6]}>{this.state.years[6]}</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div className="table-responsive">
                                                        <table className="table table-striped table-borderless text-dark webinarTitle">
                                                            <thead class="webinarheader">
                                                                <tr>
                                                                    <th style={{ fontWeight: 400 }} scope="col">Date</th>
                                                                    <th style={{ fontWeight: 400 }} scope="col">Time</th>
                                                                    <th style={{ fontWeight: 400 }} scope="col">Webinar Name</th>
                                                                    <th style={{ fontWeight: 400 }} scope="col">Duration of Webinar</th>
                                                                    <th style={{ fontWeight: 400 }} scope="col"> </th>
                                                                    <th style={{ fontWeight: 400 }} scope="col">Number of Modetators</th>
                                                                    <th style={{ fontWeight: 400 }} scope="col">Number of Registrations</th>
                                                                    <th style={{ fontWeight: 400 }} scope="col">Number of Attendees</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="webinarbody">
                                                                {this.state.filterPastWebinar && this.state.filterPastWebinar.length == 0 ? <div style={{
                                                                    width: "100%",
                                                                    margin: "20px"
                                                                }}><h3 style={{ fontSize: "12px" }}>No Data Found in Selected Date Range</h3></div> :
                                                                    this.state.filterPastWebinar && this.state.filterPastWebinar.length > 0 ? this.state.filterPastWebinar && this.state.filterPastWebinar.map((elem, index) => {

                                                                        return (

                                                                            <tr key={index}>

                                                                                <td scope="row">{this.createdDateWthoutTime(elem.start_time)}</td>


                                                                                <td>{this.createdTime(elem.start_time, elem.duration)}</td>
                                                                                <td className="showLimited">{elem.title}</td>
                                                                                <td >{this.getTimeFromMins(elem.duration)}</td>
                                                                                <td style={{padding:"0.35rem"}}>  <span className="analysisBtn" onClick={() => this.openAnalytics(elem.id, elem.meeting_id)}> See Analytics</span></td>
                                                                                <td>{elem.moderators.length}</td>
                                                                                <td>{elem.registration_count}</td>
                                                                                <td>{elem.attendee_count}</td>



                                                                            </tr>

                                                                        )
                                                                    }
                                                                    ) :

                                                                        pastWebinar && pastWebinar.map((elem, index) => {

                                                                            return (

                                                                                <tr key={index}>

                                                                                    <td scope="row">{this.createdDateWthoutTime(elem.start_time)}</td>


                                                                                    <td>{this.createdTime(elem.start_time, elem.duration)} </td>
                                                                                    <td className="showLimited">{elem.title}</td>
                                                                                    <td >{this.getTimeFromMins(elem.duration)}</td>
                                                                                    <td >  <span className="analysisBtn" onClick={() => this.openAnalytics(elem.id, elem.meeting_id)}> See Analytics</span></td>
                                                                                    <td>{elem.moderators.length}</td>
                                                                                    <td>{elem.registration_count}</td>
                                                                                    <td>{elem.attendee_count}</td>

                                                                                </tr>

                                                                            )
                                                                        }
                                                                        )}
                                                            </tbody>
                                                        </table>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </TabPanel>
                                </Tabs>

                                <Modal
                                    show={this.state.confirmChangeScopeModal}
                                    onHide={() => this.setState({ showAddUserModal: false, showDomainTable: false })}
                                    dialogClassName="modal-90w"
                                    aria-labelledby="confirmation To change Scope"
                                    size="md"
                                    centered
                                >
                                    <Modal.Body>
                                        <Row>
                                            <Col md="12">
                                                <p class="text-center">Are you sure, You want to delete this webinar ?</p>
                                            </Col>
                                        </Row>
                                        <Row className="justify-content-md-center">
                                            <Col md={{ span: 2 }}>
                                                <Button block size="sm" onClick={() => this.deleteWebinar(false)}>No</Button>
                                            </Col>
                                            <Col md={{ span: 2 }}>
                                                <Button block size="sm" onClick={() => this.deleteWebinar(true)}>Yes</Button>
                                            </Col>
                                        </Row>
                                    </Modal.Body>
                                </Modal>


                                <Modal
                                    show={this.state.openModalShowReg}
                                    onHide={() => this.setState({ showAddUserModal: false, showDomainTable: false })}
                                    dialogClassName="modal-90w"
                                    aria-labelledby="confirmation To change Scope"
                                    size="md"
                                    centered
                                >
                                    <Modal.Header onClick={() => this.closeRegModal()} closeButton style={{ background: "#18508D" }}>
                                        <Modal.Title style={{ lineHeight: 1, color: "#fff" }}  >Registration Details</Modal.Title>
                                    </Modal.Header>

                                    <Modal.Body>


                                        <div className="ml-2" style={{ width: "80%" }}>



                                            {
                                                this.state.regDetail.length == 0 ?

                                                    <div>No Data </div>

                                                    :

                                                    this.state.regDetail && this.state.regDetail.length > 0 && this.state.regDetail.map((elem, index) => {

                                                        return (
                                                            <ul>
                                                                < li kry={index}>
                                                                    {elem.full_name} ({elem.email})
                                                        </li>
                                                            </ul>
                                                        )

                                                    })}






                                        </div>





                                    </Modal.Body>
                                </Modal>
                            </div>
                        </div>
                    </div>

                    <Footer />
                    <ReactTooltip id='inProgress' />

                    <ReactTooltip id='scheduled' />
                    <ReactTooltip id='refreshIcon' />
                    <ReactTooltip id='addIcon' />
                    <ReactTooltip id='downloadRecordingIcon' />
                    <ReactTooltip id='statWebinar' />
                </div>
            </div >

        );
    }
}

export default Dashboard;
