import React, { Component } from 'react';
import Background from '../assets/images/background.png';
import EmailIcon from '../assets/images/emailIcon.png';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import TimeRange from 'react-time-range';
import moment from 'moment';
import { AvForm, AvField } from 'availity-reactstrap-validation';
import { toast } from 'react-toastify';
import { ReactMultiEmail, isEmail } from 'react-multi-email';
import Header from '../no-auth/header';
import jstz from 'jstz';
import './newDesign.css';
import {
    onlytoken,
    schedule,
    Baseurl_self,
    Baseurl_invite,
    timeDiffRange,
    userName,
    password,
    OneCloudGuestUserID
} from '../constant/index';
import { MESSAGES } from '../constant/messages'

class ScheduleMeeting extends Component {
    constructor(props) {
        super(props);
        this.state = {
            meeting_id: '',
            date: new Date(),
            start_time: moment(),
            end_time: moment().add(1, 'hours'),
            endTime: moment().add(1, 'hours'),
            timezone: '',
            host_name: '',
            host_email: '',
            emails: [],
            invitation_link: '',
            host_invitation_link: '',
            time_diff_range: timeDiffRange,
            sameTimeMsg: false,
            pastTimeMsg: false,
            isEmailsEmpty: false,
            // endTimeMsg : false,
            // meeting_password: localStorage.getItem('apiUserDetail') ? JSON.parse(localStorage.getItem('apiUserDetail')).settings.password : '',
            meeting_password: localStorage.getItem('apiUserDetail') ? (!JSON.parse(localStorage.getItem('apiUserDetail')).settings ? '' : (JSON.parse(localStorage.getItem('apiUserDetail')).settings.is_password ? JSON.parse(localStorage.getItem('apiUserDetail')).settings.password : '')) : "",
            apiUserDetail: localStorage.getItem("isAuthenticated") ? JSON.parse(localStorage.getItem("apiUserDetail")) : {},
            meeting_name: '',
            isAuthenticated: localStorage.getItem("isAuthenticated") ? localStorage.getItem("isAuthenticated") : false,
        }
        this.myStartSubmitHandler = this.myStartSubmitHandler.bind(this);
    }

    componentDidMount() {
        const query = new URLSearchParams(this.props.location.search);
        const redirect = query.get('success')
        if (redirect == "true") {
            this.props.history.push('/schedule/meeting/');
            toast.dismiss();
            toast.success("Meeting has been scheduled, please check your email account.", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }

    myStartSubmitHandler = async (e) => {
        e.preventDefault();
        if(this.state.emails.length == 0){
            this.setState({
                isEmailsEmpty: true
            })
            return
        }else if(this.state.pastTimeMsg){
            this.setState({
                pastTimeMsg: true
            })
            return
        }else{
            this.setState({
                isEmailsEmpty: false,
                pastTimeMsg: false
            })
        const startTime = document.getElementById("select-start").value;
        const endTime = document.getElementById("select-end").value;
        const start_time = startTime.match(/.{1,2}/g).join(':')
        const end_time = endTime.match(/.{1,2}/g).join(':')
        const formatedDate = moment(this.state.date).format("YYYY-MM-DD");
        let meeting_id = '';
        if (this.state.isAuthenticated) {
            meeting_id = localStorage.getItem('meetingUrlLink')
        } else {
            meeting_id = Math.floor(Math.random() * 900000000 + 100000000);
        }
        const timezone = jstz.determine();
        const invitation_link = encodeURI(Baseurl_invite + "/" + meeting_id);
        const host_invitation_link = encodeURI(Baseurl_self + "/" + meeting_id);

        let schedule_obj = {
            meeting_id: meeting_id,
            start_time: formatedDate + "T" + start_time,
            end_time: formatedDate + "T" + end_time,
            timezone: timezone.name(),
            host_email: localStorage.getItem("isAuthenticated") ? this.state.apiUserDetail.email : this.state.host_email,
            host_name: localStorage.getItem("isAuthenticated") ? this.state.apiUserDetail.display_name : this.state.host_name,
            participants: this.state.emails,
            invitation_link: invitation_link,
            host_invitation_link: host_invitation_link,
            subject: localStorage.getItem("isAuthenticated") ? this.state.meeting_name : "HDMeet Meeting Invite",
            oc_user: localStorage.getItem("isAuthenticated") ? this.state.apiUserDetail.id : OneCloudGuestUserID,
            meeting_password: this.state.meeting_password
        };

        if (!this.state.sameTimeMsg) {
            try {
                const myHeaders = new Headers();
                myHeaders.append('Content-Type', 'application/json');

                toast.dismiss();
                toast.warning("Sending Email Invites, Please wait...", {
                    position: "top-right",
                    autoClose: 12000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                let data = await fetch(onlytoken, {
                    method: 'POST',
                    headers: myHeaders,
                    body: JSON.stringify({ username: userName, password: password }),
                }).then((response) => response.json())
                    .then(data => {
                        this.submitData(data, schedule_obj)
                    });
            } catch (error) {
                console.log(error)
            }
        }
    }
    }

    submitData = async (token, schedule_obj) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);

            await fetch(schedule, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify(schedule_obj),
            })
                .then(res => {
                    if (res.status == "201") {
                        toast.dismiss();
                        this.resetForm();
                    } else {
                        toast.dismiss();
                        toast.error("Invalid form, Meeting was not scheduled, please try again.");
                    }
                }).catch(function (err) {
                    toast.dismiss();
                });
        } catch (error) {
            toast.dismiss();
            toast.error(error, {
                autoClose: false,
                hideProgressBar: true
            });
        }
    }

    resetForm = () => {
        document.location.href = "/schedule/meeting?success=true";
    }

    updateFormValue = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        });
    }

    updateUsers = (value) => {
        this.setState({
            isEmailsEmpty: false,
            emails: value
        });
    }

    onChange = date => {
        const currentDay = moment().format("MMMM DD YYYY");
        const currentTime = moment().format("HH:mm");
        const selectedDay = moment(date).format("MMMM DD YYYY");
        const defaultStartTime = document.getElementById("select-start").value.match(/.{1,2}/g).join(':');
        this.setState({ date })
        if(selectedDay == currentDay){
            if(defaultStartTime < currentTime){
                this.setState({
                    pastTimeMsg: true
                })
            }
        }else{
            this.setState({
                pastTimeMsg: false
            })
        }
    }

    returnFunctionStart = event => {
        const startTimeHours = moment(event.startTime).milliseconds() + 1000 * (moment(event.startTime).seconds() + 60 * (moment(event.startTime).minutes() + 60 * moment(event.startTime).hours()));
        const startTimeDay = moment(this.state.date).format("MMMM DD YYYY")
        const currentTimeHours = moment().milliseconds() + 1000 * (moment().seconds() + 60 * (moment().minutes() + 60 * moment().hours()));
        const currentTimeDay = moment().format("MMMM DD YYYY");

        if (startTimeDay == currentTimeDay) {
                this.setState({
                    pastTimeMsg: false
                });
            if (startTimeHours > currentTimeHours) {
                this.setState({
                    pastTimeMsg: false,
                    startTime: event.startTime,
                    endTime: moment(event.startTime).add(1, 'hours')
                });
            } else {
                this.setState({
                    pastTimeMsg: true,
                    startTime: event.startTime,
                    endTime: moment(event.startTime).add(1, 'hours')
                })
            }
        } else {
            this.setState({
                pastTimeMsg: false,
                startTime: event.startTime,
                endTime: moment(event.startTime).add(1, 'hours')
            });
        }
    };

    handleMeetingPassword = (meetingPassword) => {
        this.setState({
            meeting_password: meetingPassword
        });
    }

    returnFunctionEnd = event => {
        if (!this.state.pastTimeMsg) {
            const defaultStartTime = document.getElementById("select-start").value;
            const startTime = this.state.startTime ? moment(this.state.startTime).format('HH:mm') : defaultStartTime.match(/.{1,2}/g).join(':')
            const endTime = moment(event.endTime).format('HH:mm')

            if (startTime >= endTime) {
                this.setState({
                    // sameTimeMsg: false,
                    sameTimeMsg: true,
                })
            } else {
                this.setState({
                    sameTimeMsg: false,
                }
                )
            }

            this.setState({
                endTime: event.endTime
            });
        } else {
            return
        }
    };

    render() {
        const formatedDate = moment(this.state.date).format("ddd, MMM DD, YYYY")
        return (
            <div className="appContainer" style={{ backgroundImage: `url(${Background})` }}>
                <div className="mainContainer">
                    <Header currentMeetingPassword={this.handleMeetingPassword} />

                    <div className="dbMeetingContainer scheduleContainer">
                        <h1>{MESSAGES.scheduleMeeting}</h1>
                        <div className="calender">
                            <Calendar
                                onChange={this.onChange}
                                value={this.state.date}
                                minDate={moment().toDate()}
                            />
                        </div>

                        <AvForm className="scheduleForm" onValidSubmit={this.myStartSubmitHandler}>
                            <div className="form-row">
                                <div className="form-group col-md-6">
                                    <label htmlFor="selectDate">{MESSAGES.selectedDate}</label>
                                    <input type="text" className="form-control" id="selectDate" placeholder="Date" value={formatedDate} disabled />
                                </div>
                                <div className="form-group col-md-6">
                                    <label htmlFor="startTime"></label>
                                    <TimeRange
                                        className="startEndTime"
                                        startMoment={this.state.startTime}
                                        endMoment={this.state.endTime}
                                        startLabel="Start Time"
                                        endLabel="End Time"
                                        minuteIncrement={timeDiffRange}
                                        sameIsValid="false"
                                        onStartTimeChange={this.returnFunctionStart}
                                        onEndTimeChange={this.returnFunctionEnd}
                                    />
                                    {this.state.pastTimeMsg ? <label className="same-time-error">{MESSAGES.pastTimeMessage}</label> : null}
                                    {this.state.sameTimeMsg ? <label className="same-time-error">{MESSAGES.startEndTimeMessage}</label> : null}
                                </div>
                            </div>

                            {!localStorage.getItem("isAuthenticated") ?
                                <div className="form-row">
                                    <div className="col-md-6 withStar">
                                        <AvField
                                            name="host_name"
                                            label="Your Name"
                                            className="form-control"
                                            type="text"
                                            errorMessage="Please enter a valid name."
                                            validate={{
                                                required: { value: true }
                                            }}
                                            value={this.state.host_name.trim()}
                                            onChange={this.updateFormValue}
                                        />
                                    </div>
                                    <div className="col-md-6 withStar">
                                        <AvField
                                            name="host_email"
                                            label="Your Email Address (Host)"
                                            className="form-control"
                                            type="text"
                                            errorMessage="Please enter a valid email address."
                                            validate={{
                                                required: { value: true },
                                                email: { value: true }
                                            }}
                                            value={this.state.host_email.trim()}
                                            onChange={this.updateFormValue}
                                        />
                                    </div>
                                </div>

                                :
                                <div className="form-row">
                                    <div className="col-md-12 withStar">
                                        <AvField
                                            name="meeting_name"
                                            label="Meeting Name"
                                            className="form-control"
                                            type="text"
                                            errorMessage="Please enter a valid name."
                                            validate={{
                                                required: { value: true }
                                            }}
                                            value={this.state.meeting_name.trim()}
                                            onChange={this.updateFormValue}
                                        />
                                    </div>
                                </div>
                            }

                            <div className="form-row">
                                <div className="col-md-12">
                                    <AvField
                                        name="meeting_password"
                                        label="Meeting Password"
                                        className="form-control"
                                        type="text"
                                        errorMessage="Please enter a valid password."
                                        validate={{
                                            required: { value: false, errorMessage: 'min 6 digits are allowed.' },
                                            pattern: { value: '/^[0-9]{6,}$/', errorMessage: 'Password should be minimun 6 digits.' }
                                        }}
                                        // value={this.state.apiUserDetail.settings.is_password ? this.state.meeting_password : ''}
                                        value={this.state.meeting_password}
                                        onChange={this.updateFormValue}
                                    />
                                </div>
                            </div>

                            <div className="form-row">
                                <div className="form-group col-md-12 withStar">
                                    <label htmlFor="emails">{MESSAGES.guestEmailAddresses}</label>
                                    <ReactMultiEmail
                                        name="emails"
                                        id="emails"
                                        // className={`${this.state.emails.length === 0 ? 'is-invalid' : ''}`}
                                        className=''
                                        emails={this.state.emails}
                                        onChange={this.updateUsers}
                                        validateEmail={email => {
                                            return isEmail(email);
                                        }}
                                        getLabel={(email, index, removeEmail) => {
                                            return <div data-tag key={index}>
                                                {email}
                                                <span data-tag-handle onClick={() => removeEmail(index)}>&times;</span>
                                            </div>;
                                        }}
                                    />
                                    {this.state.isEmailsEmpty ? <span className="same-time-error">{MESSAGES.isEmailsEmptyMsg}</span> : null}
                                </div>
                            </div>
                            <div className="form-row">
                                <div className="form-group col-md-3">
                                </div>
                                <div className="form-group col-md-3 text-center">
                                    <a href="/" className="cancelBtn">{MESSAGES.cancel}</a>
                                </div>
                                <div className="form-group col-md-6">
                                    <button
                                        className="form-control scheduleinviteBtn"
                                        id="SendInvite"
                                    >
                                        <img src={EmailIcon} alt="Send Email Invite Icon" />
                                        {MESSAGES.sendEmailInvitations}
                                    </button>
                                </div>
                            </div>
                        </AvForm>
                    </div>
                </div>
            </div>
        );
    }
}

export default ScheduleMeeting;