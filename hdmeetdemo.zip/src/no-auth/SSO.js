import React, { Component } from 'react'
var qs = require('qs');
import { toast } from 'react-toastify';
import { MESSAGES } from '../constant/messages';
import Loader from '../no-auth/loader'
import {
    ONE_CLOUD,
    nsApiUrl,
    Baseurl_app,
} from '../constant/index';
import {
    getAuthToken,
    getOneCloudUserDetail,
    createUpdateAuthToken,
    getMeetingsFromMeetingId,
    getJwtToken,
    createBackendMeeting,
} from '../helpers/auth-header';

class SSO extends Component {
    constructor(props) {
        super(props)
        this.state = {
            query_param: qs.parse(this.props.location.search, { ignoreQueryPrefix: true }),
            userInfo: {},
            isLogin: false,
            showLoader: false
        }
        this.readInfoOnExistingUser = this.readInfoOnExistingUser.bind(this);
        this.validSSO = this.validSSO.bind(this);
        this.loginSSO = this.loginSSO.bind(this);
        this.logIntoHdmeet = this.logIntoHdmeet.bind(this)
        this.startMeeting = this.startMeeting.bind(this)
    }
    componentDidMount() {
        this.setState({
            showLoader: true
        })
        if (this.state.query_param.access_token === undefined ||
            this.state.query_param.access_token === '' ||
            this.state.query_param.username === undefined ||
            this.state.query_param.username === '' ||
            this.state.query_param.domain === undefined ||
            this.state.query_param.domain === '' ||
            this.state.query_param.scope === undefined ||
            this.state.query_param.scope === '') {
            toast.warning("Invalid Authorisation", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });        
            this.setState({
                showLoader: false
            })
            localStorage.clear()
            window.location.href = "/"
        }
        // this.validSSO()
        this.loginSSO();
    }

    loginSSO = async () => {
        let error = "";
        let isSSOValid = false;

        //Get query parameters from request	
        let access_token = this.state.query_param.access_token
        let username = this.state.query_param.username
        let domain = this.state.query_param.domain
        let scope = this.state.query_param.scope

        try {
            isSSOValid = await this.validSSO(username, scope, access_token, domain)
        }
        catch (er) {
            error = 'Portal SSO error'
            toast.warning(error, {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            }); 
            setTimeout(() => {
                this.setState({
                    isLogin: false,
                    showLoader: false
                });
                localStorage.clear()
                window.location.href = "/"; 
            }, 5000)
            // redirect guest home page with error message on toast
        }

        if (isSSOValid) {
            // Use request query parameters to log user into your app
            this.setState({
                isLogin: true
            })
            await this.logIntoHdmeet()
            if(this.props.path == "/login/sso"){
                this.startMeeting()
            }else if (this.props.path == "/schedule/sso"){
                this.setState({
                    showLoader: false
                })
                this.props.history.push("/schedule/meeting")
            }else{
                this.setState({
                    showLoader: false
                })
                this.props.history.push("/user/dashboard/")
            }
        }
        else {
            error = 'Credential error';
            toast.warning(error, {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            }); 

            setTimeout(() => {
                this.setState({
                    isLogin: false,
                    showLoader: false
                });
                localStorage.clear()
                window.location.href = "/";
            }, 5000)
            // redirect guest home page with error message on toast
        }
    }

    logIntoHdmeet = async () => {
        let token = await getAuthToken();
        let authUserInfo = {
            domain: this.state.userInfo.domain,
            scope: this.state.userInfo.scope,
            displayName: this.state.userInfo.first_name + " " + this.state.userInfo.last_name,
            uid: this.state.userInfo.subscriber_login,
            user: this.state.userInfo.user,
            user_email: this.state.userInfo.email,
            username: this.state.userInfo.subscriber_login,
        }
        localStorage.setItem('isAuthenticated', true);
        localStorage.setItem('authUserData', JSON.stringify(authUserInfo));
        let dateNow = new Date();
        localStorage.setItem('checkLastLogin', dateNow.getTime());
        let apiUserDetail = await getOneCloudUserDetail(token, authUserInfo);
        let userToken = await createUpdateAuthToken(token, authUserInfo);
        localStorage.setItem('userToken', JSON.stringify(userToken));
        localStorage.setItem("apiUserDetail", JSON.stringify(apiUserDetail));
        let meetingUrlLink = apiUserDetail.current_meeting_id
        localStorage.setItem("meetingUrlLink", meetingUrlLink);
    }

    startMeeting = async () => {
        let token = await getAuthToken();
        let meetingPassword = !JSON.parse(localStorage.getItem("apiUserDetail")).settings ? '' : JSON.parse(localStorage.getItem("apiUserDetail")).settings.password;
        let data = await getJwtToken(token, 'start', '');
        let getMeetingsUsingMeetingId = await getMeetingsFromMeetingId(token, localStorage.getItem("meetingUrlLink"))
        if (getMeetingsUsingMeetingId.multiple == false && Object.keys(getMeetingsUsingMeetingId.detail).length == 0) {
            let cname = JSON.parse(localStorage.getItem('apiUserDetail')).current_meeting_id
            const meetingUrl = Baseurl_app + '/startconference/' + cname + '/' + 'a_on' + '/' + 'v_on' + '/' + data.jwt_token
            let displayname = JSON.parse(localStorage.getItem('authUserData')).displayName
            let ocUserId = JSON.parse(localStorage.getItem('apiUserDetail')).id
            let current_meeting_data = await createBackendMeeting(token, displayname, ocUserId, meetingUrl)
            localStorage.setItem("current_meeting_data", JSON.stringify(current_meeting_data))
            this.setState({
                showLoader: false
            })
            this.redirectConf(data, 'start')
        } else if (getMeetingsUsingMeetingId.multiple == false && Object.keys(getMeetingsUsingMeetingId.detail).length > 0) {
            let current_meeting_data = getMeetingsUsingMeetingId
            localStorage.setItem("current_meeting_data", JSON.stringify(current_meeting_data))
            this.setState({
                showLoader: false
            })
            this.redirectConf(data, 'start')
        } else {
            toast.dismiss();
            toast.error(MESSAGES.meetingAlreadyInProgress, {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }

    redirectConf = (token, participant) => {
        let cname;
        if (participant === 'start') {
            cname = localStorage.getItem("meetingUrlLink")
        }
        this.props.history.push('/startconference/' + cname + '/' + 'a_on' + '/' + 'v_on' + '/' + token.jwt_token);
    }

    validSSO = async () => {
        let isValid = false;
        let userInfoRes = await this.readInfoOnExistingUser();
        let infoUsername = userInfoRes[0].subscriber_login;
        let infoDomain = userInfoRes[0].domain;
        let infoScope = userInfoRes[0].scope;

        if (infoUsername == this.state.query_param.username &&
            infoDomain == this.state.query_param.domain &&
            infoScope == this.state.query_param.scope) {
            isValid = true;
            this.setState({
                userInfo: userInfoRes[0]
            })
        }
        return isValid
    }

    readInfoOnExistingUser = async () => {
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        myHeaders.append('Authorization', 'Bearer ' + this.state.query_param.access_token);
        let fields = {
            format: ONE_CLOUD.format,
            login: this.state.query_param.username,
            domain: this.state.query_param.domain,
        }
        let result = await fetch(nsApiUrl + "/?object=subscriber&action=read", {
            method: 'POST',
            headers: myHeaders,
            body: JSON.stringify(fields),
        })
        let response = {
            status: 400,
            data: {},
            message: "InValid Authrisation"
        }
        return await result.json()
    }

    render() {
        return (
            <div className="loaderWarpper">
                {this.state.showLoader ? 
                    <Loader showLoader={this.state.showLoader}></Loader>
                    : null
                }
            </div>
        )
    }
}

export default SSO;