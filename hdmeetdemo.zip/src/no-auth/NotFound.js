import React, { Component } from 'react';
import Background from '../assets/images/background.png';
import './newDesign.css';
import Header from '../no-auth/header';
import { MESSAGES } from '../constant/messages';

class NotFound extends Component {
    render() {
        return (
            <div className="appContainer" style={{ backgroundImage: `url(${Background})` }}>
                <div className="mainContainer">
                    <Header/>
                    <div className="dbMeetingContainer scheduleContainer">
                        <h1>{MESSAGES.errorPageNotFound}</h1>
                    </div>
                </div>
            </div>
        );
    }
}

export default NotFound;