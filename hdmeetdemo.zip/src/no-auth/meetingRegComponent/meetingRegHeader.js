import React from 'react'

const MeetingRegHeader = (props) => {

    
    return (
        <div className="container-fluid">
            <div className="row">
                <div className="col-xl-12 col-sm-12 text-white text-center" style={{height:"43px",background:"#18508D"}}>
                    {props.meetingReg ? <h2 style={{fontSize:"24px",padding:"6px"}}> Meeting Registration</h2>:<h2></h2>}
                    
                </div>
            </div>
        </div>
    )
}
export default MeetingRegHeader;
