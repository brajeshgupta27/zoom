import React, { useState, useEffect } from 'react'
import MeetingRegHeader from "./meetingRegHeader";
import MeetingRegConform from "./meetingRegConform";
import telwareLogo from "../../assets/images/Logo_HDMeet.png"
import { useHistory } from "react-router-dom";
import Loder from '../loader'
import Modal from '@material-ui/core/Modal';
import { getAuthToken } from '../../helpers/auth-header'

import axios from "axios";
import {
    webinarRegistration,
    webinarMeeting,
    webMeetingDetail,
    gettoken
} from '../../constant/index';
import moment from 'moment';


const MeetingReg = () => {

    let history = useHistory();
    var id = localStorage.getItem("webinarId");



    const emailRegex = /\S+@\S+\.\S+/;
    const [email, setEmail] = useState();
    const [conformEmail, setconformEmail] = useState();
    const [name, setName] = useState();
    const [getResId, setResId] = useState()

    const [errorEmail, seterrorEmail] = useState('');
    const [errorConformEmail, setconErrorformEmail] = useState('');
    const [errorName, seterrorName] = useState('');
    const [errorMailMatch, setErrorMailMatch] = useState('');
    const [getData, setData] = useState();
    const [showModal, setShowModal] = useState(false)
    const [loaderStart, setLoaderStart] = useState(false);
    const[meetingUrl,setMeetUrl]=useState();
    const[regidsend,setRgidSend]=useState( window.location.href.slice(window.location.href.lastIndexOf('/') + 1, window.location.href.length));
    let url = window.location.href
   
    var regstrationId = url.slice(url.lastIndexOf('/') + 1, url.length)
    // setRgidSend(regstrationId);
  

    const meetDetails=async()=>{
        var token = await getAuthToken();
        axios.get(`${webMeetingDetail}/${regstrationId}`,{
            headers: {
                'Authorization':  `Bearer ${token.access}`
              }
            })

            .then((response) => {
                setData(response.data.Result)
            

            }, (error) => {

                console.log(error);
            });
    }
    useEffect(() => {
        meetDetails();
       
    }, []);

    const closeModal = () => {
        setShowModal(false)
    }

    let reg_obj = {
        "webinar": getData && getData.id,
        "full_name": name,
        "email": email,
    }
    const getName = (e) => {
        setName(e.target.value);
        seterrorName("");
    }

    const getEmail = (e) => {

        let emailCheck = e.target.value;
        setEmail(e.target.value);
        seterrorEmail("")

        if (emailRegex.test(emailCheck)) {
            seterrorEmail('');

        } else {

            seterrorEmail('Please enter a valid email!');
        }
    }

    const getConfEmail = (e) => {
        setconformEmail(e.target.value);
        setconErrorformEmail("")
        setErrorMailMatch("")
      
    }
    let error = false

    const handleOnclick = async(e) => {
        let token = await getAuthToken();


        

        if (!name) {

            error = true;
            seterrorName("Please Enter Your full Name")
        }
        if (!email) {
            error = true;

            seterrorEmail("Please Enter Your Email")
            
        }
        if(!emailRegex.test(email)){
            error = true;
            seterrorEmail('Please enter a valid email!');
        }
        
        if (!conformEmail) {
            error = true;
            setconErrorformEmail("Please confirm Your Email")
        }
        if (email && conformEmail && email !== conformEmail) {
            error = true;
            setErrorMailMatch("Please try again.Your emails do not match");
        }

        if (error === false) {
            setLoaderStart(true)
            try {
                axios.post(webinarRegistration, reg_obj,{
                headers: {
                    'Authorization':  `Bearer ${token.access}`
                  }
                })

                    .then((response) => {
                        
                        setResId(response.data.Result.id)
                        setMeetUrl(response.data.Result.meeting_url)
                        localStorage.setItem("regId", regstrationId);
                        setShowModal(true)
                        // history.push("/webinar/regsuccess");
                        setLoaderStart(false)

                    }
                        , (error) => {

                            console.log(error);
                        });
            }
            catch (err) {
                console.log(err);
            }

        }
    }

    const createdDate = (createdDate) => {
        let formatedCreatedDate = moment(createdDate).format('dddd, MMMM DD YYYY, h:mm A');
        return formatedCreatedDate;
    }
    return (
        <React.Fragment>

            <MeetingRegHeader meetingReg={1} />
            <div className="meetings-Wrapper">
                {showModal === true ?
                    <div class="modal-dialog modal-lg" >
                        <MeetingRegConform showModal={showModal} closeModal={closeModal} getResId={getResId} meetingUrl={meetingUrl} regidsend={regidsend}/>

                    </div>
                    : ""}

            </div>


            <div className="container">
                <div className="row">
                    <div className="mt-4 col-xl-12 col-sm-12 text-dark text-center">
                        <h3 className="scheduleMeetConfTex">Registration for:</h3>

                    </div>
                    <div className="mt-1 col-xl-12 col-sm-12 text-dark text-center">
                        <h5 className="scheduleMeetConfSubText">{getData && getData.title}</h5>

                    </div>

                    <div className="mt-2 col-xl-12 col-sm-12 text-dark text-center">
                        <h3 className="scheduleMeetConfTex">Description:</h3>

                    </div>

                    <div className="mt-1 col-xl-12 col-sm-12 text-dark text-center">
                        <h5 className="scheduleMeetConfSubText">{getData && getData.description}</h5>

                    </div>
                    <div>
                    {loaderStart &&
                                    <div>
                                        <Loder meetingRegPage={"yes"}/>
                                    </div>
                                }
                                </div>
                    <div className="mt-2 col-xl-12 col-sm-12 text-dark text-center">
                        <h3 className="scheduleMeetConfTex">Date:</h3>


                    </div>


                    <div className="mt-1 col-xl-12 col-sm-12 text-dark text-center">
                        <h5 className="scheduleMeetConfSubText">{createdDate(getData && getData.start_time)}</h5>

                    </div>
                </div>
                <div className="row">
                    <div className=" offset-3 mx-auto col-md-6">
                        <form>
                            <div className="form-group">

                                <div className="text-danger">{errorName} </div>

                                <input type="email"
                                    className="form-control"
                                    id="exampleInputEmail1"
                                    aria-describedby="emailHelp"
                                    placeholder="Full Name"
                                    onChange={(e) => getName(e)}
                                />
                              

                            </div>

                            <div className="form-group">
                                <div className="text-danger">{errorEmail} </div>
                                <input type="email"

                                    className="form-control"
                                    id="exampleInputEmail1"
                                    aria-describedby="emailHelp"
                                    placeholder="Email"
                                    onChange={(e) => getEmail(e)}
                                />

                            </div>
                            <div className="form-group">
                                <div className="text-danger">{errorConformEmail} </div>

                                <input type="email"
                                    className="form-control"
                                    id="exampleInputEmail1"
                                    aria-describedby="emailHelp"
                                    placeholder="Confirm Email"
                                    onChange={(e) => getConfEmail(e)}
                                />
                                <div className="text-danger">{errorMailMatch} </div>
                            </div>


                        </form>
                        <div className="d-flex justify-content-center mt-5">
                            <button onClick={(e) => handleOnclick()} className="btn  text-center btnReg">Register</button>
                        </div>
                    </div>
                </div>
                <div className="col-xl-12 col-sm-12 d-flex justify-content-center mt-5">
                    <img style={{width:"13%"}} src={telwareLogo} alt="logo img" />
                </div>
            </div>

        </React.Fragment>

    );
}
export default MeetingReg;




