import React, { useEffect, useState } from 'react'

import '../newDesign.css';
import telwareLogo from "../../assets/images/Logo_HDMeet.png";

import Modal from '@material-ui/core/Modal';
import axios from "axios";
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { getAuthToken } from '../../helpers/auth-header'
import {
    webinarMeeting,
    webinarRegistration,
    attendeeMeetingUrl,
    downloadAttendeeIcsAttachment,
    webMeetingDetail,
    gettoken
} from '../../constant/index';
import moment from 'moment';
const MeetingRegConform = (props) => {

    const [getData, setData] = useState();
  
    const [getregData, setregData] = useState();
    
    const [data, setcopyData] = useState();
    const [copy, setCopy] = useState(false);

    var id = parseInt(localStorage.getItem("webinarId"));
    var regid = parseInt(localStorage.getItem("regId"));
    
    const getAuth=async()=>{
        const token = await getAuthToken();
        

        axios.get(`${webMeetingDetail}/${props.regidsend}`,{
            headers: {
                'Authorization':  `Bearer ${token.access}`
              }
            })
            .then((response) => {
                setData(response.data.Result)
                

            }, (error) => {

                console.log(error);
            });

            

            
     }
     const getMeetDetail=async()=>{
        const token = await getAuthToken();
        axios.get(`${webinarRegistration}/${regid}`,{
            headers: {
                'Authorization':  `Bearer ${token.access}`
              }
            })
            .then((response) => {
                setregData(response.data.Result)


            }, (error) => {

                console.log(error);
            });
     }

    useEffect(() => {
        getAuth()
        getMeetDetail()
        
    }, []);


    const downloadIcs = () => {
        

        try {
            const link = document.createElement('a');
            link.href = `${downloadAttendeeIcsAttachment}/${props.getResId}`;
            document.body.appendChild(link);
            link.click();
            link.parentNode.removeChild(link);
        } catch (error) {
            console.log(error)
        }
    }

    const createdDate = (createdDate) => {
        let formatedCreatedDate = moment(createdDate).format('dddd, MMMM DD YYYY, h:mm A');
        return formatedCreatedDate;
    }

    if (props.showModal) {

        return (<Modal
            open={props.showModal}
            onClick={() => props.closeModal()}
        >
            <React.Fragment>
            

                <div className=" regConfModalBody" style={{ margin: "0", position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)", maxWidth: "700px",  width:" auto" }} onClick={(e) => e.stopPropagation()}>
                    <div className="col-xl-12 col-sm-12 text-white text-center" style={{ width: "100%", background: "#18508D", padding: "22px" }}>
                    <button type="button" style={{ textAlign: "left", position: "absolute", right: "15px", top: "6px",color:"white" }} class="close schedule-close" data-dismiss="modal" onClick={() => props.closeModal()}>&times;</button>
                       
                    </div>
                    <div className="row" style={{padding:"3px"}}>


                        <div className="mt-1 col-xl-12 col-sm-12 text-dark text-center "  >
                            <h1 style={{ color: "#18508D",fontSize:"34px" }}> Congratulations! You are now registered.</h1>

                        </div>
                        <div className="mt-2 col-xl-12 col-sm-12 text-dark text-center">
                            <h1  style={{fontSize:"26px"}}> {getData && getData.title}</h1>

                        </div>
                        <div className="col-xl-12 col-sm-12 text-dark text-center">
                            <h3 className="scheduleMeetConfText mt-2" >Description:</h3>

                        </div>
                        <div className="col-xl-12 col-sm-12 text-dark text-center">
                            <h5 className="scheduleMeetConfSubText">{getData && getData.description}</h5>

                        </div>

                        <div className="col-xl-12 col-sm-12 text-dark text-center">
                            <h3 className="scheduleMeetConfText mt-2" >Date:</h3>

                        </div>


                        <div className="col-xl-12 col-sm-12 text-dark text-center">
                            <h5 className="scheduleMeetConfSubText">{createdDate(getData && getData.start_time)}</h5>

                        </div>

                        <div className="col-xl-12 col-sm-12 text-dark text-center">
                            <h3 className="scheduleMeetConfText mt-4">Meeting URL:</h3>

                        </div>
                        <div className=" col-xl-12 col-sm-12 text-center">
                        <h6 className="scheduleMeetConfSubText">{`${attendeeMeetingUrl}/${getData && getData.register_id}?attendee=${props.meetingUrl}`}</h6>
                        </div>
                        
                        
                
                        <div className="col-xl-12 col-sm-12 text-dark text-center">

                        <CopyToClipboard text={`${attendeeMeetingUrl}/${getData && getData.register_id}?attendee=${props.meetingUrl}`}
                                onCopy={() => setCopy(true)}>
                                     <span style={{color:"#38A6DE"}}>Copy Meeting Info <i className="fa fa-clone" aria-hidden="true">

</i></span>
                                

                            </CopyToClipboard>
                            <br />
                            {copy ? <span className="text-success">Copied</span> : null}
                        </div>
                        <div className="col-xl-12 col-sm-12 mt-3 text-center">
                            <span className="downloadMeetInfoRegSucc " style={{fontSize:"16px"}}>Download Meeting Information <i class="fa fa-download" aria-hidden="true"
                                onClick={() => downloadIcs()}></i></span>
                        </div>
                        <div className="mt-1 col-xl-12 col-sm-12 text-dark text-center">
                            <h6 className="scheduleMeetConfSubText">We have sent you an email. Please check your inbox for confirmation of this registration</h6>

                        </div>
                    </div>
                    
                    <div className="mt-1 col-xl-12 col-sm-12 text-dark text-center">
                        <button className="btn  websConfbtn" onClick={() => props.closeModal()}>Close</button>

                    </div>


                    <div className="col-xl-12 col-sm-12 d-flex justify-content-center mt-3">
                    <img style={{width:"13%"}}src={telwareLogo} alt="logo img" />
                </div>
                </div>
            </React.Fragment>

        </Modal>
        );
    }
}
export default MeetingRegConform;




