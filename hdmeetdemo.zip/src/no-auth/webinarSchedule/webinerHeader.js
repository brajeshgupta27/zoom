import React from 'react'

const webinerHeader = () => {


    return (
        <div className="container-fluid" style={{background:"#18508D",width: "102.7%",
        marginTop: "-16px",
        marginLeft: "-16px"}}>
            <div className="row">
                <div className="col-xl-12 col-sm-12  text-white text-start" style={{height:"46px"}}>
                     <h3 className="mt-1 meetingText"> Schedule meeting</h3>
                    
                </div>
            </div>
        </div>
    )
}
export default webinerHeader;
