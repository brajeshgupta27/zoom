import React, { useState, useEffect, useRef } from 'react'
import Modal from '@material-ui/core/Modal';
import '../newDesign.css';
import axios from 'axios';
import ComponentToPrint from "../webinarSchedule/ComponentToPrint";
import { CSVLink, CSVDownload } from "react-csv";



import ReactToPrint, { PrintContextConsumer } from 'react-to-print';

import { getAuthToken } from '../../helpers/auth-header'

import {
    webinarMeeting,
    showanalytics,
    gettoken,
    downloadWebinarRecording,
    getAttendeeDetails,
} from '../../constant/index';


// const csvData =
//     [
//         {
//             "userId": 1,
//             "id": 1,
//             "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",

//         },
//         {
//             "userId": 1,
//             "id": 2,
//             "title": "qui est esse",
//         },
//         {
//             "userId": 1,
//             "id": 3,
//             "title": "ea molestias quasi exercitationem repellat qui ipsa sit aut",
//         }
//     ]
// const headers = [
//     { label: "UserId", key: "userId" },
//     { label: "ISD", key: "id" },
//     { label: "Title", key: "title" },
// ]
// const csvReport = {
//     filename: 'Report.csv',
//     headers: headers,
//     data: csvData
// }
const AnalyticsModal = (props) => {
    const componentRef = useRef();



    const [getAnalyticsData, setAnalyticsData] = useState();
    const [hostIndex, setHostIndex] = useState();
    const [regDetail, setRegDetail] = useState();
    const [data, setData] = useState();
    let userdata = JSON.parse(localStorage.getItem('authUserData'))
    var userEmail = userdata.user_email;
    
  
   
    
    const getmodIndex = () => {
        const ownerIndex = getAnalyticsData && getAnalyticsData.moderators.indexOf(userEmail)

        return ownerIndex;
    }
    if (props.analyticsShow) {


        const getAttendees = async () => {
            let token = await getAuthToken();
            axios.get(`${showanalytics}/${props.webinarId}`, {
                headers: {
                    'Authorization': `Bearer ${token.access}`
                }
            })
                .then((response) => {
                    setAnalyticsData(response.data.Result)



                }, (error) => {

                    console.log(error);
                });
        }
        var csvDataDownload=[];
        const showRegDetails = async (id) => {
    
            let token = await getAuthToken();
            axios.get(`${getAttendeeDetails}/${props.webinarId}`, {
                headers: {
                    'Authorization': `Bearer ${token.access}`
                }
            })
                .then(res => {
                    csvDataDownload=res.data.Result;
                    if (Object.keys(res.data.Result).length == 0) {
                        setRegDetail([])
                    }
                    
                    else{setRegDetail(res.data.Result)}
    
                    // if (Object.keys(res.data.Result).length == 0) {
                    //     csvDataDownload=res.data.Result;
                    //     setRegDetail([], () => {
                    //         console.log(regDetail, "regDetail")
                    //     })
                    // }
                    // else {
                    //     csvDataDownload=res.data.Result;
                    //     setRegDetail(res.data.Result, () => {
                    //         console.log(regDetail, "regDetail7777")
                    //     })
                    // }
                    // const webinardata = res.data;
    
                    // this.setState({ webinarData: webinardata });
                })
    
    
        }
        //  console.log(csvDataDownload,"csvDataDownload")
        const csvData = regDetail && regDetail
         

        const csvData2 = csvDataDownload;
        const csvData1 =[
            
               
                {full_name: "Ashwani Gupta", email: "krishnas2@chetu.com"},
    
            
            
               
                {full_name: "Ashwani Gupta", email: "krishnas2@chetu.com"},
    
    
            
            
        ];
        
        const headers = [
            { label: "Email", key: "email" },
            { label: "Name", key: "full_name" },
            
        ]
        const csvReport = {
            filename: 'Report.csv',
            headers: headers,
            data: csvData ?  csvData:""
        }
        useEffect(() => {
            getAttendees();
            showRegDetails();

        }, []);
        var userDetail = localStorage.getItem("apiUserDetail") ? JSON.parse(localStorage.getItem("apiUserDetail")) : {};
        var userToken = localStorage.getItem('userToken') ? JSON.parse(localStorage.getItem('userToken')) : "",
            download_file = (e) => {
                e.preventDefault();
                try {
                    const link = document.createElement('a');
                    link.href = `${downloadWebinarRecording}/${props.meetingId}/${userToken.token}/${userDetail.id}`;
                    link.target = "_blank"
                    document.body.appendChild(link);
                    link.click();
                    link.parentNode.removeChild(link);
                } catch (error) {
                    console.log("inside exception")
                    console.log(error)
                }
            }


        return (
            <Modal
                open={props.analyticsShow}

            >



                <div className=" container-fluid modal-body mt-3 mb-5 modalBodyAnalytics" style={{ padding: "0px", maxHeight: "650px" }}>
                    <div className="modal-header" style={{
                        background: "#18508D", height: "66px",
                        padding: "15px"
                    }}>
                        <h4 className="modal-title text-uppercase ml-3" style={{ fontSize: "26px", color: "#fff" }}>Analytics</h4>
                        <button type="button" class="close"
                            data-dismiss="modal" aria-label="Close"
                            onClick={() => props.closeAnalytics()}
                        >

                            <span aria-hidden="true" size="2x" style={{ color: "white" }}>&times;</span>
                        </button>
                    </div>



                    <div className="modal-body"  >


                        <div className="modal-details analytisc-detail" >

                            <div className="row"  >
                                <div className="col-12">
                                    <p><strong>Title:</strong> {getAnalyticsData && getAnalyticsData.title}</p>
                                    <p><strong>Description:</strong>{getAnalyticsData && getAnalyticsData.description}</p>
                                </div>
                            </div>
                            <div className="row" >
                                <div className="col-12">
                                    <h4>{getAnalyticsData && getAnalyticsData.moderators_count} Moderators <i className="fa fa-angle-down" aria-hidden="true"></i></h4>
                                    <ul className="moderators">
                                        {getAnalyticsData && getAnalyticsData.moderators && getAnalyticsData.moderators.length > 0 && getAnalyticsData.moderators.map((value, index) => {
                                            return (
                                                <li className="mr-1 mt-1"> {getmodIndex() == index ? `${value} (owner)` : value}</li>

                                            )
                                        })

                                        }

                                    </ul>
                                </div>
                            </div>
                            <div className="row"  >
                                <div className="col-12">
                                    <h4>{getAnalyticsData && getAnalyticsData.total_registration_count} Registrations <i className="fa fa-angle-down" aria-hidden="true"></i></h4>
                                    <div className="scrollbar" id="style-3">
                                        <div className="force-overflow">
                                            <ul className="analytics-list d-flex">
                                                {getAnalyticsData && getAnalyticsData.total_registration && getAnalyticsData.total_registration.length > 0 && getAnalyticsData.total_registration.map((value, index) => {
                                                    return (
                                                        <li> {value}</li>

                                                    )
                                                })

                                                }


                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* <div className="row" ref={componentRef} >
                                    <div className="col-12">
                                        <h4>{getAnalyticsData && getAnalyticsData.attended_attendee_count}  Attendees <i className="fa fa-angle-down" aria-hidden="true"></i></h4>
                                        <div className="scrollbar" id="style-3">
                                            <div className="force-overflow">
                                                <ul className="analytics-list d-flex">
                                                    {getAnalyticsData && getAnalyticsData.attended_attendee && getAnalyticsData.attended_attendee.length > 0 && getAnalyticsData.attended_attendee.map((value, index) => {
                                                        return (
                                                            <li> {value}</li>

                                                        )
                                                    })

                                                    }


                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div> */}
                            <div className="row">
                                <div className="col-12">
                                    <h4>Analytics <i className="fa fa-angle-down" aria-hidden="true"></i></h4>
                                    <div className="row">
                                        <div className="col-12">
                                            <ul className="analytics m-0">
                                                <li><h4> Attendance Rate:  {getAnalyticsData && getAnalyticsData.attendance_rate}%</h4></li>
                                                <li><h4> Registrations:  {getAnalyticsData && getAnalyticsData.total_registration_count}</h4></li>

                                                {/* <li><h4>Attendees: {getAnalyticsData && getAnalyticsData.attended_attendee_count} </h4></li> */}
                                            </ul>
                                            <div style={{ display: "none" }}>
                                                <ComponentToPrint ref={componentRef} getAnalyticsData=
                                                    {props.webinarId} />
                                            </div>
                                            <ul className="analytics m-0">
                                                <li><h4> <a className="dAttendee" onClick={(e) => download_file(e)}>Download Recording <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-cloud-arrow-down-fill" viewBox="0 0 16 16">
                                                    <path d="M8 2a5.53 5.53 0 0 0-3.594 1.342c-.766.66-1.321 1.52-1.464 2.383C1.266 6.095 0 7.555 0 9.318 0 11.366 1.708 13 3.781 13h8.906C14.502 13 16 11.57 16 9.773c0-1.636-1.242-2.969-2.834-3.194C12.923 3.999 10.69 2 8 2zm2.354 6.854-2 2a.5.5 0 0 1-.708 0l-2-2a.5.5 0 1 1 .708-.708L7.5 9.293V5.5a.5.5 0 0 1 1 0v3.793l1.146-1.147a.5.5 0 0 1 .708.708z" />
                                                </svg></a></h4></li>
                                                {/* <li><h4> <a href="#">Download Transcription <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-cloud-arrow-down-fill" viewBox="0 0 16 16">
                                                <path d="M8 2a5.53 5.53 0 0 0-3.594 1.342c-.766.66-1.321 1.52-1.464 2.383C1.266 6.095 0 7.555 0 9.318 0 11.366 1.708 13 3.781 13h8.906C14.502 13 16 11.57 16 9.773c0-1.636-1.242-2.969-2.834-3.194C12.923 3.999 10.69 2 8 2zm2.354 6.854-2 2a.5.5 0 0 1-.708 0l-2-2a.5.5 0 1 1 .708-.708L7.5 9.293V5.5a.5.5 0 0 1 1 0v3.793l1.146-1.147a.5.5 0 0 1 .708.708z" />
                                            </svg></a></h4></li> */}
                                                {/* <ReactToPrint


trigger={() =>     <li><h4> <a className="dAttendee">Download Registrations <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-cloud-arrow-down-fill" viewBox="0 0 16 16">
<path d="M8 2a5.53 5.53 0 0 0-3.594 1.342c-.766.66-1.321 1.52-1.464 2.383C1.266 6.095 0 7.555 0 9.318 0 11.366 1.708 13 3.781 13h8.906C14.502 13 16 11.57 16 9.773c0-1.636-1.242-2.969-2.834-3.194C12.923 3.999 10.69 2 8 2zm2.354 6.854-2 2a.5.5 0 0 1-.708 0l-2-2a.5.5 0 1 1 .708-.708L7.5 9.293V5.5a.5.5 0 0 1 1 0v3.793l1.146-1.147a.5.5 0 0 1 .708.708z" />
</svg></a></h4></li>}
content={() => componentRef.current}
/> */}
                                                <li><CSVLink {...csvReport}><h4> <a className="dAttendee">Download Registrations <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-cloud-arrow-down-fill" viewBox="0 0 16 16">
                                                    <path d="M8 2a5.53 5.53 0 0 0-3.594 1.342c-.766.66-1.321 1.52-1.464 2.383C1.266 6.095 0 7.555 0 9.318 0 11.366 1.708 13 3.781 13h8.906C14.502 13 16 11.57 16 9.773c0-1.636-1.242-2.969-2.834-3.194C12.923 3.999 10.69 2 8 2zm2.354 6.854-2 2a.5.5 0 0 1-.708 0l-2-2a.5.5 0 1 1 .708-.708L7.5 9.293V5.5a.5.5 0 0 1 1 0v3.793l1.146-1.147a.5.5 0 0 1 .708.708z" />
                                                </svg></a></h4></CSVLink></li>
                                            </ul>

                                        </div>

                                    </div>
                                </div>
                            </div>



                        </div>
                    </div>
                    <div className="modal-footer">

                        <button type="button" className="btn" style={{ width: "170px", background: "#757575", color: "#fff" }} data-dismiss="modal" onClick={() => props.closeAnalytics()}>Close</button>
                    </div>

                </div>

            </Modal>
        )
    }
}
export default AnalyticsModal;