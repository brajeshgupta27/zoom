import React, { useState, useEffect } from 'react'
import axios from 'axios';
import Modal from '@material-ui/core/Modal';
import moment from 'moment';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { getAuthToken } from '../../helpers/auth-header'

import '../newDesign.css';
import {

    webinarMeeting,
    MeetingUrl,
    downloadIcsAttachment
} from '../../constant/index';
const WebinarScheduleConfModal = (props) => {
  

    const [data, setData] = useState();
    const [copy, setCopy] = useState(false);
const [authToken,setauthToken]=useState()

    const createdDate = (createdDate) => {
        let formatedCreatedDate = moment(createdDate).format('dddd, MMMM DD YYYY, h:mm A');
        return formatedCreatedDate;
    }
    const getAuth=async()=>{
        const token = await getAuthToken();
        

        axios.get(`${webinarMeeting}/${props.successRegId}`,{
            headers: {
                'Authorization':  `Bearer ${token.access}`
              }
            })
            .then((response) => {
                setData(response.data)
                

            }, (error) => {

                console.log(error);
            });
     }
    




        

    
    
    useEffect(() => {
        getAuth()
   
    }, []);


    const downloadIcs = () => {
        

        try {
            const link = document.createElement('a');
            link.href = `${downloadIcsAttachment}/${data.id}`;
            document.body.appendChild(link);
            link.click();
            link.parentNode.removeChild(link);
        } catch (error) {
            console.log(error)
        }
    }





    if (props.showModalConfMeet) {


        return (<Modal
            open={props.showModalConfMeet}
            onClick={() => props.closeMeetconf()}
        >

            <div class="modal-body ml-5 mr-5 mt-3 mb-5 modalBodymeetConf" onClick={(e) => e.stopPropagation()} style={{left: "27%"}}>
                <div className="meetInfoHeader">
                    <h4 className="ml-4 mt-1 scheduleMeetConfText"> Meeting Information</h4>
                    <button type="button" style={{ textAlign: "left", position: "absolute", right: "15px", top: "6px",color:"white" }} class="close schedule-close" data-dismiss="modal" onClick={() => props.closeMeetconf()}>&times;</button>
                </div>
                <center>
                    <div className="contantContainer mt-3">
                        <div>
                            <h5 className="scheduleMeetConfText mt-4">Title:</h5>
                        </div>
                        <div>
                            <h6 className="scheduleMeetConfSubText">{data && data.title}</h6>
                        </div>
                        <div>
                            <h5 className="scheduleMeetConfText mt-4">Description:</h5>
                        </div>
                        <div>
                            <h6  className="scheduleMeetConfSubText">{data && data.description}</h6>
                        </div>
                        <div>
                            <h5 className="scheduleMeetConfText mt-4">Date:</h5>
                        </div>
                        <div>
                            <h6  className="scheduleMeetConfSubText">{createdDate(data && data.start_time)}</h6>
                        </div>
                        <div>
                            <h5 className="scheduleMeetConfText mt-4"> Meeting URL:</h5>
                        </div>
                        <div>
                            <h6  className="scheduleMeetConfSubText">{data && `${MeetingUrl}/${data.meeting_id}`}</h6>
                        </div>
                        <div>
                            <h5 className="scheduleMeetConfText mt-4">Registration Link:</h5>
                        </div>
                        <div>
                            <h6  className="scheduleMeetConfSubText">{data && data.registration_link}


                                <CopyToClipboard text={data && data.registration_link}
                                    onCopy={() => setCopy(true)}>
                                    <i class="fa fa-clone" aria-hidden="true">

                                    </i>

                                </CopyToClipboard>
                            </h6>
                            {copy ? <span className="text-success" >Copied.</span> : null}
                            {/* <h6>{data && data.registration_link}</h6> */}
                        </div>
                        <div className="downloadMeetInfo mt-3">
                            <span style={{fontSize:"16px"}}>Download Meeting Information <i class="fa fa-download" aria-hidden="true"
                                onClick={() => downloadIcs()}></i></span>
                        </div>

                        <div>
                            <button
                                className="btn mt-4 websConfbtn"
                                onClick={() => props.closeMeetconf()}>Close</button>
                        </div>

                    </div>
                </center>
            </div>

        </Modal>
        )
    }
}
export default WebinarScheduleConfModal;
