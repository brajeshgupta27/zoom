import React from 'react'
import '../newDesign.css';
import axios from 'axios';
import {
    webinarMeeting,
    showanalytics,
    gettoken,
    downloadWebinarRecording

} from '../../constant/index';
import { getAuthToken } from '../../helpers/auth-header';
import '../newDesign.css';
class ComponentToPrint extends React.Component {

constructor(props){
    super(props) 
    this.state = {
        getAnalyticsData:null,
    }
}

     getAttendees = async () => {
        let token = await getAuthToken();
        axios.get(`${showanalytics}/${this.props.getAnalyticsData}`, {
            headers: {
                'Authorization': `Bearer ${token.access}`
            }
        })
            .then((response) => {
                this.setState({getAnalyticsData:response.data.Result},()=>{
             
                })
                



            }, (error) => {

                console.log(error);
            });
    }
    componentDidMount=()=>{
        this.getAttendees();
    }
    render() {
     
        return (
            
               <div className="container" style={{margin:"50px",fontSize:"40px"}}>
                <div className="row">
                    <div className="col-12">
                        <p><strong>Title:</strong> {this.state.getAnalyticsData && this.state.getAnalyticsData.title}</p>
                        <p><strong>Description:</strong>{this.state.getAnalyticsData && this.state.getAnalyticsData.description}</p>
                    </div>
                </div>
                <div className="row" >
                    <div className="col-12">
                        <h4 style={{fontSize:"40px"}}>{this.state.getAnalyticsData && this.state.getAnalyticsData.moderators_count} Moderators <i className="fa fa-angle-down" aria-hidden="true"></i></h4>
                        <ul className="">
                            {this.state.getAnalyticsData && this.state.getAnalyticsData.moderators && this.state.getAnalyticsData.moderators.length == 0 ? <li style={{fontSize:"40px"}}>No Record</li>:
                            
                            this.state.getAnalyticsData && this.state.getAnalyticsData.moderators && this.state.getAnalyticsData.moderators.length > 0 && this.state.getAnalyticsData.moderators.map((value, index) => {
                                return (
                                    <li className="mr-1" style={{fontSize:"40px"}}> {value}</li>

                                )
                            })

                            }

                        </ul>
                    </div>
                    
                </div>
                <div className="row">
                    <div className="col-12">
                        <h4 style={{fontSize:"40px"}}>{this.state.getAnalyticsData && this.state.getAnalyticsData.total_registration_count} Registrations <i className="fa fa-angle-down" aria-hidden="true"></i></h4>
                        <div className="scrollbar" id="style-3">
                            <div className="force-overflow">
                                <ul className="analytics-list d-flex">
                                    {
                                    this.state.getAnalyticsData && this.state.getAnalyticsData.total_registration && this.state.getAnalyticsData.total_registration.length == 0 ? <li style={{fontSize:"40px"}}>No Record</li>:
                                    this.state.getAnalyticsData && this.state.getAnalyticsData.total_registration && this.state.getAnalyticsData.total_registration.length > 0 && this.state.getAnalyticsData.total_registration.map((value, index) => {
                                        return (
                                            <li style={{fontSize:"40px"}}> {value}</li>

                                        )
                                    })

                                    }


                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-12">
                        <h4 style={{fontSize:"40px"}}>{this.state.getAnalyticsData && this.state.getAnalyticsData.attended_attendee_count}  Attendees <i className="fa fa-angle-down" aria-hidden="true"></i></h4>
                        <div className="scrollbar" id="style-3">
                            <div className="force-overflow">
                                <ul className="analytics-list d-flex">
                                    {
                                         this.state.getAnalyticsData && this.state.getAnalyticsData.attended_attendee && this.state.getAnalyticsData.attended_attendee.length == 0 ? <li style={{fontSize:"40px"}}>No Record</li>:
                                    this.state.getAnalyticsData && this.state.getAnalyticsData.attended_attendee && this.state.getAnalyticsData.attended_attendee.length > 0 && this.state.getAnalyticsData.attended_attendee.map((value, index) => {
                                        return (
                                            <li style={{fontSize:"40px"}}> {value}</li>

                                        )
                                    })

                                    }


                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                </div>

            

        )
    }
}
export default ComponentToPrint;