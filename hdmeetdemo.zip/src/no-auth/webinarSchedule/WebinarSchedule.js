import React, { useState } from 'react'
// import DatePicker from 'react-date-picker';
import EmailIcon from '../../assets/images/emailIcon.png';
import Clock from '../../assets/images/clock.png';
import { MDBInput, MDBIcon } from "mdbreact";
import Input from '@material-ui/core/Input';
import { makeStyles } from "@material-ui/core/styles"
import InputAdornment from '@material-ui/core/InputAdornment';
import '../newDesign.css';
import WebinerHeader from './webinerHeader';
import Dateschedule from './dateschedule';
import axios from 'axios';
import moment from 'moment';
import ReactDOM from 'react-dom'
import TimezonePicker from 'react-bootstrap-timezone-picker';
import 'react-bootstrap-timezone-picker/dist/react-bootstrap-timezone-picker.min.css';

import {
    webinarMeeting
} from '../../constant/index';

const WebinarSchedule = () => {

    let userData = localStorage.getItem('apiUserDetail');
    let userId = JSON.parse(userData)


    const [selectedTimezone, setSelectedTimezone] = useState({})

    const [defaultValue, setDafaultValue] = useState(0);
    const [title, setTitle] = useState('');
    const [desc, setDesc] = useState();

    const [moderators, setModerators] = useState([]);
    const [attendees, setAttendees] = useState([]);
    const [oc_user, setOc_user] = useState(userId.id);

    const [start_time, setStart_time] = useState();
    console.log(start_time, "start_time");

    const [duration, setDuration] = useState();
    const [hour, setHour] = useState();
    const [minute, setMinute] = useState();
    const [timezone, setTimezone] = useState("EDT");
    const [meeting_password, setMeeting_password] = useState();
    const [enable_chat, setEnable_chat] = useState(false);
    const [require_invitation, setRequire_invitation] = useState(false);
    const [hide_viewers, setHide_viewers] = useState(false);
    const [record_meeting, setRecord_meeting] = useState(false);

    let dates = `${start_time}T${hour}:${minute}`
    console.log(dates, "dates");
    const getTitle = (e) => {
        setTitle(e.target.value);
    }
    const getDesc = (e) => {
        setDesc(e.target.value);
    }
    const getDurtion = (e) => {
        setDuration(e.target.value);
    }
    console.log(duration,"durayii")

    const getTimeZone = (e) => {
        setTimezone(e.target.value)
    }
    const getPassword = (e) => {
        setMeeting_password(e.target.value)
    }
    const getEnableChatvalue = () => {
        setEnable_chat(true)
    }
    const getRequireInvitation = () => {
        setRequire_invitation(true)
    }
    const getHideViwers = () => {
        setHide_viewers(true)
    }
    const getStartDate = (e) => {

        setStart_time(e.target.value)
    }
    const getHours = (e) => {
       if(e.target.value < 10){
        setHour(`0${e.target.value}`)
       }
           else{
            setHour(e.target.value)
           }
       
       }
    
    const getMinutes = (e) => {
        if(e.target.value < 10){
        setMinute(`0${e.target.value}`)
        }
        else{
            setMinute(e.target.value)
        }
    }


    const getMeetingRecording = () => {
        setRecord_meeting(true)
    }

    const getModerators = (e) => {
        let moderators = e.target.value;

        let modArr = moderators.split(",")

        setModerators(modArr)
    }

    const getAttendees = (e) => {

        let attenendes = e.target.value;

        let attArr = attenendes.split(",")

        setAttendees(attArr)
    }


    ///Api obj
    let webinarMeeting_obj = {
        "meeting_id": "",
        "register_id": "",
        "moderators": moderators,
        "attendees": attendees,
        "title": title,
        "description": desc,
        "recur": "",
        "oc_user": oc_user,
        "start_time": `${start_time}T${hour}:${minute}`,
        "duration": duration,
        "registration_link": "",
        "timezone": timezone,
        "meeting_password": meeting_password,
        "enable_chat": enable_chat,
        "require_invitation": true,
        "hide_viewers": hide_viewers,
        "record_meeting": record_meeting

    }

    const handleDefaultValue = (val) => {
        setDafaultValue(val)
    }

    const handleOnclickApi = () => {
        console.log(webinarMeeting_obj)

        axios.post(webinarMeeting, webinarMeeting_obj
        )
            .then((response) => {
                console.log(response);
            }, (error) => {
                console.log(error);
            });

    }


    return (
        <React.Fragment>
            <WebinerHeader />
            <div className="container">
                <div className="row d-flex justify-content-between inputRadius ">
                    <div className="col-xl-6 col-md-6 col-sm-12 mt-5">
                        <form>
                            <div className="form-group">

                                <input type="email"
                                    className="form-control"
                                    id="exampleInputEmail1"
                                    aria-describedby="emailHelp"
                                    placeholder="Title of Meeting"
                                    onChange={(e) => getTitle(e)}
                                />

                            </div>
                            {defaultValue === 1 ?
                                <div className="form-group">

                                    <input type="email"
                                        className="form-control"
                                        id="exampleInputEmail1"
                                        aria-describedby="emailHelp"
                                        placeholder="Description"
                                        onChange={(e) => getDesc(e)}
                                    />

                                </div> :
                                <div></div>
                            }

                        </form>
                        <div className="col-md-12 col-sm-12 mt-5">
                            <div className="row d-flex">

                                <div className="col-xl-5 col-md-5 col-sm-12">
                                    <p> Meeting Type</p>

                                </div>

                                <div className="d-flex col-xl-7 col-md-7 col-sm-12" style={{ fontSize: "13px" }}>

                                    <input className="redioBtn"
                                        type="radio"
                                        name="selectType"
                                        checked={defaultValue === 0 ? "checked" : ""}
                                        onClick={() => handleDefaultValue(0)}
                                    />
                                    <label className="ml-2 mr-4 mb-2" for="basic-url">Conference</label>


                                    <input className="ml-1 mr-2 
                                    redioBtn"
                                        type="radio"
                                        name="selectType"
                                        onClick={() => handleDefaultValue(1)}
                                    />
                                    <label for="basic-url">Webinar</label>


                                </div>
                            </div>
                        </div>

                        <div className="container">
                            <div className="row">
                                <div className="col-md-7 d-flex">
                                    <div style={{ marginLeft: "-19px" }}>
                                        <input type="date"
                                            className="form-control col-md-3"
                                            style={{ maxWidth: "170px" }}
                                            // onChange={(e)=>getStartDate()
                                            onChange={(date) => getStartDate(date)}
                                        />
                                        <p className="ml-1">Date</p>
                                    </div>
                                    <div className="col-md-4">
                                        <input type="number" className="form-control inputHour" placeholder="hh"
                                            onChange={(e) => getHours(e)}
                                        />
                                        <p>Hour</p>
                                    </div>

                                    <div className="col-md-4">
                                        <input type="number"
                                            className="form-control minDiv"
                                            placeholder="mm"
                                            onChange={(e) => getMinutes(e)}
                                        />
                                        <p>Minute</p>
                                    </div>

                                    <div className="col-md-4">
                                        <TimezonePicker 
                                        
                                            absolute={false}
                                            // defaultValue="Europe/Moscow"
                                            placeholder="EDT"
                                            onChange={setSelectedTimezone}
                                            
                                        />
                                        {/* <input type="number"
                                            className="form-control zoneDiv" placeholder="EDT"
                                            onChange={(e) => getTimeZone(e)}

                                        /> */}


                                        <p>Zone</p>
                                    </div>

                                    <div className="col-md-4">
                                        <input type="number"
                                            className="form-control durationDiv" placeholder="30 min"
                                            onChange={(e) => getDurtion(e)}
                                        />
                                        <p className="mr-1">Duration</p>
                                    </div>


                                </div>

                            </div>

                        </div>


                        <select className="custom-select mt-3 mb-1" id="inputGroupSelect01">
                            <option selected>Recurs daily</option>
                            <option value="1">Recurs weekly</option>
                            <option value="2">Recurs monthaly</option>

                        </select>
                        <p>Frequency of meeting</p>

                        <div className="form-group">

                            <input type="password"
                                className="form-control"
                                id="exampleInputEmail1"
                                aria-describedby="emailHelp"
                                placeholder="Password"
                                onChange={(e) => getPassword(e)}
                                style={{ height: "35px" }}

                            />

                        </div>
                        <div className="d-flex justify-content-between">
                            <div className="col-xl-4 col-md-4 col-sm-12">
                                <p className="mpass">Meeting Password</p>
                            </div>
                            <div className="col-xl-7 col-md-7 col-sm-12" style={{ fontSize: "12px" }}>
                                <span className="mpass">Require Passcode</span>
                                <span className="ml-2 mr-2 ">off</span>
                                <label className="switch">
                                    <input className="mt-2" type="checkbox" />
                                    <span className="slider round"></span>
                                </label>
                                <span className="ml-1">on</span>


                            </div>
                        </div>
                        {/* <Dateschedule defaultValue={defaultValue}/> */}

                        <div className="row">
                            <div className="col-md-12 col-xl-12" style={{ marginLeft: "-26px" }}>
                                <div className="d-flex" style={{ marginTop: "60px" }}>

                                    <div className="" style={{ fontSize: "12px" }}>
                                        <div className="float-left">Enable Chat
                            <br />
                                            <span className="ml-2 mr-2 d-inline">off</span>

                                            <label className="switch">
                                                <input className="mt-2"
                                                    type="checkbox"
                                                    onClick={() => getEnableChatvalue()}
                                                />
                                                <span className="slider round"></span>
                                            </label>

                                            <span className="ml-1 d-inline">on</span>

                                        </div>
                                        {defaultValue === 1 ?
                                            <div className="ml-4 float-left">Require Invitation
                                              <br />
                                                <span className="ml-2 mr-2 d-inline">off</span>

                                                <label className="switch">
                                                    <input className="mt-2" type="checkbox"
                                                        onClick={() => getRequireInvitation()}
                                                    />
                                                    <span className="slider round"></span>
                                                </label>

                                                <span className="ml-1 d-inline">on</span>

                                            </div> : <div className="d-none"> <span className="ml-2 mr-2 d-inline">off</span>

                                                <label className="switch">
                                                    <input className="mt-2" type="checkbox" />
                                                    <span className="slider round"></span>
                                                </label>

                                                <span className="ml-1 d-inline">on</span></div>
                                        }

                                        {defaultValue === 1 ?

                                            <div className="ml-4 float-left">Hide viewers and list count
                                              <br />
                                                <span className="ml-1 mr-2 d-inline">off</span>

                                                <label className="switch">
                                                    <input className="mt-2" type="checkbox"
                                                        onClick={() => getHideViwers()}
                                                    />
                                                    <span className="slider round"></span>
                                                </label>

                                                <span className="ml-1 d-inline">on</span>

                                            </div> : <div className="d-none">  <span className="ml-1 mr-2 d-inline">off</span>

                                                <label className="switch">
                                                    <input className="mt-2" type="checkbox" />
                                                    <span className="slider round"></span>
                                                </label>

                                                <span className="ml-1 d-inline">on</span></div>
                                        }
                                        <div className="ml-4 float-left">Record Meeting
                            <br />
                                            <span className="ml-4 mr-2 d-inline">off</span>

                                            <label className="switch">
                                                <input className="mt-2"
                                                    type="checkbox"
                                                    onClick={() => getMeetingRecording()}
                                                />
                                                <span className="slider round"></span>
                                            </label>

                                            <span className="ml-1 d-inline">on</span>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div className="vline mt-5">

                    </div>
                    <div className=" col-xl-4 col-md-4 col-sm-12 mt-5">
                        {defaultValue === 1 ?
                            <div>
                                <div className="form-group">
                                    <label for="exampleInputEmail1">Add Moderators</label>
                                    <input type="email"
                                        className="form-control"
                                        id="exampleInputEmail1"
                                        aria-describedby="emailHelp"
                                        placeholder="Add by name, extention, number or email"
                                        onChange={(e) => getModerators(e)}
                                    />

                                </div>
                                <div className="d-inline mt-5">
                                    <div className="d-flex">
                                        <div className="pothoFrame">
                                            <img src={EmailIcon} alt="gold" />
                                        </div>
                                        <div className="ml-2">Katy Robinson  3124</div>

                                    </div>




                                </div>
                            </div> : <div></div>
                        }
                        <div className="form-group mt-4">
                            <label for="exampleInputEmail1">Add Attendees</label>
                            <input type="email"
                                className="form-control"
                                id="exampleInputEmail1"
                                aria-describedby="emailHelp"
                                placeholder="Add by name, extention, number or email"
                                onChange={(e) => getAttendees(e)}
                            />

                        </div>
                        <div className="d-inline mt-5">
                            <div className="d-flex">
                                <div className="pothoFrame">

                                </div>
                                <div className="ml-2">Katy Robinson  3124</div>

                            </div>
                            <div className="d-flex">
                                <div className="pothoFrame">

                                </div>
                                <div className="ml-2">Katy Robinson  3124</div>

                            </div>



                        </div>
                        <div className="btndown text-center">
                            <button type="button"
                                class="btn btn-primary pl-5 pr-5"
                                onClick={() => handleOnclickApi()}
                            >Save</button>
                        </div>

                    </div>


                </div>
            </div>
        </React.Fragment>
    )

}

export default WebinarSchedule
