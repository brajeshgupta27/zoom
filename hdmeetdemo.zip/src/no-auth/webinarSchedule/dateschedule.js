import React from 'react';
import { MDBInput, MDBIcon } from "mdbreact";
import { Input, Switch } from '@material-ui/core';
import { makeStyles } from "@material-ui/core/styles"
import InputAdornment from '@material-ui/core/InputAdornment';
import '../newDesign.css';

const dateschedule = (props) => {
    const { defaultValue } = props;
    return (
        // <div className="container">
            <div className="row">
                <div className="col-md-12 col-xl-12" style={{ marginLeft: "-26px" }}>
                    <div className="d-flex" style={{ marginTop: "60px" }}>

                        <div className="" style={{ fontSize: "12px" }}>
                            <div className="float-left">Enable Chat
                            <br />
                                <span className="ml-2 mr-2 d-inline">off</span>

                                <label className="switch">
                                    <input className="mt-2" type="checkbox" />
                                    <span className="slider round"></span>
                                </label>

                                <span className="ml-1 d-inline">on</span>

                            </div>
                            {defaultValue === 1 ?
                                <div className="ml-4 float-left">Require Invitation
                            <br />
                                    <span className="ml-2 mr-2 d-inline">off</span>

                                    <label className="switch">
                                        <input className="mt-2" type="checkbox" />
                                        <span className="slider round"></span>
                                    </label>

                                    <span className="ml-1 d-inline">on</span>

                                </div> : <div className="d-none"> <span className="ml-2 mr-2 d-inline">off</span>

                                    <label className="switch">
                                        <input className="mt-2" type="checkbox" />
                                        <span className="slider round"></span>
                                    </label>

                                    <span className="ml-1 d-inline">on</span></div>
                            }

                            {defaultValue === 1 ?

                                <div className="ml-4 float-left">Hide viewers and list count
                            <br />
                                    <span className="ml-1 mr-2 d-inline">off</span>

                                    <label className="switch">
                                        <input className="mt-2" type="checkbox" />
                                        <span className="slider round"></span>
                                    </label>

                                    <span className="ml-1 d-inline">on</span>

                                </div> : <div className="d-none">  <span className="ml-1 mr-2 d-inline">off</span>

                                    <label className="switch">
                                        <input className="mt-2" type="checkbox" />
                                        <span className="slider round"></span>
                                    </label>

                                    <span className="ml-1 d-inline">on</span></div>
                            }
                            <div className="ml-4 float-left">Record Meeting
                            <br />
                                <span className="ml-4 mr-2 d-inline">off</span>

                                <label className="switch">
                                    <input className="mt-2" type="checkbox" />
                                    <span className="slider round"></span>
                                </label>

                                <span className="ml-1 d-inline">on</span>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        // </div>

    )
}

export default dateschedule;
