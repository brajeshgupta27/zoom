import React, { useState, useEffect } from 'react';
import TimeZoneModal from "./TimeZoneModal";
import WebinarScheduleConfModal from './WebinarScheduleConfModal';
import WatchModal from './WatchModal'
import Modal from '@material-ui/core/Modal';
import Timekeeper from 'react-timekeeper';
import WebinarSchedule from './WebinarSchedule'
import EmailIcon from '../../assets/images/emailIcon.png';
import Clock from '../../assets/images/clock.png';
import { MDBInput, MDBIcon } from "mdbreact";
import Input from '@material-ui/core/Input';
import { makeStyles } from "@material-ui/core/styles"
import InputAdornment from '@material-ui/core/InputAdornment';
import '../newDesign.css';
import WebinerHeader from './webinerHeader';
import Dateschedule from './dateschedule';
import axios from 'axios';
import moment from 'moment';
import momentz from 'moment-timezone';
import ReactDOM from 'react-dom';
import Loder from '../loader';
import { toast } from 'react-toastify';
import { getAuthToken } from '../../helpers/auth-header';
import ReactTooltip from 'react-tooltip';



import 'react-bootstrap-timezone-picker/dist/react-bootstrap-timezone-picker.min.css';

import {
    webinarMeeting,
    Baseurl_invite,
    Baseurl_self,
    schedule,
    gettoken,
    getScope_featureList,
    getAllScopesApi


} from '../../constant/index';


const WebinarScheduleModal = (props) => {



    let userData = localStorage.getItem('apiUserDetail');
    let userId = JSON.parse(userData)
    let userdata = JSON.parse(localStorage.getItem('authUserData'))
    var userEmail = userdata.user_email;
    var userName = userId.display_name;
    var userScope = userId.oc_scope




    var times = new Date();

    let currentDateUpperCase = times.toLocaleString('en-US', {
        hour: '2-digit',
        minute: '2-digit', hour12: true
    })
    var currentDate = currentDateUpperCase.toLowerCase()


    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = today.getFullYear();


    today = yyyy + '-' + mm + '-' + dd;

    var BrtimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone + moment.tz(Intl.DateTimeFormat().resolvedOptions().timeZone).format(" z Z") + "GMT"
    var abbr_default_tz = BrtimeZone.split(" ")[1]


    const [selectedTimezone, setSelectedTimezone] = useState(BrtimeZone);


    const [selectedDisplayTimezone, setSelectedDisplayTimezone] = useState(abbr_default_tz)
    const [selectedTimezoneError, setSelectedTimezoneError] = useState();
    const [loaderStart, setLoaderStart] = useState(false);
    const [defaultValue, setDafaultValue] = useState(0);
    const [getRegLink, setRegLink] = useState()
    const [getRegid, setRedId] = useState()
    const [getmeetId, setMeetId] = useState()
    const [title, setTitle] = useState();
    const [titleError, setTitleError] = useState('');
    const [desc, setDesc] = useState();
    const [showModal, setShowModal] = useState(false);
    const [showModalConfMeet, setShowModalConfMeet] = useState(false);
    const [successRegId, setSuccessRegId] = useState();
    const [showWatchModal, setShowWatchModal] = useState(false);
    const [recurValue, setRecurValue] = useState("N")


    const [moderators, setModerators] = useState([userEmail]);
    const [moderatorsError, setModeratorsError] = useState();
    const [moderatorsToshow, setModeratorsToshow] = useState([]);

    const [attendees, setAttendees] = useState([]);
    const [attendeesError, setAttendeesError] = useState([]);
    const [oc_user, setOc_user] = useState(userId.id);

    const [start_time, setStart_time] = useState(today);
    const [start_timeError, setstart_timeError] = useState();
    const [time, setTime] = useState(currentDate);

    const [timeError, setTimeError] = useState();
    const [openClock, setOpenClock] = useState(false);
    const [getInterVal, setgetInterVal] = useState();
    const [endDate, setendDate] = useState("");

    const [duration, setDuration] = useState(parseInt(15));


    const [durationError, setDurationError] = useState("");
    const [hour, setHour] = useState();
    const [minute, setMinute] = useState();
    const [timezone, setTimezone] = useState("EDT");
    const [meeting_password, setMeeting_password] = useState();
    const [paserror, setpassError] = useState();
    const [enable_chat, setEnable_chat] = useState(true);
    const [req_pass, setReq_pass] = useState(false);

    const [require_invitation, setRequire_invitation] = useState(true);
    const [getRecurseValue, setRecurseValue] = useState(false);
    const [hide_viewers, setHide_viewers] = useState(true);
    const [record_meeting, setRecord_meeting] = useState(false);
    const [sun, setSun] = useState(false);

    const [mon, setMon] = useState(false);
    const [tue, setTue] = useState(false);
    const [wed, setWed] = useState(false);
    const [thu, setThu] = useState(false);
    const [fri, setFri] = useState(false);
    const [sat, setSat] = useState(false);
    const [selectedDay, setSelectedDay] = useState(props.webinarID > 0 && occurWeekly ? data && data.recur_data.days : "");

    // const getDelectedDaysEdit = () => {


    //     // if (selectedDay.length > 0) {
    //         console.log(selectedDay, "getting here iiii")
    //         // for (let i = 0; i <= selectedDay.length; i++) {
    //             selectedDay.length > 0 && selectedDay.forEach(function (element) {
    //                 console.log(element, "element")

    //                 if (element == "SU") {
    //                     console.log("getting here")
    //                     setSun(true)
    //                 }
    //                 if (element == "MO") {
    //                     setMon(true)
    //                 }
    //                 if (element == "TU") {
    //                     setTue(true)
    //                 }
    //                 if (element == "WE") {
    //                     setWed(true)
    //                 }
    //                 if (element == "TH") {
    //                     setThu(true)
    //                 }
    //                 if (element == "FR") {
    //                     setThu(true)
    //                 }
    //                 if (element == "SA") {
    //                     setThu(true)
    //                 }
    //             })
    //         //}
    //     }
    // }
    const [inputType, setInputType] = useState(true);
    const [neveroccur, setneveroccur] = useState(true);
    const [occurDay, setnOccurDay] = useState(false);
    const [occurWeekly, setOccurWeekly] = useState(false);

    const [occurMonthly, setOccurMonthly] = useState(false);
    const [occurYearly, setOccurYearly] = useState(false);
    const [occurType, setOccurType] = useState(false);
    const [ends, setEnds] = useState(false);
    const [endsOnDate, setendsOnDate] = useState(false);
    const [modCurrentVaue, setModCurrentValue] = useState();
    const [attCurrentValue, setAttCurrentValue] = useState();
    const [data, setData] = useState();
    const [authTok, setAuthTok] = useState();
    const [scopeData, setScopeData] = useState();
    const [featureData, setFeatureData] = useState();
    const [featureListData, setfeatureListData] = useState();



    const getwebinarDetail = async () => {

        const token = await getAuthToken();
        axios.get(`${webinarMeeting}/${props.webinarID}`, {
            headers: {
                'Authorization': `Bearer ${token.access}`
            }
        })
            .then((response) => {


                setData(response.data)
                if (response.data.recur_data.days.length > 0) {
                    let days = response.data.recur_data.days.filter((e, i) => {
                        if (response.data.recur_data.days[i] === "SU") {
                            setSun(true)
                        } else if (response.data.recur_data.days[i] === "MO") {
                            setMon(true)
                        } else if (response.data.recur_data.days[i] === "TU") {
                            setTue(true)
                        } else if (response.data.recur_data.days[i] === "WE") {
                            setWed(true)
                        } else if (response.data.recur_data.days[i] === "TH") {
                            setThu(true)
                        } else if (response.data.recur_data.days[i] === "FR") {
                            setFri(true)
                        } else if (response.data.recur_data.days[i] === "SA") {
                            setSat(true)
                        } else {
                            console.log("")
                        }
                    })
                }
                if (props.webinarID > 0) {

                    setTitle(response.data.title)
                    setDesc(response.data.description)


                    setStart_time(moment(response.data.start_time).format('YYYY-MM-DD'))

                    var hours = Math.floor(response.data.duration / 60);
                    var minutes = response.data.duration % 60;
                    if (minutes.toString().length === 1) {

                        minutes = `0${minutes}`
                    }
                    let hourMin = `${hours} hour:${minutes} min`
                    //  return hours + ":" + minutes;


                    setDuration(hourMin)
                    setSelectedTimezone(response.data.timezone)
                    setMeeting_password(response.data.meeting_password)
                    setEnable_chat(response.data.enable_chat)
                    setRequire_invitation(response.data.require_invitation)
                    setHide_viewers(response.data.hide_viewers)
                    setRecord_meeting(response.data.record_meeting)
                    setAttendees(response.data.attendees)
                    setModerators(response.data.moderators)
                    setDafaultValue(1);
                    setRegLink(response.data.registration_link)
                    setRedId(response.data.register_id)
                    setMeetId(response.data.meeting_id)
                    setReq_pass(response.data.require_passcode)
                    if (response.data.recurrence === true) {
                        setRecurValue(response.data.recur_type)
                        if (recurValue == "D") {
                            setnOccurDay(true)

                        }
                        else if (recurValue == "W") {
                            setOccurWeekly(true)
                            setSelectedDay(response.data.recur_data.days.length > 0 && response.data.recur_data.days)
                            // console.log(selectedDay,"selectedDay")
                        }
                        else if (recurValue == "M") {
                            setOccurMonthly(true)

                        }
                        setgetInterVal(response.data.recur_data.interval)

                    }
                    // if(response.data.recurrence){
                    //     console.log("entring")

                    //     setRecurValue(response.data.recur_type,()=>{
                    //         console.log(recurValue,"jjjj")
                    //     })
                    //     console.log(recurValue,"jjjj000")
                    //     // if()
                    //     // setRecurValue(recur_typ)
                    // }

                }

            }, (error) => {

                console.log(error);
            });
    }

    useEffect(() => {
        getwebinarDetail();

        //getDelectedDaysEdit();


        // axios.get(`${webinarMeeting}/${props.successRegId}`)
        //    axios.get(`${webinarMeeting}/107`)

        // .then((response) => {
        //     setData(response.data)
        //     setTitle(response.data.title)
        //     setDesc(response.data.description)
        //     setStart_time(response.data.start_time.split('T'))

        //     console.log(response, "reesponse data");

        // }, (error) => {

        //     console.log(error);
        // });

    }, [recurValue]);

    const userFeatureData = async () => {
        let token = await getAuthToken();
        let featureList = await getFeatureData(token, userScope);
        let OcScopeData = await getScopeData(token, userScope);

        let featureListData_ = featureList.Result[OcScopeData.Result.name]


        setfeatureListData(featureListData_.is_webinar)



    }

    const getScopeData = async (token, scopeId) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(getAllScopesApi + "/" + scopeId, {
                method: 'GET',
                headers: myHeaders,
            })
            const data = await result.json()

            return data
        } catch (error) {
            console.log(error)
        }
    }
    const getFeatureData = async (token, scopeId) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(getScope_featureList + "/" + scopeId, {
                method: 'GET',
                headers: myHeaders,
            })
            const data = await result.json()

            return data
        } catch (error) {
            console.log(error)
        }
    }


    useEffect(() => {
        userFeatureData()

    }, [featureListData]);

    const openWatch = () => {
        setOpenClock(!openClock)
        setShowWatchModal(!showWatchModal)
    }

    const getDayValue = (dayVal) => {


        if (dayVal == "SU") {

            if (sun === false) {

                setSun(true)
                setSelectedDay([...selectedDay, dayVal])
            }
            else {



                setSun(false)
                var indexVal = selectedDay.indexOf("SU")

                if (indexVal > -1) {

                    selectedDay.splice(indexVal, 1);


                }
            }

        }
        if (dayVal == "MO") {

            if (mon === false) {

                setMon(true)
                setSelectedDay([...selectedDay, dayVal])
            }
            else {



                setMon(false)
                var indexVal = selectedDay.indexOf("MO")

                if (indexVal > -1) {

                    selectedDay.splice(indexVal, 1);


                }
            }

        }
        if (dayVal == "TU") {

            if (tue === false) {

                setTue(true)
                setSelectedDay([...selectedDay, dayVal])
            }
            else {



                setTue(false)
                var indexVal = selectedDay.indexOf("TU")

                if (indexVal > -1) {

                    selectedDay.splice(indexVal, 1);


                }
            }

        }
        if (dayVal == "WE") {

            if (wed === false) {

                setWed(true)
                setSelectedDay([...selectedDay, dayVal])
            }
            else {



                setWed(false)
                var indexVal = selectedDay.indexOf("WE")

                if (indexVal > -1) {

                    selectedDay.splice(indexVal, 1);


                }
            }

        }
        if (dayVal == "TH") {

            if (thu === false) {

                setThu(true)
                setSelectedDay([...selectedDay, dayVal])
            }
            else {



                setThu(false)
                var indexVal = selectedDay.indexOf("TH")

                if (indexVal > -1) {

                    selectedDay.splice(indexVal, 1);


                }
            }

        }
        if (dayVal == "FR") {

            if (fri === false) {

                setFri(true)
                setSelectedDay([...selectedDay, dayVal])
            }
            else {



                setFri(false)
                var indexVal = selectedDay.indexOf("FR")

                if (indexVal > -1) {

                    selectedDay.splice(indexVal, 1);


                }
            }

        }

        if (dayVal == "SA") {

            if (sat === false) {

                setSat(true)
                setSelectedDay([...selectedDay, dayVal])
            }
            else {



                setSat(false)
                var indexVal = selectedDay.indexOf("SA")

                if (indexVal > -1) {

                    selectedDay.splice(indexVal, 1);


                }
            }

        }

    }


    const getinterval = {
        interval: parseInt(getInterVal),
        end_time: endDate,
        days: selectedDay
    }

    function getWeekOfMonth(date) {
        const startWeekDayIndex = 1; // 1 MonthDay 0 Sundays
        const firstDate = new Date(date.getFullYear(), date.getMonth(), 1);
        const firstDay = firstDate.getDay();

        let weekNumber = Math.ceil((date.getDate() + firstDay) / 7);
        if (startWeekDayIndex === 1) {
            if (date.getDay() === 0 && date.getDate() > 1) {
                weekNumber -= 1;
            }

            if (firstDate.getDate() === 1 && firstDay === 0 && date.getDate() > 1) {
                weekNumber += 1;
            }
        }
        if (weekNumber == 1) {
            return "first";
        }
        else if (weekNumber == 2) {
            return "second";
        }
        else if (weekNumber == 3) {
            return "third";
        }
        else if (weekNumber == 4) {
            return "fourth";
        }
    }

    function myDate() {
        var a = new Date();
        var weekdays = new Array(7);
        weekdays[0] = "Sunday";
        weekdays[1] = "Monday";
        weekdays[2] = "Tuesday";
        weekdays[3] = "Wednesday";
        weekdays[4] = "Thursday";
        weekdays[5] = "Friday";
        weekdays[6] = "Saturday";
        return weekdays[a.getDay()];

    }


    const getEnds = (e) => {
        let endsValue = e.target.value;
        if (endsValue == "N") {
            setEnds(false)
        }
        if (endsValue == "D") {
            setEnds(true)


        }
        if (endsValue == "DN") {
            setEnds(true)
            setendsOnDate(true)

        }


    }




    const getOcurance = (e) => {
        var ocurValue = e.target.value;
        setRecurValue(ocurValue)

        setOccurType(ocurValue)
        if (ocurValue == "D") {
            setneveroccur(false)
            setnOccurDay(true)
            setOccurWeekly(false)
            setOccurMonthly(false)
        }
        else if (ocurValue == "W") {
            setneveroccur(false)
            setOccurWeekly(true)
            setnOccurDay(false)
            setOccurMonthly(false)
        }

        else if (ocurValue == "M") {
            setneveroccur(false)
            setOccurMonthly(true)
            setOccurWeekly(false)
            setnOccurDay(false)
        }
        else if (ocurValue == "Y") {
            setneveroccur(false)
            setOccurYearly(true)
            setOccurMonthly(false)
            setOccurWeekly(false)
            setnOccurDay(false)
        }
        else if (ocurValue == "N") {
            setneveroccur(true)
            setOccurYearly(false)
            setOccurMonthly(false)
            setOccurWeekly(false)
            setnOccurDay(false)
        }

    }


    const getTimePickerDate = () => {
        setOpenClock(!openClock)
        setInputType(false)
        setShowWatchModal(!showWatchModal)
    }
    if (time) {
        var dt = moment(time, ["h:mm A"]).format("HH:mm");


        var datesRemovedZone = `${start_time}T${dt}`

    }


    const getTitle = (e) => {

        setTitle(e.target.value);
    }

    const getDesc = (e) => {

        setDesc(e.target.value)

    }
    const getDurtion = (e) => {
        setDuration(e.target.value);
    }


    const getTimeZone = (e) => {
        setTimezone(e.target.value)
    }
    const getPassword = (e) => {
        let pass = e.target.value;
        const re = /^[0-9\b]+$/;
        if (e.target.value === '' || re.test(e.target.value)) {
            setMeeting_password(e.target.value)
            setpassError("");
        }
        else {
            setpassError("This field allow only numbers")
        }
        // console.log(typeof pass, "pass")
        // let passWord = parseInt(meeting_password)
        // console.log(passWord, "uu")
        // console.log(meeting_password.length,"lenth")
        // if (meeting_password.length > 0) {
        //     console.log(meeting_password.length,"lenth")
        //     if (isNaN(passWord)) {
        //         setpassError("This field allow only numbers llll")

        //     }
        // }
        // setMeeting_password(e.target.value)
        // setpassError("");

    }
    const getEnableChatvalue = () => {
        setEnable_chat(!enable_chat)
    }
    const getReqPassvalue = () => {
        setReq_pass(!req_pass)
    }

    const getRequireInvitation = () => {
        setRequire_invitation(!require_invitation)
    }
    const getHideViwers = () => {
        setHide_viewers(!hide_viewers)
    }
    const getStartDate = (e) => {

        setStart_time(e.target.value)
    }

    // const getRecurse = (e) => {

    //     setRecurseValue(e.target.value)const
    // }
    const removeEmail = (email) => {

        var indexVal = moderators.indexOf(email)

        if (indexVal > -1) {

            moderators.splice(indexVal, 1);

            setModerators([...moderators]);

        }


    }
    const removeEmailAttende = (email) => {

        var indexVal = attendees.indexOf(email)

        if (indexVal > -1) {

            attendees.splice(indexVal, 1);

            setAttendees([...attendees]);

        }


    }


    const getHours = (e) => {
        if (e.target.value < 10) {
            setHour(`0${e.target.value}`)
        }
        else {
            setHour(e.target.value)
        }

    }

    const getMinutes = (e) => {
        if (e.target.value < 10) {
            setMinute(`0${e.target.value}`)
        }
        else {
            setMinute(e.target.value)
        }
    }


    const getMeetingRecording = () => {
        setRecord_meeting(!record_meeting)
    }

    var emailRegex = /\S+@\S+\.\S+/;
    const getModerators = (e) => {

        let moderatorsVal = e.target.value;

        setModCurrentValue(moderatorsVal)
        if (emailRegex.test(moderatorsVal)) {
            setModeratorsError('');

        } else {

            setModeratorsError('Please enter a valid email!');
        }


    }

    const handleTest = (e) => {
        if (!emailRegex.test(modCurrentVaue)) {
            setModeratorsError('Please enter a valid email!');
        }
        if (emailRegex.test(modCurrentVaue)) {
            if (e.which == 13) {

                setModerators([...moderators, modCurrentVaue])
                setModCurrentValue("")


            }
        }
    }
    var attArr = [];


    const getAttendees = (e) => {

        let attenendes = e.target.value;
        setAttCurrentValue(attenendes)

        if (emailRegex.test(attenendes)) {
            setAttendeesError('');

        } else {

            setAttendeesError('Please enter a valid email!');
        }

    }
    const handleTestAttende = (e) => {
        if (!emailRegex.test(attCurrentValue)) {
            setAttendeesError('Please enter a valid email!');
        }
        if (emailRegex.test(attCurrentValue)) {
            if (e.which == 13 || e.which == 44) {
                setAttendees([...attendees, attCurrentValue])
                setAttCurrentValue("")
            }
        }
    }

    ///confApi obj
    let isAuthenticated = localStorage.getItem("isAuthenticated") ? localStorage.getItem("isAuthenticated") : false


    let meeting_id = '';
    if (isAuthenticated) {
        meeting_id = localStorage.getItem('meetingUrlLink')
    } else {
        meeting_id = Math.floor(Math.random() * 900000000 + 100000000);
    }

    const invitation_link = encodeURI(Baseurl_invite + "/" + meeting_id);
    const host_invitation_link = encodeURI(Baseurl_self + "/" + meeting_id)

    let schedule_obj = {
        "meeting_id": meeting_id,
        "start_time": datesRemovedZone,
        "end_time": "",
        "timezone": selectedTimezone,
        "host_email": userEmail,
        "moderators": moderators,
        "host_name": userName,
        "participants": attendees,
        "invitation_link": invitation_link,
        "host_invitation_link": host_invitation_link,
        "subject": title,
        "oc_user": oc_user,
        "meeting_password": meeting_password,
        "recurrence": recurValue != "N" ? true : false,
        "recur_type": recurValue,
        "recur_data": getinterval,
        "duration": parseInt(duration),
        "enable_chat": enable_chat,
        "record_meeting": record_meeting,
        "require_passcode": req_pass
    };
    ///Api obj
    let webinarMeeting_obj = {
        "meeting_id": props.webinarID > 0 ? getmeetId : "",
        "register_id": props.webinarID > 0 ? getRegid : "",
        "registration_link": props.webinarID > 0 ? getRegLink : "",
        "moderators": moderators,
        "attendees": attendees,
        "title": title,
        "description": desc,
        "recurrence": recurValue != "N" ? true : false,
        "recur_type": recurValue,
        "recur_data": getinterval,
        "oc_user": oc_user,
        "start_time": datesRemovedZone,
        "duration": parseInt(duration),

        "timezone": selectedTimezone,
        "meeting_password": meeting_password,
        "enable_chat": enable_chat,
        "require_invitation": require_invitation,
        "hide_viewers": hide_viewers,
        "record_meeting": record_meeting,
        "require_passcode": req_pass

    }




    const disablePastDate = () => {
        const today = new Date();
        const dd = String(today.getDate() + 1).padStart(2, "0");
        const mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
        const yyyy = today.getFullYear();
        return yyyy + "-" + mm + "-" + dd;
    };

    const handleTimeZoneModal = () => {
        setShowModal(true)

    }
    const closeTimeZoneModal = (val) => {
        setShowModal(false)
        setSelectedTimezone(val)
        var abbr_tz = val.split(" ")[1]

        setSelectedDisplayTimezone(abbr_tz)

    }
    const closeMeetconf = () => {
        setShowModalConfMeet(false)
        props.setModaCloselData()
    }

    const handleDefaultValue = (val) => {
        setDafaultValue(val)
    }
    let error = false
    const handleOnclickApi = async () => {
        if (!title) {
            error = true;
            setTitleError("Please enter meeting title")
        }
        if (!start_time) {
            error = true;
            setstart_timeError("Please Select Date")
        }
        if (!time) {
            error = true;
            setTimeError("Please select time")
        }

        if (!duration) {
            error = true;
            setDurationError("Please select duration")
        }
        if (!selectedTimezone) {
            error = true;
            selectedTimezoneError
            setSelectedTimezoneError("Please select Timezone")
        }
        if (meeting_password && isNaN(meeting_password)) {
            error = true;
            setpassError("This field allow only numbers")
        }
        if (moderators.length == 0) {
            error = true;
            setModeratorsError("Please add at least one moderators")
        }
        if (defaultValue == 0) {
            if (attendees.length == 0) {
                error = true;
                setAttendeesError("Please add at least one attendee")
            }
        }
        if (error === false) {
            let token = await getAuthToken();
            setAuthTok(token.access)
            setLoaderStart(true);
            if (defaultValue == 0) {
                axios.post(schedule, schedule_obj, {
                    headers: {
                        'Authorization': `Bearer ${token.access}`
                    }
                })

                    .then((response) => {

                        setSuccessRegId(response.data.id)
                        // setShowModalConfMeet(true)
                        setLoaderStart(false)

                        // toast.dismiss();
                        // toast.success("Your conference scheduled successfully", {
                        //     position: "top-right",
                        //     autoClose: 5000,
                        //     hideProgressBar: false,
                        //     closeOnClick: true,
                        //     pauseOnHover: true,
                        //     draggable: true,
                        //     progress: undefined,
                        // });

                        props.setModaCloselData()
                    }, (error) => {
                        toast.error("Something went wrong please try again later", {
                            position: "top-right",
                            autoClose: 5000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                        });
                        console.log(error);
                    });
            }

            if (defaultValue == 1) {

                axios.post(webinarMeeting, webinarMeeting_obj, {
                    headers: {
                        'Authorization': `Bearer ${token.access}`
                    }
                })

                    .then((response) => {

                        setSuccessRegId(response.data.id)
                        setShowModalConfMeet(true)
                        setLoaderStart(false)


                        // props.setModaCloselData()
                    }, (error) => {
                        toast.error("Something went wrong please try again later", {
                            position: "top-right",
                            autoClose: 5000,
                            hideProgressBar: false,
                            closeOnClick: true,
                            pauseOnHover: true,
                            draggable: true,
                            progress: undefined,
                        });
                        console.log(error);
                    });
            }

            // if (props.webinarID > 1) {
            //     console.log("lllllllllllll876")
            //     axios.put(`${webinarMeeting}/${props.webinarID}`, webinarMeeting_obj, {
            //         headers: {
            //             'Authorization': `Bearer ${token.access}`
            //         }
            //     })

            //         .then((response) => {

            //             // setSuccessRegId(response.data.id)
            //             // setShowModalConfMeet(true)
            //             setLoaderStart(false)


            //             // props.setModaCloselData()
            //         }, (error) => {
            //             toast.error("Something went wrong please try again later", {
            //                 position: "top-right",
            //                 autoClose: 5000,
            //                 hideProgressBar: false,
            //                 closeOnClick: true,
            //                 pauseOnHover: true,
            //                 draggable: true,
            //                 progress: undefined,
            //             });
            //             console.log(error);
            //         });
            // }
        }
    }

    const updateData = async () => {

        setLoaderStart(true);
        const token = await getAuthToken();

        axios.put(`${webinarMeeting}/${props.webinarID}`, webinarMeeting_obj, {
            headers: {
                'Authorization': `Bearer ${token.access}`
            }
        })

            .then((response) => {
                setLoaderStart(true);
                // setSuccessRegId(response.data.id)
                // setShowModalConfMeet(true)
                setLoaderStart(false)


                props.setModaCloselData()
            }, (error) => {
                toast.error("Something went wrong please try again later", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
                console.log(error);
            });

    }
    if (props.show) {


        return <Modal
            open={props.show}

        >

            <center style={{
                // width: "1118px",
                // marginLeft: "auto",
                // marginRight: "auto",
            }}>


                <div class="modal-body web-sch-modal mt-3 mb-5" style={{ background: "white" }}>
                    <div className="meetings-Wrapper">
                        {showModal === true ?
                            <div class="modal-dialog modal-lg" >
                                <TimeZoneModal showModal={showModal} closeTimeZoneModal={closeTimeZoneModal} time={time} />

                            </div>
                            : ""}

                    </div>
                    <div className="meetings-Wrapper">
                        {showModalConfMeet === true ?
                            <div class="modal-dialog modal-lg" >
                                <WebinarScheduleConfModal
                                    showModalConfMeet={showModalConfMeet}
                                    closeMeetconf={closeMeetconf}
                                    successRegId={successRegId}
                                    authTok={authTok}
                                />

                            </div>
                            : ""}

                    </div>

                    <div className="meetings-Wrapper">
                        {showWatchModal === true ?
                            <div class="modal-dialog modal-lg" >
                                <WatchModal showWatchModal={showWatchModal}
                                    closeMeetconf={closeMeetconf}
                                    getTimePickerDate={getTimePickerDate}
                                    setTime={setTime}
                                    openClock={openClock}
                                />

                            </div>
                            : ""}

                    </div>



                    <React.Fragment>
                        <div className="container sm-meeting-input larg-modal">
                            <div className="modal_content">
                                <div className="row m-0">
                                    <div className="col-xl-12 col-sm-12  text-white text-start" style={{ height: "46px" }}>
                                        <h3 className="mt-1 meetingText ml-4"> Schedule meeting</h3>
                                        <button type="button" style={{ textAlign: "left", position: "absolute", right: "29px", top: "10px", color: "white" }} class="close schedule-close" data-dismiss="modal" onClick={() => props.setModaCloselData()}>&times;</button>
                                    </div>

                                </div>
                            </div>
                            <div className="row d-flex inputRadius mt-5">

                                <div className="col-xl-6 col-md-6 col-sm-12 mt-5 modal-height">

                                    <div className="row">
                                        <div className="col-md-12">
                                            <form>
                                                <div className="text-danger" style={{ textAlign: "left" }}>{titleError}</div>
                                                <div className="form-group">

                                                    <input type="email"
                                                        value={title}
                                                        className="form-control"
                                                        id="exampleInputEmail1"
                                                        aria-describedby="emailHelp"
                                                        placeholder="Title of Meeting"
                                                        onChange={(e) => getTitle(e)}

                                                    />

                                                    {loaderStart &&
                                                        <div>
                                                            <Loder />
                                                        </div>
                                                    }

                                                </div>
                                                {defaultValue === 1 ?
                                                    <div className="form-group">

                                                        <input type="email"
                                                            value={desc}
                                                            className="form-control"
                                                            id="exampleInputEmail1"
                                                            aria-describedby="emailHelp"
                                                            placeholder="Description (max length 500)"
                                                            maxLength={500}
                                                            onChange={(e) => getDesc(e)}
                                                        />

                                                    </div> :
                                                    <div></div>
                                                }

                                            </form>
                                        </div>
                                    </div>

                                    <div className="text-danger" style={{ textAlign: "left" }}>{start_timeError}</div>
                                    <div className="text-danger" style={{ textAlign: "left" }}>{timeError}</div>
                                    <div className="text-danger" style={{ textAlign: "left" }}>{durationError}</div>
                                    <div className="text-danger" style={{ textAlign: "left" }}>{selectedTimezoneError}</div>

                                    <div className="">
                                        <div className="row">

                                            <div className="col-md-6 col-lg-3">
                                                <input id="past-date" type="date"
                                                    value={start_time}
                                                    className="form-control"
                                                    style={{ Width: "100%", height: "32px" }}
                                                    min={disablePastDate()}
                                                    // onChange={(e)=>getStartDate()
                                                    onChange={(date) => getStartDate(date)}
                                                />


                                                <p className="schedularText">Date</p>
                                            </div>

                                            <div className="col-md-6 col-lg-3">



                                                <Input
                                                    // type={inputType === true ? "time" : ""}
                                                    style={{ width: "116%", height: "32px" }}
                                                    type="text"
                                                    className="form-control hourWidth"
                                                    name="searchText"
                                                    value={time}
                                                    placeholder="hh:mm AM"
                                                    onChange={(e) => setTime(e.target.value)}
                                                    startAdornment={

                                                        <InputAdornment position="start">
                                                            <MDBIcon far
                                                                onClick={() => openWatch()}
                                                                icon="clock" />
                                                        </InputAdornment>
                                                    }
                                                />


                                                <p className="schedularText">Hour</p>
                                            </div>

                                            {/* {openClock &&
                                                    <div>

                                                        <Timekeeper

                                                            time={time}
                                                            onChange={(newTime) => setTime(newTime.formatted12)}
                                                            onDoneClick={() => getTimePickerDate()}

                                                        /></div>
                                                } */}


                                            <div className="col-md-6 col-lg-3">

                                                <select className="custom-select durationDiv ml-0 form-control"
                                                    id="inputGroupSelect01"
                                                    style={{ width: "100%", height: "32px" }}
                                                    onChange={(e) => getDurtion(e)}
                                                >
                                                    <option selected>{props.webinarID > 0 ? duration : "15 min"}</option>
                                                    <option value="30">30 min</option>
                                                    <option value="45">45 min</option>
                                                    <option value="60">01 hour 00 min</option>
                                                    <option value="75">01 hour 15 min</option>
                                                    <option value="90">01 hour 30 min</option>
                                                    <option value="105">01 hour 45 min</option>
                                                    <option value="120">02 hour 00 min</option>
                                                    <option value="135">02 hour 15 min</option>
                                                    <option value="150">02 hour 30 min</option>
                                                    <option value="165">02 hour 45 min</option>
                                                    <option value="180">03 hour 00 min</option>
                                                    <option value="195">03 hour 15 min</option>
                                                    <option value="210">03 hour 30 min</option>
                                                    <option value="225">03 hour 45 min</option>
                                                    <option value="240">04 hour 00 min</option>
                                                    <option value="255">04 hour 15 min</option>
                                                    <option value="270">04 hour 30 min</option>
                                                    <option value="285">04 hour 45 min</option>
                                                    <option value="300">05 hour 00 min</option>
                                                    <option value="315">05 hour 15 min</option>
                                                    <option value="330">05 hour 30 min</option>
                                                    <option value="345">05 hour 45 min</option>
                                                    <option value="360">06 hour 00 min</option>
                                                    <option value="375">06 hour 15 min</option>
                                                    <option value="390">06 hour 30 min</option>
                                                    <option value="405">06 hour 45 min</option>
                                                    <option value="420">07 hour 00 min</option>
                                                    <option value="435">07 hour 15 min</option>
                                                    <option value="450">07 hour 30 min</option>
                                                    <option value="465">07 hour 45 min</option>
                                                    <option value="480">08 hour 00 min</option>
                                                </select>
                                                <p className="schedularText">Duration</p>
                                            </div>



                                            <div className="col-md-6 col-lg-3">
                                                <input className="form-control"
                                                    value={selectedDisplayTimezone}
                                                    onClick={() => handleTimeZoneModal()}
                                                    type="text"
                                                    placeholder="Time Zone"
                                                    style={{ width: "100%", height: "32px" }}
                                                />





                                                <p className="schedularText">Zone</p>
                                            </div>





                                        </div>

                                    </div>

                                    <div className="col-md-12 p-0">
                                        <div className="row d-flex">
                                            <div className="col-md-4">
                                                <select className="custom-select  
                                                 float-left"
                                                    id="inputGroupSelect01"
                                                    onChange={(e) => getOcurance(e)}

                                                >

                                                    <option value="N" selected>{recurValue == "D" ? "Daily" : recurValue == "W" ? "Weekly" : recurValue == "M" ? "Monthly" : recurValue == "Y" ? "Yearly" : "Does Not Recur"}</option>
                                                    {props.webinarID > 0 &&
                                                        <option value="N">Does Not Recur</option>}
                                                    {recurValue != "D" &&
                                                        <option value="D">Daily</option>}
                                                    {recurValue != "W" &&
                                                        <option value="W">Weekly</option>}
                                                    {recurValue != "M" &&
                                                        <option value="M">Monthly</option>}
                                                    {recurValue != "Y" &&
                                                        <option value="Y">Yearly</option>}

                                                </select>
                                            </div>
                                            {occurDay || occurWeekly || occurMonthly === true ?
                                                <div class="mt-2">
                                                    <h6 style={{ fontSize: "12px" }}>Every</h6>
                                                </div> : ""
                                            }
                                            {occurDay || occurWeekly || occurMonthly === true ?
                                                <div className=" form-group col-md-6 col-lg-3">
                                                    <input type="number"
                                                        value={getInterVal}
                                                        class="form-control"
                                                        id="exampleInputEmail1"
                                                        aria-describedby="emailHelp"
                                                        placeholder="Enter Number"
                                                        onChange={(e) => setgetInterVal(e.target.value)}
                                                        min="1" max="31"
                                                    />



                                                </div> : ""
                                            }
                                            {occurDay || occurWeekly || occurMonthly === true ?
                                                <div class="mt-2 schedularText">
                                                    <p>{occurType == "D" ? "day" : occurType == "M" ? "month" : occurType == "W" ? "week" : ""}</p>
                                                </div> : ""
                                            }
                                            {occurMonthly &&
                                                <div className=" form-group col-md-6 col-lg-3">
                                                    <select className="custom-select  
                                                 float-left"
                                                        id="inputGroupSelect01"
                                                        onChange={(e) => getEnds(e)}

                                                    >
                                                        <option value="N" selected>On the {dd}th</option>
                                                        <option value="D">On the {getWeekOfMonth(new Date())} {myDate()} </option>


                                                    </select>



                                                </div>
                                            }


                                        </div>
                                        <p className="float-left schedularText">Frequency of Meeting</p>
                                    </div>
                                    <br />
                                    {occurWeekly === true ?
                                        <div className="col-md-12"
                                        // onClick={()=>getSelectedDay()} 
                                        >
                                            <div className="row  mt-4 mb-2">
                                                <div onClick={() => getDayValue("SU")} className={sun === true ? "daysSelected" : "days"}>
                                                    S
                                                </div>
                                                <div onClick={() => getDayValue("MO")} className={mon === true ? "daysSelected" : "days"}>
                                                    M
                                                </div>
                                                <div onClick={() => getDayValue("TU")} className={tue === true ? "daysSelected" : "days"}>
                                                    T
                                                </div>
                                                <div onClick={() => getDayValue("WE")} className={wed === true ? "daysSelected" : "days"}>
                                                    W
                                                </div>
                                                <div onClick={() => getDayValue("TH")} className={thu === true ? "daysSelected" : "days"}>
                                                    T
                                                </div>
                                                <div onClick={() => getDayValue("FR")} className={fri === true ? "daysSelected" : "days"}>
                                                    F
                                                </div>
                                                <div onClick={() => getDayValue("SA")} className={sat === true ? "daysSelected" : "days"}>
                                                    S
                                                </div>

                                            </div>
                                            <p className="schedularText">Occuring on these days</p>
                                        </div> : ""
                                    }
                                    {neveroccur === true ? "" :
                                        <div className="col-md-12 col-sm-12 mt-4 p-0">
                                            <div className="row d-flex" >

                                                <div class="ml-1 mt-2">
                                                    <p className="schedularText" style={{ marginLeft: "9px" }}>Ends</p>
                                                </div>

                                                <div className=" form-group col-md-4">
                                                    <select className="custom-select  
                                                 float-left"
                                                        id="inputGroupSelect01"
                                                        onChange={(e) => getEnds(e)}

                                                    >
                                                        <option value="N" selected>Never</option>
                                                        <option value="DN">On a date</option>


                                                    </select>



                                                </div>
                                                {endsOnDate &&
                                                    <div className=" form-group col-md-4">
                                                        <input
                                                            onChange={(e) => setendDate(e.target.value)}
                                                            type="date" className="form-control" style={{ height: "37px" }} />
                                                    </div>
                                                }
                                            </div>
                                        </div>
                                    }

                                    <div className="col-md-12 col-sm-12 mt-4 text-left p-0">
                                        <div className="row d-flex" >

                                            <div className="col-xl-3 col-md-3 col-sm-12">
                                                <p className="schedularText"> Meeting Type</p>

                                            </div>

                                            <div className="d-flex col-xl-7 col-md-7 col-sm-12" style={{ fontSize: "13px" }}>

                                                <input className="redioBtn"
                                                    type="radio"
                                                    name="selectType"
                                                    checked={defaultValue === 0 ? "checked" : ""}
                                                    onClick={() => handleDefaultValue(0)}
                                                />
                                                <label className="ml-2 mr-4 mb-2" for="basic-url">Conference</label>
                                                <div className={!featureListData ? "redioBtnHover webinarHover" : ""} data-tip={!featureListData ? "Please contact support to enable Webinar features." : ""}
                                                    data-for='inProgress'>

                                                    <input className="ml-1 mr-2 redioBtn"

                                                        type="radio"
                                                        name="selectType"
                                                        checked={defaultValue}
                                                        onClick={() => handleDefaultValue(1)}
                                                        disabled={!featureListData}
                                                    //disabled={true}
                                                    />
                                                    {/* <label className={!featureListData ? "tooltiptext":"dpnone"}   data-tip="Click here to start this meeting">You have No access for webinar</label> */}
                                                    <label
                                                    >Webinar</label>
                                                </div>

                                            </div>
                                        </div>
                                    </div>


                                    <div className="row d-flex justify-content-between mt-4">
                                        <div className="col-12">
                                            <div className="text-danger" style={{ textAlign: "left" }}>{paserror}</div>

                                            <div className="form-group mb-0">

                                                <input type="text"
                                                    value={meeting_password}
                                                    className="form-control"
                                                    id="exampleInputEmail1"
                                                    aria-describedby="emailHelp"
                                                    placeholder="Password"
                                                    onChange={(e) => getPassword(e)}
                                                    style={{ height: "35px" }}

                                                />

                                            </div>
                                        </div>
                                        <div className="col-xl-4 col-md-4 col-sm-12 text-left mt-2">
                                            <p className="mpass ml-0">Meeting Password</p>
                                        </div>
                                        <div className="col-xl-7 col-md-7 col-sm-12 text-right mt-2" style={{ fontSize: "12px" }}>
                                            <span className="mpass mt-2" >Require Password</span>
                                            <span className=" mr-2 ml-2 mt-2">Off</span>
                                            <label className="switch">
                                                <input className="mt-2"
                                                    checked={req_pass}
                                                    onChange={() => getReqPassvalue()}
                                                    type="checkbox" />
                                                <span className="slider round"></span>
                                            </label>
                                            <span className="ml-1">On</span>


                                        </div>
                                    </div>
                                    {/* <Dateschedule defaultValue={defaultValue}/> */}

                                    <div className="row">
                                        <div className="col-md-12 col-xl-12 pl-0" >
                                            <div className="d-flex  mt-4">

                                                <div className="d-flex justify-content-around w-100 webinarPermition" style={{ fontSize: "12px" }}>
                                                    <div className="float-left">Enable Chat
                                                        <br />
                                                        <span className="mr-2 d-inline">off</span>

                                                        <label className="switch">
                                                            <input className="mt-2"
                                                                type="checkbox"
                                                                checked={enable_chat}
                                                                onClick={() => getEnableChatvalue()}
                                                            />
                                                            <span className="slider round"></span>
                                                        </label>

                                                        <span className="ml-1 d-inline">on</span>

                                                    </div>
                                                    {defaultValue === 1 ?
                                                        <div className="float-left">Require Invitation
                                                            <br />
                                                            <span className="mr-2 d-inline">off</span>

                                                            <label className="switch">
                                                                <input className="mt-2" type="checkbox"
                                                                    checked={require_invitation}
                                                                    onClick={() => getRequireInvitation()}
                                                                />
                                                                <span className="slider round"></span>
                                                            </label>

                                                            <span className="ml-1 d-inline">on</span>

                                                        </div> : <div className="d-none"> <span className="ml-2 mr-2 d-inline">off</span>

                                                            <label className="switch">
                                                                <input className="mt-2" type="checkbox" />
                                                                <span className="slider round"></span>
                                                            </label>

                                                            <span className="ml-1 d-inline">on</span></div>
                                                    }

                                                    {defaultValue === 1 ?

                                                        <div className="float-left">Hide viewers
                                                            <br />
                                                            <span className="mr-2 d-inline">off</span>

                                                            <label className="switch">
                                                                <input className="mt-2"
                                                                    checked={hide_viewers}
                                                                    type="checkbox"
                                                                    onClick={() => getHideViwers()}
                                                                />
                                                                <span className="slider round"></span>
                                                            </label>

                                                            <span className="ml-1 d-inline">on</span>

                                                        </div> : <div className="d-none">  <span className="ml-1 mr-2 d-inline">off</span>

                                                            <label className="switch">
                                                                <input className="mt-2" type="checkbox" />
                                                                <span className="slider round"></span>
                                                            </label>

                                                            <span className="ml-1 d-inline">on</span></div>
                                                    }
                                                    <div className="float-left">Record Meeting
                                                        <br />
                                                        <span className="mr-2 d-inline">off</span>

                                                        <label className="switch">
                                                            <input className="mt-2"
                                                                type="checkbox"
                                                                onClick={() => getMeetingRecording()}
                                                            />
                                                            <span className="slider round"></span>
                                                        </label>

                                                        <span className="ml-1 d-inline">on</span>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                                <div class="col-md-1 col-xl-1"><div class="vline mt-4 ml-4"></div></div>
                                <div className=" col-xl-5 col-md-5 col-sm-12 mt-5 ">
                                    {/* {defaultValue === 1 ? */}
                                    <div className="modal-height1">
                                        <div className="text-danger" style={{ textAlign: "left" }}>{moderatorsError}</div>

                                        <div className="form-group">
                                            <label className="float-left" style={{ fontSize: "16px" }}>Add Moderators</label>
                                            <input type="email"
                                                value={modCurrentVaue}
                                                className="form-control"
                                                id="exampleInputEmail1"
                                                aria-describedby="emailHelp"
                                                placeholder="Add by email"
                                                onChange={(e) => getModerators(e)}
                                                onKeyPress={(e) => handleTest(e)
                                                }
                                            />

                                        </div>
                                        <div className="d-inline mt-5">
                                            <ul className="addemail">
                                                {moderators.length > 0 && moderators.map((moder, index) => {
                                                    return (<li>
                                                        <div>
                                                            <div className="d-flex align-items-center">
                                                                {/* <div className="pothoFrame">

                                                        </div> */}
                                                                <div className="ml-2 font-size-75" style={{ fontSize: "14px" }}>{moder}
                                                                    <i className="fas fa-times ml-3" onClick={() => removeEmail(moder)}> </i>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>)




                                                })}

                                            </ul>
                                        </div>
                                        <div className="form-group mt-4">
                                            <div className="text-danger" style={{ textAlign: "left" }}>{attendeesError}</div>

                                            <label className="float-left" style={{ fontSize: "16px" }}>Add Attendees</label>
                                            <input type="email"
                                                className="form-control"
                                                id="exampleInputEmail1"
                                                aria-describedby="emailHelp"
                                                placeholder="Add by email"
                                                value={attCurrentValue}
                                                onChange={(e) => getAttendees(e)}
                                                onKeyPress={(e) => handleTestAttende(e)}
                                            />

                                        </div>
                                        <ul className="addemail">
                                            {attendees.length > 0 && attendees.map((moder, index) => {
                                                return (<li>
                                                    <div>
                                                        <div className="d-flex align-items-center">
                                                            {/* <div className="pothoFrame">
                                                           
                                                        </div> */}
                                                            <div className="ml-2" style={{ fontSize: "14px" }}>
                                                                {moder}
                                                                <i className="fas fa-times"
                                                                    onClick={() => removeEmailAttende(moder)}>
                                                                </i> </div>
                                                        </div>
                                                    </div>
                                                </li>)

                                            })}
                                        </ul>
                                    </div>




                                    <div className="row">
                                        <div className="col-md-12 btndown justify-content-start mt-2">

                                            <button type="button"
                                                style={{ width: "40%", background: "#38A6DE", borderRadius: "8px", color: "#fff" }}
                                                class="btn float-left"
                                                onClick={props.webinarID > 0 ? () => updateData() : () => handleOnclickApi()}
                                            >{props.webinarID > 0 ? "Update" : "Save"}</button>

                                            <button type="button"
                                                style={{ width: "40%", background: "#757575", borderRadius: "8px", color: "#fff" }}
                                                class="btn float-right"
                                                data-dismiss="modal"
                                                onClick={() => props.setModaCloselData()}
                                            >Close
                                            </button>
                                        </div>
                                    </div>

                                </div>


                            </div>
                        </div>

                    </React.Fragment>



                </div>

                <ReactTooltip id='inProgress' />
            </center>
        </Modal >

    }

}
export default WebinarScheduleModal;