import React from 'react'
import Modal from '@material-ui/core/Modal';
import '../newDesign.css';
import Timekeeper from 'react-timekeeper';
import moment from 'moment';
const WatchModal = (props) => {
   
    const { getTimePickerDate, setTime, openClock, time, landingPage,takeTime } = props;

    const crTime = moment().format("hh:mmA");
    if (props.showWatchModal) {

        return (<Modal
            open={props.showWatchModal}
            onClick={() => getTimePickerDate()}
        >

            <div class="modal-body" onClick={(e) => e.stopPropagation()}>
                <div className="text-center">
                    {openClock &&
                        <Timekeeper

                            time={crTime}
                            onChange={landingPage ?  (newTime) =>takeTime(newTime.formatted12) : (newTime) => setTime(newTime.formatted12)}
                            onDoneClick={() => getTimePickerDate()}

                        />
                    }
                </div>

            </div>

        </Modal>
        )
    }
}
export default WatchModal;