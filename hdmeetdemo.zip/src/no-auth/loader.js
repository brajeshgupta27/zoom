import React, { Component } from 'react'
import LoaderImage from '../assets/images/loader.gif';

class Loader extends Component {
    constructor(props) {
        super(props)
        this.state = {
            showLoader: this.props.showLoader
        }
    }
    render() {
        return (
            <div className={this.state.showLoader ? "loaderAlignment d-block" : "loaderAlignment d-none"}>
                <img className={this.props.meetingRegPage == "yes" ? "loaderImgReg" : "loaderImg"} src={LoaderImage} alt="loading..."></img>
            </div>
        )
    }
}

export default Loader