import React, { Component } from 'react';
import Background from '../assets/images/background.png';
import { dialInConfCodeUrl, dialInNumbersUrl } from '../constant/index';
import { MESSAGES } from '../constant/messages'
import './newDesign.css';
import Header from '../no-auth/header';


class DialInInfo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            meeting_Id: this.props.computedMatch.params.meeting_id,
            conf_Pin: '',
            dialin_numbers: {}
        };
    }

    componentDidMount() {
        fetch(dialInConfCodeUrl + this.state.meeting_Id + "@conference.hdmeet.net")
            .then(res => res.json())
            .then(
                (result) => {
                    this.setState({
                        conf_Pin: result.id
                    })
                },
                (error) => {
                    console.log("error", error);
                }
            )

        fetch(dialInNumbersUrl)
            .then(res => res.json())
            .then(
                (result) => {
                    this.setState({
                        dialin_numbers: result.numbers
                    })
                },
                (error) => {
                    console.log("error2", error);
                }
            )
    }

    render() {
        return (
            <div className="appContainer" style={{ backgroundImage: `url(${Background})` }}>
                <div className="mainContainer">
                    <Header />

                    <div className="dbMeetingContainer scheduleContainer">
                        <div className="dialinInfo">
                            <h1>{this.state.meeting_Id}</h1>
                            <p>{MESSAGES.dialTitle}</p>
                            <label>{MESSAGES.pin}: </label><span>{this.state.conf_Pin}</span>
                        </div>
                        <table className="dialinNumber">
                            <thead>
                                <th>{MESSAGES.country}</th>
                                <th>{MESSAGES.dialInNumber}</th>
                            </thead>
                            {Object.keys(this.state.dialin_numbers).map((keyName, i) => (
                                <tr key={i}>
                                    <td>{keyName}</td>
                                    <td>{this.state.dialin_numbers[keyName]}</td>
                                </tr>
                            ))}
                        </table>
                    </div>
                </div>
            </div>
        );
    }
}

export default DialInInfo;