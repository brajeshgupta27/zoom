import React, { Component } from 'react';
import Background from '../assets/images/background.png';
import Loader from '../assets/images/loader.gif';
import './newDesign.css';
import { AvForm, AvField } from 'availity-reactstrap-validation';
import { Link } from 'react-router-dom'
import Header from './header';
import {
    ONE_CLOUD,
    nsApiUrl,
    ocSuperUser,
    ocSuperPassword,
    forgetPassword,
    Baseurl_app
} from '../constant/index';
import { MESSAGES } from '../constant/messages';
import { getAuthToken } from '../helpers/auth-header';

class ForgotPassword extends Component {
    constructor(props) {
        super(props);
        this.state = {
            is_loginForm_visiable: true,
            is_multiUser_visiable: false,
            is_loader_visiable:false,
            one_cloud_access_token: '',
            user_email: '',
            access_token: '',
            users_list: [],
            one_cloud_user_name: '',
            ocUserDomain:'',
            error_msg: MESSAGES.inCorrectUser,
            isAuthenticated: localStorage.getItem('isAuthenticated') ? localStorage.getItem('isAuthenticated') : false,
            userToken: localStorage.getItem('userToken') ? JSON.parse(localStorage.getItem('userToken')) : "",
            showError: false,
            loginWithEmail: true,
            linkSend: false,

        }
        this.loginHandler = this.loginHandler.bind(this);
        this.multiUserResetPassword = this.multiUserResetPassword.bind(this);
        this.getOneCloudOauth = this.getOneCloudOauth.bind(this);
        this.sendForgetPasswordLink = this.sendForgetPasswordLink.bind(this);
    }

    componentWillMount = () => {
        let path = `/user/dashboard`;
        { localStorage.getItem('isAuthenticated') ? this.props.history.push(path) : null }

    }

    loginHandler = async (e) => {
        this.setState({
            showError: false,
        })
        let token = await getAuthToken();
        const authData = await this.getOneCloudOauth(ocSuperUser, ocSuperPassword)
        this.setState({
            access_token: authData.access_token
        })
        const usersData = await this.getOneCloudUsers(token)
    }

    getOneCloudUsers = async () => {
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        myHeaders.append('Authorization', 'Bearer ' + this.state.access_token);
        let fields = {
            format: ONE_CLOUD.format,
            email: this.state.user_email
        }
        let result = await fetch(nsApiUrl + "/?object=subscriber&action=read", {
            method: 'POST',
            headers: myHeaders,
            body: JSON.stringify(fields),
        })
        const data = await result.json()
        this.setState({
            users_list: data,
        })

        if (this.state.users_list.length == 0) {
            this.setState({
                is_loginForm_visiable: true,
                is_multiUser_visiable: false,
                showError: true,
            })
            return
        } else if (this.state.users_list.length == 1) {
            this.setState({
                one_cloud_user_name: this.state.users_list[0].subscriber_login,
                ocUserDomain: this.state.users_list[0].domain,
                is_loginForm_visiable: false,
                is_multiUser_visiable: false,
                showError: false,
                is_loader_visiable:true,
            })
            const resetPassword = await this.sendForgetPasswordLink()
            this.setState({
                is_loader_visiable:false,
                linkSend: true,
            })
        } else {
            this.setState({
                is_multiUser_visiable: true,
                is_loginForm_visiable: false,
                showError: false,
            })
        }
    }

    sendForgetPasswordLink = async () => {
        try {
            let token = await getAuthToken();
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let fields = {
                username: this.state.one_cloud_user_name,
                access_token: this.state.access_token,
                domain: this.state.ocUserDomain,
            }
            let result = await fetch(forgetPassword, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify(fields),
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log("ERROR", error)
        }
    }

    getOneCloudOauth = async (onecloud_username, onecloud_password) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            let fields = {
                format: ONE_CLOUD.format,
                grant_type: ONE_CLOUD.grant_type,
                client_id: ONE_CLOUD.client_id,
                client_secret: ONE_CLOUD.client_secret,
                username: onecloud_username,
                password: onecloud_password,
            }
            let result = await fetch(nsApiUrl + "/oauth2/token", {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify(fields),
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log("ERROR", error)
        }
    }


    multiUserResetPassword = async () => {
        const resetPassword = await this.sendForgetPasswordLink()
        this.setState({
            linkSend: true,
            is_multiUser_visiable: false,
        })
    }

    updateFormValue = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        });
    }

    getSubscriber = (e) => {
        this.setState({
            one_cloud_user_name: e.target.value
        })
    }

    backToLogin() {
        this.setState({
            is_multiUser_visiable: false,
            is_loginForm_visiable: true,
            showError: false,
            loginWithEmail: true,
            users_list: []
        });
    }
    render() {
        return (
            <div className="appContainer" style={{ backgroundImage: `url(${Background})` }}>
                <div className="mainContainer">
                    <Header />
                    <div className="dbMeetingContainer scheduleContainer">
                        <div id="login">
                            <div className="container">
                                <div id="login-row" className="row justify-content-center align-items-center">
                                    <div id="login-box" className="col-md-12">
                                        {this.state.is_loginForm_visiable ?
                                            <AvForm id="login-form" className="form" action="" method="post" onValidSubmit={this.loginHandler}>
                                                <div className="form-group">
                                                    <h2 className="forgotPasswordHeading">{MESSAGES.forgotPassword}</h2>
                                                    <p className="forgotPasswordlable">{MESSAGES.passwordResetIntro}</p>
                                                    <AvField
                                                        name="user_email"
                                                        label="Email"
                                                        className="form-control"
                                                        type="text"
                                                        errorMessage="Please enter a valid email address."
                                                        validate={{
                                                            required: { value: true },
                                                            email: { value: true }
                                                        }}
                                                        value={this.state.user_email.trim()}
                                                        onChange={this.updateFormValue}
                                                    />
                                                </div>
                                                {this.state.showError ? <label style={{ color: 'red' }}> {this.state.error_msg}</label> : null}
                                                <div className="form-group text-center">
                                                    <input type="submit" name="submit" className="login-btn" value="SEND" />
                                                </div>
                                                <div id="register-link" className="text-center">
                                                    <Link to="/user/login" className="go-back">{MESSAGES.goback}</Link>
                                                </div>
                                            </AvForm>
                                            : null
                                        }
                                        {
                                            this.state.is_multiUser_visiable ?
                                                <AvForm id="" className="form" action="" method="post" onValidSubmit={this.multiUserResetPassword}>
                                                    <div className="user-accounts">
                                                        <p className="user-accounts-title">{MESSAGES.selectAnAccountToLogInWith}</p>

                                                        <div className="account-list">
                                                            <p className="user-accounts-titlepara">{MESSAGES.allAccounts}</p>
                                                            <ul>
                                                                {
                                                                    this.state.users_list.map((keyName, i) => (
                                                                        <li className="account-listItem" key={i}>
                                                                            <div className="form-check">
                                                                                <label className="form-check-label">
                                                                                    <input type="radio" className="form-check-input" name="optradio" value={keyName.subscriber_login} onChange={this.getSubscriber} />{keyName.first_name + " " + keyName.last_name}
                                                                                </label><br />
                                                                                <span>{keyName.subscriber_login}</span><br />
                                                                                <span>{keyName.domain}</span>
                                                                            </div>
                                                                        </li>
                                                                    ))
                                                                }
                                                            </ul>
                                                        </div>

                                                        <div className="form-group text-center">
                                                            <input type="submit" name="submit" className="login-btn" value="Send" />
                                                        </div>
                                                        <div id="register-link" className="text-center">
                                                            <p className="go-back m-0">{MESSAGES.connectDifferentAccount}</p>
                                                            <a href="#" className="go-back" onClick={() => this.backToLogin()} >{MESSAGES.backToLogin}</a>
                                                        </div>
                                                    </div>
                                                </AvForm>
                                                : null
                                        }
                                        {
                                            this.state.linkSend ?
                                                <div className="text-center">
                                                    <p>{MESSAGES.linkSuccessfullySent}</p>
                                                    <Link to="/" >{MESSAGES.goTo + " " + Baseurl_app}</Link>
                                                </div>
                                                :
                                                null
                                        }
                                        {
                                        this.state.is_loader_visiable ?
                                            <img className="loaderImage" src={Loader} alt="loaderImage"></img>
                                            : null
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default ForgotPassword;