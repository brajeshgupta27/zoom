import React, { Component } from 'react';
import Background from '../assets/images/background.png';
import StartMeetingIcon from '../assets/images/StartMeetingIcon.png';
import ScheduleIcon from '../assets/images/ScheduleIcon.png';
import JoinIcon from '../assets/images/JoinIcon.svg';
import CopyIcon from '../assets/images/copyIcon.png';
import EmailIcon from '../assets/images/emailIcon.png';
import GoogleStoreIcon from '../assets/images/play-store.svg';
import AppleStoreIcon from '../assets/images/app-store.svg';
import './newDesign.css';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import { AvForm, AvField } from 'availity-reactstrap-validation';
import Header from '../no-auth/header';
import axios from "axios"

import { toast } from 'react-toastify';
import Footer from "./footer"
import jstz from 'jstz';
import {
    gettoken,
    Baseurl_invite,
    appleStoreUrl,
    googleStoreUrl,
    backendMeetingApi,
    OneCloudGuestUserID,
    // GuestMaxUserLimit,
    // OneCloudMaxUserLimit,
    Baseurl_app,
    getFeatureFromMeetingIdApi,
    attendeewebdetail,
    addAttendeeCount
} from '../constant/index';

import { getAuthToken } from '../helpers/auth-header';
import { MESSAGES } from '../constant/messages';
import meetingReg from './meetingRegComponent/meetingReg';

class LandingPage extends Component {
    constructor(props) {
        console.log(props,"props")
        super(props);
        this.state = {
            cname: this.props.computedMatch.params.host_type ? (atob(this.props.computedMatch.params.host_type) === "true") ? ((this.props.computedMatch.params.meeting_id) ? atob(this.props.computedMatch.params.meeting_id) :
                Math.floor(Math.random() * 900000000 + 100000000)) : '' : (Math.floor(Math.random() * 900000000 + 100000000)),
            // value: '', NOTE:: will be used later
            // dispname: 'name', NOTE:: will be used later
            joincname: this.props.computedMatch.params.meeting_id ? this.props.computedMatch.params.meeting_id : "",
            // joincpassword: '', NOTE:: will be used later
            // joindispname: this.props.computedMatch.params.host_type ? ((atob(this.props.computedMatch.params.host_type) === "false") ? ((this.props.computedMatch.params.host_name) ? atob(this.props.computedMatch.params.host_name) : '') : '') : '',
            
            s_audio:  this.getCookie('s_audio') !== null ? this.getCookie('s_audio') : 'a_on',
            s_video: this.getCookie('s_video') !==null ? this.getCookie('s_video') : 'v_on',
            isAudioChecked:true,
            isVideoChecked:true,
            invalid_time: false,
            schedule: false,
            start: true,
            isModerator: false,
            landing: false,
            meetingId: '',
            joinMeetingPopup: this.props.computedMatch.params.meeting_id ? true : false,
            scheduleMeetingPopup: false,
            invitation_url: '',
            copied: false,
            isAuthenticated: localStorage.getItem('isAuthenticated') ? localStorage.getItem('isAuthenticated') : false,
            current_meeting_data: {},
            meetingUrl: '',
        };
    console.log(this.state,"stated data 0000")
        // this.joinMeetingInput = React.createRef();
        this.handleChange = this.handleChange.bind(this);
        this.myStartSubmitHandler = this.myStartSubmitHandler.bind(this);
        this.myJoinSubmitHandler = this.myJoinSubmitHandler.bind(this);
        this.invitation_urlWithJWT = this.invitation_urlWithJWT.bind(this);
        this.getCookie = this.getCookie.bind(this);
    }

getCookie(name) {
    var dc = document.cookie;
    var prefix = name + "=";
    var begin = dc.indexOf("; " + prefix);
    if (begin == -1) {
        begin = dc.indexOf(prefix);
        if (begin != 0) return null;
    }
    else
    {
        begin += 2;
        var end = document.cookie.indexOf(";", begin);
        if (end == -1) {
        end = dc.length;
        }
    }
    return decodeURI(dc.substring(begin + prefix.length, end));
} 

  async componentDidMount() {
        const query = new URLSearchParams(this.props.location.search);
       console.log(query,"query")
        if (query.has('attendee')){
            let token = await getAuthToken();
            const attendee = query.get('attendee')
            axios.get(`${attendeewebdetail}/${attendee}`,{
                headers: {
                    'Authorization':  `Bearer ${token.access}`
                  }
                })
            .then((response) => {
                // setData(response.data.Result)
               
                this.setState({joincname:response.data.Result.meeting_id})
                this.props.history.push('/startwebinar/' + this.state.joincname + '/a_on/v_on/' + response.data.Result.attendee_token);
                axios.put(addAttendeeCount,
                    {"meeting_url":attendee},{
                    headers: {
                        'Authorization':  `Bearer ${token.access}`
                      }
                    })
                .then((response_data)=>{
                    console.log("Response Data::", response_data)
                })
            }, (error) => {

                console.log(error);
            });
            
       
        }else if(query.has('token')){
            const token = query.get('token')
         
            this.props.history.push('/startwebinar/' + this.state.joincname + '/a_on/v_on/' + token);
        }
        
        // if (token && this.props.computedMatch.params.meeting_id) {
        //     console.log("99::")
        //     // this.props.history.push('/startconference/' + this.props.computedMatch.params.meeting_id + '/a_on/v_on/' + token);
        // }
        // console.log("token1::", token)
        if (this.props.computedMatch.params.host_type) {
           
            this.setState({ joincname: atob(this.props.computedMatch.params.meeting_id) })
        }

        if ((this.props.computedMatch.params.start) && (this.props.computedMatch.params.end)) {
          
            const current_time = new Date().getTime();
            if (current_time < atob(this.props.computedMatch.params.start) || atob(this.props.computedMatch.params.end) < current_time) {
                this.setState({
                    invalid_time: true
                });
                
                toast.dismiss();
                toast.error("Meeting cannot be started", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            } else if (this.props.computedMatch.params.host_type) {
              
                let moderator = false
                if (atob(this.props.computedMatch.params.host_type) == "true") {
                    moderator = true
                }
                this.setState({
                    joincname: atob(this.props.computedMatch.params.meeting_id),
                    isModerator: moderator
                })
            }
        }
        if (this.props.computedMatch.params.host_type) {
      
            this.props.history.push('/' + atob(this.props.computedMatch.params.meeting_id));
        }
    }

    invitation_urlWithJWT = async () => {
        let token = await getAuthToken();
        let data = await this.getJwtToken(token, 'start', true);
        let invitation_url = Baseurl_invite + '/startconference/' + this.state.cname + '/' + this.state.s_audio + '/' + this.state.s_video + '/' + data.jwt_token
        this.setState({ invitation_url: invitation_url })
    }

    componentDidUpdate() {
        if (this.state.copied) {
            this.timeout = setTimeout(() => {
                this.setState({ copied: false });
            }, 1000);
        }
    }

    componentWillUnmount() {
        clearTimeout(this.timeout);
    }

    showJoinMeeting = () => {
        this.setState({ scheduleMeetingPopup: false })
        this.setState({ joinMeetingPopup: true })
        // this.joinMeetingInput.current.focus();
    }
    showScheduleMeeting = () => {
        this.setState({ joinMeetingPopup: false })
        this.setState({ scheduleMeetingPopup: true })
    }
    popupBoxCancelBtn = (e) => {
        e.stopPropagation()
        this.setState({ joincname: '' })
        this.setState({ joinMeetingPopup: false })
        this.setState({ scheduleMeetingPopup: false })
    }

    myStartSubmitHandler = async () => {
        let token = await getAuthToken();
        let getMeetingsFromMeetingId = await this.getMeetingsFromMeetingId(token, this.state.cname)
        if (getMeetingsFromMeetingId.multiple == false && Object.keys(getMeetingsFromMeetingId.detail).length == 0) {
            let data = await this.getJwtToken(token, 'start');
            const createMeetingUrl = Baseurl_app + '/startconference/' + this.state.cname + '/' + this.state.s_audio + '/' + this.state.s_video + '/' + data.jwt_token
            this.setState({
                meetingUrl: createMeetingUrl
            })
            let current_meeting_data = await this.createBackendMeeting(token)
            this.setState({
                current_meeting_data: current_meeting_data
            })
            localStorage.setItem("current_meeting_data", JSON.stringify(current_meeting_data))
            this.redirectConf(data, 'start')
        } else if (getMeetingsFromMeetingId.multiple == false && Object.keys(getMeetingsFromMeetingId.detail).length > 0) {
            toast.dismiss();
            toast.error("Meeting Already In-Progress for given meetingID", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        } else {
            toast.dismiss(); //NOTE: future possiablities
            toast.error("Meeting Already In-Progress for given meetingID", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }

    myJoinSubmitHandler = async () => {
        let OneCloudMaxUserLimit = 0;
        let GuestMaxUserLimit = 0;
        let token = await getAuthToken();
        let getMeetingsFromMeetingId = await this.getMeetingsFromMeetingId(token, this.state.joincname)
        let getFeatureFromMeetingId = await this.getFeatureFromMeetingId(token, this.state.joincname)

        if (getMeetingsFromMeetingId.multiple == false && getMeetingsFromMeetingId.detail.auth_user == false) {
            GuestMaxUserLimit = getFeatureFromMeetingId.Result.web_participants
        }
        else if (getMeetingsFromMeetingId.multiple == false && getMeetingsFromMeetingId.detail.auth_user == true) {
            OneCloudMaxUserLimit = getFeatureFromMeetingId.Result.web_participants
        }

        if (getMeetingsFromMeetingId.multiple == false && Object.keys(getMeetingsFromMeetingId.detail).length == 0) {
            let data = await this.getJwtToken(token, 'join');
            this.redirectConf(data, 'join')
        } else if ((getMeetingsFromMeetingId.multiple == false
            && Object.keys(getMeetingsFromMeetingId.detail).length > 0)
            && getMeetingsFromMeetingId.detail.status == "I") {
            if (getMeetingsFromMeetingId.detail.auth_user == false && getMeetingsFromMeetingId.detail.current_attendees < GuestMaxUserLimit) {
                let data = await this.getJwtToken(token, 'join');
                this.redirectConf(data, 'join')
            } else if (getMeetingsFromMeetingId.detail.auth_user == true && getMeetingsFromMeetingId.detail.current_attendees < OneCloudMaxUserLimit) {
                let data = await this.getJwtToken(token, 'join');
                this.redirectConf(data, 'join')
            } else {
                toast.dismiss();
                toast.error(MESSAGES.maxParticipant, {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                });
            }
        } else {
            toast.dismiss();
            toast.error("Cannot join the meeting", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
            });
        }
    }


    getMeetingsFromMeetingId = async (token, meeting_id) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(backendMeetingApi + "/" + meeting_id, {
                method: 'GET',
                headers: myHeaders,
            })
            const data = await result.json()
          
            return data
        } catch (error) {
            console.log(error)
        }
    }

    getFeatureFromMeetingId = async (token, meeting_id) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(getFeatureFromMeetingIdApi, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify({
                    current_meeting_id: meeting_id,
                })
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log(error)
        }
    }


    createBackendMeeting = async (token) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(backendMeetingApi, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify({
                    meeting_id: this.state.cname,
                    meeting_name: "GuestRoom",
                    oc_user: OneCloudGuestUserID,
                    current_attendees: 1, // NOTE: Need to check 
                    total_attendees: 1, // NOTE: Need to check 
                    auth_user: false,
                    max_limit_reached: false,
                    status: 'I',
                    is_scheduled: false,
                    meeting_url: this.state.meetingUrl
                }),
            })
            const data = await result.json()
            
            return data
        } catch (error) {
            console.log(error)
        }
    }

    getJwtToken = async (token, participant, isSixMonthExpiry = false) => {
        let room_name = this.state.cname
        let moderator = true
        if (participant === "join") {
            room_name = this.state.joincname
            moderator = false
        }
        let obj
        if (isSixMonthExpiry) {
            const timezone = jstz.determine();
            obj = {
                room: room_name,
                is_mod: moderator,
                isSixMonthExpiry: true,
                timeZone: timezone.name()
            }

        } else {
            obj = {
                room: room_name,
                is_mod: moderator,
                isSixMonthExpiry: false
            }
        }
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(gettoken, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify(obj),
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log(error)
        }
    }

    redirectConf = (data, participant) => {
        let cname;
        if (participant === 'start') {
            cname = this.state.cname
        }
        else if (participant === 'join') {
            cname = this.state.joincname
        }
        this.props.history.push('/startconference/' + cname + '/' + this.state.s_audio + '/' + this.state.s_video + '/' + data.jwt_token);
    }

    // Set a Cookie
        setCookie = (cName, cValue, expDays) =>{
            let date = new Date();
            date.setTime(date.getTime() + (expDays * 24 * 60 * 60 * 1000));
            const expires = "expires=" + date.toUTCString();
            document.cookie = cName + "=" + cValue + "; " + expires + "; path=/";
        }


    handleChange(event) {
        if (event.target.name === "s_audio") {
            let audio_mute = "a_off"
            if (event.target.checked) {
                audio_mute = "a_on";
            } else {
                audio_mute = "a_off";
            }
            this.setState({
                [event.target.name]: audio_mute,
                isAudioChecked: !this.state.isAudioChecked,
            });
            this.setCookie('s_audio', audio_mute, 30);

        } else if (event.target.name === "s_video") {
            let video_mute = "v_off"
            if (event.target.checked) {
                video_mute = "v_on"
            } else {
                video_mute = "v_off"
            }
            this.setState({
                [event.target.name]: video_mute,
                isVideoChecked: !this.state.isVideoChecked,
            });
            this.setCookie('s_video', video_mute, 30);
        } else {
            const value = event.target.value;
            this.setState({
                [event.target.name]: value
            });
        }
    }
    scheduleMeeting = () => {
        this.props.history.push('/schedule/meeting/');
    }

    render() {
        return (
            <React.Fragment>
                {!this.state.isAuthenticated ?
                <div></div>
                   : <div></div>}
              
            </React.Fragment>
        );
    }
}

export default LandingPage;