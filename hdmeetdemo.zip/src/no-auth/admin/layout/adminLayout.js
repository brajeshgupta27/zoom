import React, { Component } from "react";
import { useLocation, Route, Switch, Redirect } from "react-router-dom";
import "../adminStyle.css"

import AdminNavbar from "../adminComponents/AdminNavbar";
// import Footer from "../adminComponents/Footer";
import Sidebar from "../adminComponents/Sidebar";
// import FixedPlugin from "../adminComponents/FixedPlugin";

import AdminRoutes from "../AdminRoute";

import sidebarImage from "../../../assets/images/sidebar-5.jpg";

function AdminLayout(props) {
  const [image, setImage] = React.useState(sidebarImage);
  const [color, setColor] = React.useState("black");
  const [hasImage, setHasImage] = React.useState(true);
  const [isAdminLogin, setIsAdminLogin] = React.useState(localStorage.getItem("isAdminLogin")?localStorage.getItem("isAdminLogin"):false)
  const location = useLocation();
  const mainPanel = React.useRef(null);
  const getRoutes = (AdminRoutes) => {
    return AdminRoutes.map((prop, key) => {
      if (prop.layout === "/hdmeetadmin" && isAdminLogin) {
        return (
          <Route
            path={prop.layout + prop.path}
            render={(props) => <prop.component {...props} />}
            key={key}
          />
        );
      } else {
        return null;
      }
    });
  };
  React.useEffect(() => {
    document.documentElement.scrollTop = 0;
    document.scrollingElement.scrollTop = 0;
    mainPanel.current.scrollTop = 0;
    if (
      window.innerWidth < 993 &&
      document.documentElement.className.indexOf("nav-open") !== -1
    ) {
      document.documentElement.classList.toggle("nav-open");
      var element = document.getElementById("bodyClick");
      element.parentNode.removeChild(element);
    }
  }, [location]);
  if (isAdminLogin){
  return (
    
    // {isAdminLogin ? 
      <div className="wrapper">
        {/* <Sidebar color={color} image={hasImage ? image : ""} AdminRoutes={AdminRoutes} /> */}
        <Sidebar color={color} image={hasImage ? image : ""} AdminRoutes={AdminRoutes} />
        <div className="main-panel" ref={mainPanel}>
          <AdminNavbar />
          <div className="content">
            <Switch>{getRoutes(AdminRoutes)}</Switch>
          </div>
          {/* <Footer /> */}
        </div>
      </div>
      // : <Redirect to='/hdmeetadmin/login'/>}
  );
  }
  else{   
      <div>
        {document.location.href = '/hdmeetadmin/login'}
      </div>
    
}
}

export default AdminLayout;
