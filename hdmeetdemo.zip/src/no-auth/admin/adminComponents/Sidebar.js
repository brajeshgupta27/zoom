import React from "react";
import { useLocation, NavLink } from "react-router-dom";

import { Nav } from "react-bootstrap";

// import Logo from "";
import SideBarLogo from "../../../assets/images/hdmeet_admin_logo.png";

function Sidebar({ color, AdminRoutes }) {
  const location = useLocation();
  const activeRoute = (AdminRoutesName) => {
    return location.pathname.indexOf(AdminRoutesName) > -1 ? "active" : "";
  };
  return (
    <div className="sidebar" data-color={color}>
      {/* <div
        className="sidebar-background"
        style={{
          backgroundImage: "url(" + image + ")",
        }}
      /> */}
      <div className="sidebar-wrapper">
        <div className="logo d-flex align-items-center justify-content-start">
          <a
            href="/"
            className="simple-text logo-mini mx-1"
          >
            <div className="logo-img">
              <img
                src={SideBarLogo}
                alt="..."
              />
            </div>
          </a>
          <a className="simple-text" href="/">
           HDMeet
          </a>
        </div>
        <Nav>
          {AdminRoutes.map((prop, key) => {
            if (!prop.redirect)
              return (
                <li
                  className={
                    prop.upgrade
                      ? "active active-pro"
                      : activeRoute(prop.layout + prop.path)
                  }
                  key={key}
                >
                  <NavLink
                    to={prop.layout + prop.path}
                    className="nav-link"
                    activeClassName="active"
                  >
                    <i className={prop.icon} />
                    <p>{prop.name}</p>
                  </NavLink>
                </li>
              );
            return null;
          })}
        </Nav>
      </div>
    </div>
  );
}

export default Sidebar;
