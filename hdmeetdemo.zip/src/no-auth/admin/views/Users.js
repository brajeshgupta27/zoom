import React, { Component } from "react";
import {
  getAllUsersApi,
  getAllScopesApi,
  getAllDomainApi,
  getAllDomainUserListApi,
  forgetPassword,
  sendWelcomeEmail,
  getParticularUserList,
  defaultScopeId,
  getAllfeatureApi
} from '../../../constant/index';
import {
  Card,
  Table,
  Container,
  Row,
  Col,
  Modal,
  Button,
  Dropdown,
} from "react-bootstrap";
import { Form } from "react-bootstrap";
import { toast } from 'react-toastify';
import { getAuthToken } from '../../../helpers/auth-header';
import { AvForm, AvField, AvSelect } from 'availity-reactstrap-validation';
// import Select from 'react-select';

class Users extends Component {
  constructor(props) {
    super(props)
    this.state = {
      showAddUserModal: false,
      showEditUserModal: false,
      confirmChangeScopeModal: false,
      userList: [],
      scopes: [],
      domainList: [],
      domainUserList: [],
      display_name: '',
      current_meeting_id: '',
      meeting_ids: [],
      sendUserEditDetail: {},
      ocScope: '',
      webinarScope: '',
      showDomainTable: false,
      selectedImportUser: [],
      changeScopeID: '',
      changeUserId: '',
      featureList:[],
      featureData:[],
    }
     

    this.getDomainList = this.getDomainList.bind(this);
    this.getUserListFromDomain = this.getUserListFromDomain.bind(this);
    this.sendUserEditId = this.sendUserEditId.bind(this);
    this.saveEditUser = this.saveEditUser.bind(this);
  }

  componentDidMount() {
    this.getAllUsers()
    this.getisWebinarScope()
  }


  
  getAllUsers = async() =>{
    let token = await getAuthToken();
    const myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    myHeaders.append('Authorization', 'Bearer ' + token.access);

    const requestOptions = {
      method: 'GET',
      headers: myHeaders
    };

    fetch(getAllUsersApi, requestOptions)
      .then(res => res.json())
      .then(
        (result) => {
          this.setState({
            userList: result.Result
          })
          if (result.CodeStatus !== 200) {
            toast.dismiss();
            toast.error(`${result.Messages}`, {
              position: "top-right",
              autoClose: 5000,
              hideProgressBar: true,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
            });
          }
        },
        (error) => {
          console.log("error", error);
        }
      )

    fetch(getAllScopesApi, requestOptions)
      .then(res => res.json())
      .then(
        (result) => {
          this.setState({
            scopes: result.Result
          })
          if (result.CodeStatus !== 200) {
            toast.dismiss();
            toast.error(`${result.Messages}`, {
              position: "top-right",
              autoClose: 5000,
              hideProgressBar: true,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
            });
          }
        },
        (error) => {
          console.log("error", error);
        }
      )

      fetch( getAllfeatureApi, requestOptions)
      .then(res => res.json())
      .then(
        (result) => {
         
          this.setState({
            featureList: result.Result
          })
          if (result.CodeStatus !== 200) {
            toast.dismiss();
            toast.error(`${result.Messages}`, {
              position: "top-right",
              autoClose: 5000,
              hideProgressBar: true,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
            });
          }
        },
        (error) => {
          console.log("error", error);
        }
      )
  }

  sendSelectedOcScope = (event) => {
    this.setState({
      ocScope: event.target.value
    });
  }
  sendSelectedWebinarScope = (event) => {
    this.setState({
      webinarScope: event.target.value
    });
  }

  updateFormValue = (event) => {
    this.setState({
      [event.target.name]: event.target.value
    });
  }

  updateMeetingId = (event) => {
    let updatedMeetingIDArr = event.target.value.trim().split(",");
    this.setState({
      meeting_ids: updatedMeetingIDArr
    });
  }

  updateImportUser = (event) => {
    if (event.target.checked) {
      this.state.selectedImportUser.push(event.target.id);
    }
    else {
      this.state.selectedImportUser = this.state.selectedImportUser.filter((elem) => {
        return elem != event.target.id;
      })
    }
  }

  createUserData = () => {
    var userListToImport = this.state.domainUserList.filter((elem) => {
      return this.state.selectedImportUser.includes(elem.user);
    })

    userListToImport.map((elem) => {
      let elemScope = document.getElementById(`user${elem.user}`).value
      elem.username = elem.subscriber_login
      elem.domain = elem.domain_name
      elem.display_name = elem.first_name + ' ' + elem.last_name
      elem.meeting_ids = [elem.domain_name + '-' + elem.user]
      elem.current_meeting_id = elem.domain_name + '-' + elem.user
      elem.uid = elem.subscriber_login
      elem.scope = 'initial'
      elem.oc_scope = elemScope
    })
    return userListToImport;
  }

  importUserData = async () => {
    let token = await getAuthToken();
    var userList = this.createUserData();
    if (userList.length == 0) {
      toast.dismiss();
      toast.error("No user selected", {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
    } else {
      try {
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        myHeaders.append('Authorization', 'Bearer ' + token.access);
        let result = await fetch(getAllUsersApi, {
          method: 'POST',
          headers: myHeaders,
          body: JSON.stringify(userList),
        })
        const data = await result.json()
        this.setState({
          showAddUserModal: false
        })
        this.getAllUsers()
        toast.dismiss();
        toast.success("User imported successfully", {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      } catch (error) {
        console.log("ERROR", error)
      }
    }
  }

  confirmChangeScope = (userId, ScopeId) => {
    this.setState({
      changeScopeID: ScopeId,
      changeUserId: userId,
      confirmChangeScopeModal: true,
    })
  }

  resyncUser = async (user) => {
    let token = await getAuthToken();
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let result = await fetch(getParticularUserList, {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify({ domain: user.domain, user: user.user }),
      })
      const data = await result.json()
      this.createResyncUserData(data.data, user.id)
    } catch (error) {
      console.log("ERROR", error)
    }
  }
  getisWebinarScope(scopeId){
    
    var featuredatas=[];
    

    for (let i=0;i<=this.state.featureList.length; i++){
      
      featuredatas= this.state.featureList.filter(feature => feature.oc_scope==this.state.ocScope[i].id && feature.is_webinar)
    }


 
  // this.setState({featureData:featuredatas})
    
     
    
     }
  createResyncUserData = async (resyncuserData, userId) => {
    let resyncPayload = {
      domain: resyncuserData[0].domain_name,
      display_name: resyncuserData[0].first_name + " " + resyncuserData[0].last_name,
      scope: resyncuserData[0].scope,
      username: resyncuserData[0].subscriber_login,
      user: resyncuserData[0].user,
    }
    let token = await getAuthToken();
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let result = await fetch(getAllUsersApi + "/" + userId, {
        method: 'PUT',
        headers: myHeaders,
        body: JSON.stringify(resyncPayload),
      })
      const data = await result.json()
  
      if (data.CodeStatus == 200) {
        toast.dismiss();
        toast.success(`${data.Messages}`, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      } else {
        toast.dismiss();
        toast.error(`${data.Messages}`, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      }
    } catch (error) {
      console.log("ERROR", error)
    }
  }

  async getDomainList() {
    this.setState({ showAddUserModal: true })
    let token = await getAuthToken();
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let result = await fetch(getAllDomainApi, {
        method: 'GET',
        headers: myHeaders,
      })
      const data = await result.json()
      this.setState({
        domainList: data.data
      })
    } catch (error) {
      console.log("ERROR", error)
    }
  }

  sendWelcomeEmail = async (domain, userName) => {
    let token = await getAuthToken();
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let fields = {
        username: userName,
        access_token: token.access,
        domain: domain,
      }
      let result = await fetch(sendWelcomeEmail, {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify(fields),
      })
      const data = await result.json()
      toast.dismiss();
      toast.success("Welcome email have been send to the registered email", {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
      return data
    } catch (error) {
      console.log("ERROR", error)
    }
  }

  resetPassword = async (domain, userName) => {
    try {
      let token = await getAuthToken();
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let fields = {
        username: userName,
        access_token: token.access,
        domain: domain,
      }
      let result = await fetch(forgetPassword, {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify(fields),
      })
      const data = await result.json()
      toast.dismiss();
      toast.success("Reset Password link have been send to the registered email ID", {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
      return data
    } catch (error) {
      console.log("ERROR", error)
    }
  }

  async sendUserEditId(userId) {
    this.setState({ showEditUserModal: true })
    let token = await getAuthToken();
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let result = await fetch(getAllUsersApi + `/${userId}`, {
        method: 'GET',
        headers: myHeaders,
      })
      const data = await result.json()
      this.setState({
        sendUserEditDetail: data.Result,
        display_name: data.Result.display_name,
        current_meeting_id: data.Result.current_meeting_id,
        meeting_ids: data.Result.meeting_ids,
        ocScope: data.Result.oc_scope,
        webinarScope: data.Result.webinar_scope
      })
    } catch (error) {
      console.log("ERROR", error)
    }
  }

  updateScope = async (decision) => {
    let token = await getAuthToken();
    if (decision) {
      try {
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        myHeaders.append('Authorization', 'Bearer ' + token.access);
        let result = await fetch(getAllUsersApi + "/" + this.state.changeUserId, {
          method: 'PUT',
          headers: myHeaders,
          body: JSON.stringify({ oc_scope: this.state.changeScopeID }),
        })
        const data = await result.json()
       
        this.setState({ confirmChangeScopeModal: false })
        if (data.CodeStatus == 200) {
          toast.dismiss();
          toast.success(`${data.Messages}`, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
        } else {
          toast.dismiss();
          toast.error(`${data.Messages}`, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
        }
      } catch (error) {
        console.log("ERROR", error)
        this.setState({ confirmChangeScopeModal: false })
      }
    } else {
      this.setState({ confirmChangeScopeModal: false })
    }
  }

  async saveEditUser(userId) {
    let token = await getAuthToken();
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let result = await fetch(getAllUsersApi + `/${userId}`, {
        method: 'PUT',
        headers: myHeaders,
        body: JSON.stringify({
          display_name: this.state.display_name,
          current_meeting_id: this.state.current_meeting_id,
          meeting_ids: this.state.meeting_ids,
          oc_scope: this.state.ocScope,
          webinar_scope: this.state.webinarScope
        }),
      })
      const data = await result.json()
      this.setState({ showEditUserModal: false })
      if (data.CodeStatus == 200) {
        toast.dismiss();
        toast.success(`${data.Messages}`, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      } else {
        toast.dismiss();
        toast.error(`${data.Messages}`, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      }
    } catch (error) {
      console.log("ERROR", error)
    }
  }


  async getUserListFromDomain(e) {
    e.persist();
    let token = await getAuthToken();
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let result = await fetch(getAllDomainUserListApi, {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify({ domain: e.target.value }),
      })
      const data = await result.json()
      this.setState({
        domainUserList: data.data,
        showDomainTable: true,
      })
    } catch (error) {
      console.log("ERROR", error)
    }
  }

  render() {
    var featuredatas=[];
    var filterd_scope=[];
    
    featuredatas = this.state.featureList.filter((item)=>{
                      return item.is_webinar
                  })

    
    
    featuredatas.map((item)=>{
      var filterd_scope_ = this.state.scopes.filter((elem)=>{
        return elem.id == item.oc_scope
        
      })
      filterd_scope.push(filterd_scope_[0])
   
      // item['oc_scope_name'] = filterd_scope[0].name
    })

 
    for (let i=0;i<=this.state.featureList.length; i++){
      
      featuredatas= this.state.featureList.filter(feature => feature.oc_scope==this.state.ocScope[i] && feature.is_webinar)
    }
    
    return (
      <div>
        <Container fluid>
          <Row>
            <Col md="12">
              <Card className="strpied-tabled-with-hover">
                <Card.Header className="userHeader">
                  <Card.Title as="h4" className="UserHeaderTitle">Users Table </Card.Title>
                  <button className="btn btn-primary inportUserBtn" onClick={this.getDomainList}>Import OC Users</button>
                </Card.Header>
                <Card.Body className="table-full-width table-responsive px-0 py-0 overflowTable">
                  <Table className="table-hover table-striped tableAlignment">
                    <thead>
                      <tr>
                        {/* <th className="border-0">ID</th> */}
                        <th className="border-0">username</th>
                        <th className="border-0">email address</th>
                        <th className="border-0">DisplayName</th>
                        <th className="border-0">HDMeet Scope</th>
                        <th className="border-0">Current MeetingID</th>
                      </tr>
                    </thead>
                    <tbody>
                      {this.state.userList.map((user, i) => (
                        <tr key={i}>
                          {/* <td>{i + 1}</td> */}
                          <td>{user.username}</td>
                          <td>{user.email}</td>
                          <td>{user.display_name}</td>
                          <td>
                            <Form.Control
                              as="select"
                              custom
                              onChange={(event) => this.confirmChangeScope(user.id, event.target.value)}
                              size="sm"
                            >
                              {this.state.scopes.map((scope, i) => (
                                <option value={scope.id} key={i} selected={user.oc_scope == scope.id}>{scope.name}</option>
                              ))}
                            </Form.Control>
                          </td>
                          <td>{user.current_meeting_id}</td>
                          <td><i className="fa fa-edit" onClick={() => this.sendUserEditId(user.id)}></i></td>
                          <td>
                            <Dropdown>
                              <Dropdown.Toggle id="dropdown-basic">
                                <i className="fa fa-ellipsis-h" aria-hidden="true"></i>
                              </Dropdown.Toggle>
                              <Dropdown.Menu>
                                <Dropdown.Item onClick={() => this.sendWelcomeEmail(user.domain, user.username,)}>Send Welcome Email</Dropdown.Item>
                                <Dropdown.Item onClick={() => this.resetPassword(user.domain, user.username,)}>Password Reset</Dropdown.Item>
                                <Dropdown.Item onClick={() => this.resyncUser(user)}>Resync User</Dropdown.Item>
                              </Dropdown.Menu>
                            </Dropdown>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </Card.Body>
              </Card>
            </Col>

          </Row>
        </Container>
        <Modal
          show={this.state.showAddUserModal}
          onHide={() => this.setState({ showAddUserModal: false, showDomainTable: false })}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
          size="lg"
        >
          <Modal.Header closeButton>
            <Modal.Title id="example-custom-modal-styling-title">
              Add OC Users
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Row>
              <Col md="2">Domain</Col>
              <Col md="4">
                <Form.Control
                  as="select"
                  custom
                  onChange={this.getUserListFromDomain}
                  size="sm"
                >
                  <option>Select Domain</option>
                  {this.state.domainList.map((domain, i) => (
                    <option value={domain.domain_name} key={i}>{domain.domain_name}</option>
                  ))}
                </Form.Control>
              </Col>
            </Row>
            <Row>
              <Col md="12">
                {this.state.showDomainTable ?
                  <Table className="table-hover table-striped tableAlignment">
                    <thead>
                      <tr>
                        <th className="border-0">Select</th>
                        <th className="border-0">username</th>
                        <th className="border-0">email address</th>
                        <th className="border-0">HDMeet Scope</th>
                      </tr>
                    </thead>
                    <tbody>
                      {this.state.domainUserList.length > 0 && this.state.domainUserList.map((domainUser, i) => (
                        <tr key={i}>
                          <td className="tableDataAlignment"><input type="checkbox" onClick={this.updateImportUser} id={domainUser.user}></input></td>
                          <td className="tableDataAlignment">{domainUser.subscriber_login}</td>
                          <td className="tableDataAlignment">{domainUser.email}</td>
                          <td className="tableDataAlignment">
                            <Form.Control
                              as="select"
                              custom
                              // onChange=''
                              size="sm"
                              id={`user${domainUser.user}`}
                            >
                              {this.state.scopes.map((scope, i) => (
                                <option value={scope.id} selected={scope.id == defaultScopeId} key={i}>{scope.name}</option>
                              ))}
                            </Form.Control>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                  : null}
              </Col>
            </Row>
            <Row>
              <Col md={{ span: 2, offset: 10 }}>
                <Button block onClick={this.importUserData}>Import</Button>
              </Col>
            </Row>
          </Modal.Body>
        </Modal>

        <Modal
          show={this.state.showEditUserModal}
          onHide={() => this.setState({ showEditUserModal: false, sendUserEditDetail: {} })}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
          size="lg"
        >
          <Modal.Header closeButton>
            <Modal.Title id="example-custom-modal-styling-title">
              Edit User
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form>
              <AvForm id="addScopeForm" className="form" action="" method="post" onValidSubmit={() => this.saveEditUser(this.state.sendUserEditDetail.id)}>
                <Form.Group as={Row} controlId="sendUserEditId">
                  <Form.Label column sm="4">Username</Form.Label>
                  <Col sm="8">
                    {/* <Form.Control size="sm" readOnly defaultValue={this.state.sendUserEditDetail.username} /> */}
                    <AvField
                      name="user_name"
                      // label="OneCloud User"
                      className="form-control"
                      type="text"
                      readOnly
                      errorMessage="Please enter a valid User Name."
                      validate={{
                        required: { value: true, errorMessage: 'No space & special characters allowed.' },
                        pattern: { value: '/^[a-zA-Z0-9,-_]+$/', errorMessage: 'No space & special characters allowed.' }
                      }}
                      value={this.state.sendUserEditDetail.username}
                    // onChange={this.addedNewScope}
                    />
                  </Col>

                  <Form.Label column sm="4">User</Form.Label>
                  <Col sm="8">
                    {/* <Form.Control size="sm" readOnly defaultValue={this.state.sendUserEditDetail.user} /> */}
                    <AvField
                      name="user"
                      // label="OneCloud User"
                      className="form-control"
                      type="text"
                      readOnly
                      errorMessage="Please enter a valid User Name."
                      validate={{
                        required: { value: true, errorMessage: 'No space & special characters allowed.' },
                        pattern: { value: '/^[a-zA-Z0-9,-_]+$/', errorMessage: 'No space & special characters allowed.' }
                      }}
                      value={this.state.sendUserEditDetail.user}
                    // onChange={this.addedNewScope}
                    />

                  </Col>

                  <Form.Label column sm="4">Domain</Form.Label>
                  <Col sm="8">
                    {/* <Form.Control size="sm" readOnly defaultValue={this.state.sendUserEditDetail.domain} /> */}
                    <AvField
                      name="domain"
                      // label="OneCloud User"
                      className="form-control"
                      type="text"
                      readOnly
                      errorMessage="Please enter a valid User Name."
                      validate={{
                        required: { value: true, errorMessage: 'No space & special characters allowed.' },
                        pattern: { value: '/^[a-zA-Z0-9,-_]+$/', errorMessage: 'No space & special characters allowed.' }
                      }}
                      value={this.state.sendUserEditDetail.domain}
                    // onChange={this.addedNewScope}
                    />
                  </Col>

                  <Form.Label column sm="4">UID</Form.Label>
                  <Col sm="8">
                    {/* <Form.Control size="sm" readOnly defaultValue={this.state.sendUserEditDetail.uid} /> */}
                    <AvField
                      name="uid"
                      // label="OneCloud User"
                      className="form-control"
                      type="text"
                      readOnly
                      errorMessage="Please enter a valid User Name."
                      validate={{
                        required: { value: true, errorMessage: 'No space & special characters allowed.' },
                        pattern: { value: '/^[a-zA-Z0-9,-_]+$/', errorMessage: 'No space & special characters allowed.' }
                      }}
                      value={this.state.sendUserEditDetail.uid}
                    // onChange={this.addedNewScope}
                    />
                  </Col>

                  <Form.Label column sm="4">OC Scope</Form.Label>
                  <Col sm="8">
                    {/* <Form.Control size="sm" readOnly defaultValue={this.state.sendUserEditDetail.scope} /> */}
                    <AvField
                      name="scope"
                      // label="OneCloud User"
                      className="form-control"
                      type="text"
                      readOnly
                      errorMessage="Please enter a valid User Name."
                      validate={{
                        required: { value: true, errorMessage: 'No space & special characters allowed.' },
                        pattern: { value: '/^[a-zA-Z0-9 ,-_]+$/', errorMessage: 'No space & special characters allowed.' }
                      }}
                      value={this.state.sendUserEditDetail.scope}
                    // onChange={this.addedNewScope}
                    />
                  </Col>

                  <Form.Label column sm="4">Email</Form.Label>
                  <Col sm="8">
                    {/* <Form.Control size="sm" readOnly defaultValue={this.state.sendUserEditDetail.email} /> */}
                    <AvField
                      name="email"
                      // label="OneCloud User"
                      className="form-control"
                      type="text"
                      readOnly
                      errorMessage="Please enter a valid User Name."
                      validate={{
                        required: { value: true, errorMessage: 'No space & special characters allowed.' },
                        pattern: { value: '/^[a-zA-Z0-9,-_]+$/', errorMessage: 'No space & special characters allowed.' }
                      }}
                      value={this.state.sendUserEditDetail.email}
                    // onChange={this.addedNewScope}
                    />
                  </Col>

                  <Form.Label column sm="4">HDMeet Scope</Form.Label>
                  <Col sm="8">
                    <Form.Control
                      as="select"
                      custom
                      onChange={this.sendSelectedOcScope}
                      size="sm"
                    >
                      {this.state.scopes.map((scope, i) => (
                        <option value={scope.id} key={i} selected={this.state.sendUserEditDetail.oc_scope == scope.id}>{scope.name}</option>
                      ))}
                    </Form.Control>
                    {/* <AvSelect name="justTheInput" options={this.state.scopes} required></AvSelect> */}
                  </Col>
                  <Form.Label column sm="4">Webinar Scope</Form.Label>
                  <Col sm="8">
                    <Form.Control
                      as="select"
                      custom
                      onChange={this.sendSelectedWebinarScope}
                      size="sm"
                    >
                      {/* {
                      this.state.scopes.filter((elem) => this.state.featureList.find((feature) => 
                        elem.id === feature.oc_scope && feature.is_webinar))
                        console.log("filter::::", filtered_webinar_scope)

                      } */}
                     
                    {filterd_scope.length>0 && filterd_scope.map((scope, i) => {
                      // console.log(scope.name,"scope88")
                    
                      return(
                         <option value={scope.id} key={i} selected={this.state.sendUserEditDetail.webinarScope == scope.id}>{scope.name}</option>
                       )})}
                    </Form.Control>
                    {/* <AvSelect name="justTheInput" options={this.state.scopes} required></AvSelect> */}
                  </Col>

                  <Form.Label column sm="4">Display Name</Form.Label>
                  <Col sm="8">
                    {/* <Form.Control size="sm" name="display_name" defaultValue={this.state.sendUserEditDetail.display_name}
                      onChange={this.updateFormValue} /> */}

                    <AvField
                      name="display_name"
                      // label="OneCloud User"
                      className="form-control"
                      type="text"
                      errorMessage="Please enter a valid Display Name."
                      validate={{
                        required: { value: true, errorMessage: 'No space & special characters allowed.' },
                        pattern: { value: '/^[a-zA-Z0-9 ,-_]+$/', errorMessage: 'No space & special characters allowed.' }
                      }}
                      value={this.state.sendUserEditDetail.display_name}
                      onChange={this.updateFormValue}
                    />
                  </Col>

                  <Form.Label column sm="4">Meeting IDs</Form.Label>
                  <Col sm="8">
                    {/* <Form.Control size="sm" name="meeting_ids" defaultValue={this.state.sendUserEditDetail.meeting_ids} onChange={this.updateMeetingId} /> */}
                    <AvField
                      name="meeting_ids"
                      // label="OneCloud User"
                      className="form-control"
                      type="text"
                      errorMessage="Please enter a valid Meeting Id."
                      validate={{
                        required: { value: true, errorMessage: 'No space & special characters allowed.' },
                        pattern: { value: '/^[a-zA-Z0-9,-_]+$/', errorMessage: 'No space & special characters allowed.' }
                      }}
                      value={this.state.sendUserEditDetail.meeting_ids}
                      onChange={this.updateMeetingId}
                    />
                  </Col>

                  <Form.Label column sm="4">Current Meeting IDs</Form.Label>
                  <Col sm="8">
                    {/* <Form.Control size="sm" name="current_meeting_id" defaultValue={this.state.sendUserEditDetail.current_meeting_id} onChange={this.updateFormValue} /> */}
                    <AvField
                      name="current_meeting_ids"
                      // label="OneCloud User"
                      className="form-control"
                      type="text"
                      errorMessage="Please enter a valid Current Meeting Id."
                      validate={{
                        required: { value: true, errorMessage: 'No space & special characters allowed.' },
                        pattern: { value: '/^[a-zA-Z0-9,-_]+$/', errorMessage: 'No space & special characters allowed.' }
                      }}
                      value={this.state.sendUserEditDetail.current_meeting_id}
                      onChange={this.updateFormValue}
                    />
                  </Col>
                </Form.Group>
                <Row>
                  <Col md={{ span: 2, offset: 10 }}>
                    <Button block type="submit">Save</Button>
                  </Col>
                </Row>
              </AvForm>
            </Form>
          </Modal.Body>
        </Modal>

        <Modal
          show={this.state.confirmChangeScopeModal}
          onHide={() => this.setState({ showAddUserModal: false, showDomainTable: false })}
          dialogClassName="modal-90w"
          aria-labelledby="confirmation To change Scope"
          size="md"
          centered
        >
          <Modal.Body>
            <Row>
              <Col md="12">
                <p class="text-center">Are you sure, You want to update the scope ?</p>
              </Col>
            </Row>
            <Row className="justify-content-md-center">
              <Col md={{ span: 2 }}>
                <Button block size="sm" onClick={() => this.updateScope(false)}>No</Button>
              </Col>
              <Col md={{ span: 2 }}>
                <Button block size="sm" onClick={() => this.updateScope(true)}>Yes</Button>
              </Col>
            </Row>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

export default Users;