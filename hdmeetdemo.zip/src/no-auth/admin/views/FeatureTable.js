import React, { Component, useState, useEffect } from 'react';
import {
  getAllfeatureApi,
  getAllScopesApi,
} from '../../../constant/index';
import {
  Badge,
  Button,
  Card,
  Navbar,
  Nav,
  Table,
  Container,
  Row,
  Col,
  Modal,
  Form,
} from "react-bootstrap";
import { toast } from 'react-toastify';
import { getAuthToken } from '../../../helpers/auth-header';
import LoaderImage from '../../../assets/images/loader.gif';
// import Loader from "../../loader"

class FeatureTable extends Component {
  constructor(props) {
    super(props)
    this.state = {
      // randonNumber: Math.floor(Math.random() * 10),
      features: [],
      scopes: [],
      addedScopes: null,
      showAddFeatureModal: false,
      showEditFeatureModal: false,
      // addWebParticipant: null,
      // addVideoParticipant: null,
      // addCurrentMeetingUrl: null,
      fields: [{ value: null, valueTwo: null, description: null, type:null }],
      featureType:["Number","String","Array","Boolean","Object"],
      // selectedFeatureType:null,
      addScope: '',
      addWebParticipant: 0,
      addVideoParticipant: 0,
      addCurrentMeetingUrl: 0,
      addNoSignupMeeting: false,
      addRecordingMeeting: false,
      addMeetingTranscript: false,
      addInternationDialinNumber: false,
      addUnlimitedRecording: false,
      addIsWebinar:false,
      addEndToEndEncryption: false,
      addHippaComplaint: false,
      addCloudStorage: false,
      addLiveStreaming: false,
      is_loader_visiable: false,
      editScope: null,
      editConfig_param: {},
      editWebParticipant: null,
      editVideoParticipant: null,
      editCurrentMeetingUrl: null,
      editNoSignupMeeting: false,
      editRecordingMeeting: false,
      editMeetingTranscript: false,
      editInternationDialinNumber: false,
      editUnlimitedRecording: false,
      editEndToEndEncryption: false,
      editHippaComplaint: false,
      editCloudStorage: false,
      editLiveStreaming: false,
      editRowId: null,
      editIsWebinar: false
    }
  }

  componentDidMount() {
    this.getAllFeatures()
  }

  getAllFeatures = async () => {
    let token = await getAuthToken();
    const myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    myHeaders.append('Authorization', 'Bearer ' + token.access);

    const requestOptions = {
      method: 'GET',
      headers: myHeaders
    };

    fetch(getAllScopesApi,requestOptions)
      .then(res => res.json())
      .then(
        (result) => {
          this.setState({
            scopes: result.Result
          })
          if (result.CodeStatus !== 200) {
            toast.dismiss();
            toast.error(`${result.Messages}`, {
              position: "top-right",
              autoClose: 5000,
              hideProgressBar: true,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
            });
          }
        },
        (error) => {
          console.log("error", error);
        }
      )

    fetch(getAllfeatureApi,requestOptions)
      .then(res => res.json())
      .then(
        (result) => {
          this.setState({
            features: result.Result
          })
          if (result.CodeStatus !== 200) {
            toast.dismiss();
            toast.error(`${result.Messages}`, {
              position: "top-right",
              autoClose: 5000,
              hideProgressBar: true,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
            });
          }
        },
        (error) => {
          console.log("error", error);
        }
      )
  }


  handleChange = (i, event) => {
    const values = [...this.state.fields];
    values[i].value = event.target.value;
    this.setState({
      fields: values
    });
  }
  handleChange2 = (i, event) => {
    const values = [...this.state.fields];
    values[i].valueTwo = event.target.value;
    this.setState({
      fields: values
    });
  }
  handleChange3 = (i, event) => {
    const values = [...this.state.fields];
    values[i].description = event.target.value;
    this.setState({
      fields: values
    });
  }

  handleChange4 = (i, event) => {
    const values = [...this.state.fields];
    values[i].type = event.target.value;
    this.setState({
      fields: values
    });
  }

  handleAdd = () => {
    const values = [...this.state.fields];
    values.push({ value: null, valueTwo: null, description: null });
    this.setState({
      fields: values
    });
  }

  handleEditAdd = () => {
    const values = { ...this.state.editConfig_param };
    var randonParameter = "p" + Math.floor(Math.random() * 100).toString()
    values[randonParameter] = {
      value: null,
      description: null,
      type: null
    }
    this.setState({
      editConfig_param: values
    });
  }

  handleRemove = (i) => {
    const values = [...this.state.fields];
    values.splice(i, 1);
    this.setState({
      fields: values
    });
  }

  handleFeatureEditRemove = (i) => {
    const values = this.state.editConfig_param;
    const allowed = [i];
    Object.keys(values)
    .filter(key => allowed.includes(key))
    .forEach(key => delete values[key]);
    this.setState({
      editConfig_param: values
    });
  }

  openEditModal = (feature) => {
    this.setState({
      showEditFeatureModal: true,
      editScope: feature.oc_scope,
      editConfig_param: feature.config_param,
      editWebParticipant: feature.web_participants,
      editVideoParticipant: feature.video_participants,
      editCurrentMeetingUrl: feature.custom_meeting_url,
      editNoSignupMeeting: feature.no_signup_meeting,
      editRecordingMeeting: feature.recording_meetings,
      editMeetingTranscript: feature.meeting_transcripts,
      editInternationDialinNumber: feature.international_dial_in_numbers,
      editUnlimitedRecording: feature.recordings,
      editEndToEndEncryption: feature.end_to_end_encryption,
      editHippaComplaint: feature.hipaa_complaint,
      editCloudStorage: feature.cloud_storage,
      editLiveStreaming: feature.live_streaming,
      editRowId: feature.id,
      editIsWebinar: feature.is_webinar
    })
  }

  updateFormValue = (event) => {
      this.setState({
        [event.target.name]: parseInt(event.target.value)
      });
  }

  addSelectedScope = (event) => {
    this.setState({
      addedScopes: event.target.value
    })
  }

  handleChecked = (event) => {
    this.setState({
      [event.target.name]: event.target.checked
    });
  }

  sendSelectedOcScope = (event) => {
    this.setState({
      addedScopes: event.target.value
    })
  }

  getOcScopeName = (featureScope) => {
    var result = this.state.scopes.find(elem => elem.id == featureScope)
    return result && result.name
  }

  submitAddedFeature = async () => {
    let obj = {};
    this.state.fields.map((elem, i) => {
      if(elem.type === "Array"){
        obj = {
          ...obj,
          [elem.value]: {
            value: elem.valueTwo.split(", "),
            description: elem.description,
            type: elem.type,
          }
        }
      }else if(elem.type === "Number"){
        obj = {
          ...obj,
          [elem.value]: {
            value: parseInt(elem.valueTwo),
            description: elem.description,
            type: elem.type,
          }
        }
      }else if(elem.type === "Boolean"){
        obj = {
          ...obj,
          [elem.value]: {
            value: Boolean(elem.valueTwo),
            description: elem.description,
            type: elem.type,
          }
        }
      }else if(elem.type === "String"){
        obj = {
          ...obj,
          [elem.value]: {
            value: elem.valueTwo,
            description: elem.description,
            type: elem.type,
          }
        }
      }else if(elem.type === "Object"){
        obj = {
          ...obj,
          [elem.value]: {
            value: JSON.parse(elem.valueTwo),
            description: elem.description,
            type: elem.type,
          }
        }
      }
      return obj
    });


    let fields = {
      oc_scope: this.state.addedScopes,
      web_participants: this.state.addWebParticipant,
      video_participants: this.state.addVideoParticipant,
      custom_meeting_url: this.state.addCurrentMeetingUrl,
      international_dial_in_numbers: this.state.addInternationDialinNumber,
      hipaa_complaint: this.state.addHippaComplaint,
      recordings: this.state.addUnlimitedRecording,
      is_webinar:this.state.addIsWebinar,
      config_param: obj
    }
    let token = await getAuthToken();
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let result = await fetch(getAllfeatureApi, {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify(fields),
      })
      const data = await result.json()
      if (data.CodeStatus == 201) {
        toast.dismiss();
        toast.success(`${data.Messages}`, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
        this.setState({
          showAddFeatureModal: false
        })
        this.getAllFeatures()
      } else {
        toast.dismiss();
        toast.error(`${data.Messages}`, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      }
    } catch (error) {
      console.log("ERROR", error)
    }
  }

  submitUpdatedFeature = async (userId) => {
    var nodeList = document.querySelectorAll(".allparameter")
    var finalParam = {};
    for (var i = 0; i < nodeList.length; i++) {
      let config = {}
      for (var j = 0; j < nodeList[i].childNodes.length - 1; j++) {
        if (nodeList[i].childNodes[j].className .split(" ").includes('paramKey')) {
          config["key"] = nodeList[i].childNodes[j].childNodes[0].value;
        }
        if (nodeList[i].childNodes[j].className.split(" ").includes('paramValue')) {
          config["value"] = nodeList[i].childNodes[j].childNodes[0].value;
        }
        if (nodeList[i].childNodes[j].className.split(" ").includes('paramDescription')) {
          config["description"] = nodeList[i].childNodes[j].childNodes[0].value;
        }
        if (nodeList[i].childNodes[j].className.split(" ").includes('paramType')) {
          config["type"] = nodeList[i].childNodes[j].childNodes[0].value;
        }
      }
      finalParam[config["key"]] = { "value": config["value"], "description": config["description"], "type": config["type"]}
    }

    // Object.entries(finalParam).map((key,value) =>{
    //   console.log("key::::>>", key, value)
    // })
    let fields = {
      oc_scope: this.state.editScope,
      config_param: finalParam,
      web_participants: this.state.editWebParticipant,
      video_participants: this.state.editVideoParticipant,
      custom_meeting_url: this.state.editCurrentMeetingUrl,
      international_dial_in_numbers: this.state.editInternationDialinNumber,
      hipaa_complaint: this.state.editHippaComplaint,
      recordings: this.state.editUnlimitedRecording,
      is_webinar: this.state.editIsWebinar
    }
    let token = await getAuthToken();
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let result = await fetch(getAllfeatureApi + `/${userId}`, {
        method: 'PUT',
        headers: myHeaders,
        body: JSON.stringify(fields),
      })
      const data = await result.json()
      if (data.CodeStatus == 200) {
        toast.dismiss();
        toast.success(`${data.Messages}`, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
        this.setState({ showEditFeatureModal: false })
        this.getAllFeatures()
      } else {
        toast.dismiss();
        toast.error(`${data.Messages}`, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      }
    } catch (error) {
      console.log("ERROR", error)
    }
  }

  render() {
    return (
      <div>
        <Container fluid>
          <Row>
            <Col md="12">
              <Card className="strpied-tabled-with-hover">
                <Card.Header className="userHeader">
                  <Card.Title as="h4" className="UserHeaderTitle">HDMeet Features </Card.Title>
                  <button className="btn btn-primary inportUserBtn" onClick={() => this.setState({ showAddFeatureModal: true })}>Add Feature</button>
                </Card.Header>
                <Card.Body className="table-full-width table-responsive px-0 py-0">
                  <Table className="table-hover table-striped tableAlignment">
                    <thead>
                      <tr>
                        <th className="border-0">HDMeet Scope</th>
                        <th className="border-0">Web Participants</th>
                        <th className="border-0">Video Participants</th>
                        <th className="border-0">Custom meeting url</th>
                      </tr>
                    </thead>
                    <tbody>
                      {this.state.features.map((feature, i) => (
                        <tr key={i}>
                          {/* <td onClick={() =>this.openEditModal(feature)}>{feature.oc_scope}</td> */}
                          <td onClick={() => this.openEditModal(feature)}>{this.getOcScopeName(feature.oc_scope)}</td>
                          <td onClick={() => this.openEditModal(feature)}>{feature.web_participants}</td>
                          <td onClick={() => this.openEditModal(feature)}>{feature.video_participants}</td>
                          <td onClick={() => this.openEditModal(feature)}>{feature.custom_meeting_url}</td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>

        {
          this.state.is_loader_visiable ?
            <img className="loaderImage adminLoader" src={LoaderImage} alt="loaderImage"></img>
            : null
        }

        <Modal
          show={this.state.showAddFeatureModal}
          onHide={() => this.setState({ showAddFeatureModal: false })}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
          size="lg"
        >
          <Modal.Header closeButton>
            <Modal.Title id="example-custom-modal-styling-title">
              Add Feature
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form>
              <Form.Group as={Row} controlId="addOcUser">
                <Form.Label column sm="4">HDMeet Scope</Form.Label>
                <Col sm="8">
                  <Form.Control
                    as="select"
                    custom
                    onChange={this.addSelectedScope}
                    size="sm"
                  >
                    <option>Select Scope</option>
                    {this.state.scopes.map((scope, i) => (
                      <option value={scope.id} key={i}>{scope.name}</option>
                    ))}
                  </Form.Control>
                </Col>
                <Form.Label column sm="4">Web participants</Form.Label>
                <Col sm="8">
                  <Form.Control size="sm" name="addWebParticipant" onChange={this.updateFormValue} />
                </Col>

                <Form.Label column sm="4">Video participants</Form.Label>
                <Col sm="8">
                  <Form.Control size="sm" name="addVideoParticipant" onChange={this.updateFormValue} />
                </Col>

                <Form.Label column sm="4">Custom meeting url</Form.Label>
                <Col sm="8">
                  <Form.Control size="sm" name="addCurrentMeetingUrl" onChange={this.updateFormValue} />
                </Col>
                <Col md="12">
                  <div style={{ border: "1px solid #ced4da", margin: "10px auto", borderBottom: "0px" }}></div>
                </Col>

                <Col sm="4">
                  <Form.Check aria-label="Recording" label="Recording" name="addUnlimitedRecording" onChange={this.handleChecked} />
                </Col>
                <Col sm="4">
                  <Form.Check aria-label="International dial in numbers" label="International dial in numbers" name="addInternationDialinNumber" onChange={this.handleChecked} />
                </Col>
                <Col sm="4">
                  <Form.Check aria-label="Hipaa complaint" label="Hipaa complaint" name="addHippaComplaint" onChange={this.handleChecked} />
                </Col>
                <Col sm="4">
                  <Form.Check aria-label="is webinar scope ?" label="is webinar scope ?" name="addIsWebinar" onChange={this.handleChecked} />
                </Col>
              </Form.Group>

              <Form.Group>
                <Row className="">
                  <Col sm="3">Config Parameter</Col>
                  <Col sm="2">Type</Col>
                  <Col sm="3">Value</Col>
                  <Col sm="3">Description</Col>
                  <Col sm="1"></Col>
                </Row>
                {this.state.fields.map((field, idx) => {
                  return (
                    <Row className="text-center mt-2" key={`${field}-${idx}`}>
                      <Col sm="3" className="text-center">
                        <Form.Control size="sm" name="toolbarButtons" placeholder="Enter Parameter" onChange={e => this.handleChange(idx, e)} />
                      </Col>
                      <Col sm="2" className="text-center paramDescription">
                        <Form.Control
                          as="select"
                          custom
                          onChange={e => this.handleChange4(idx, e)}
                          size="sm"
                        >
                          <option>Select</option>
                          {this.state.featureType.map((featureType, i) => (
                            <option value={featureType} key={i}>{featureType}</option>
                          ))}
                        </Form.Control>
                      </Col>
                      <Col sm="3" className="text-center">
                        <Form.Control size="sm" name="" placeholder="Enter Value" onChange={e => this.handleChange2(idx, e)} />
                      </Col>
                      <Col sm="3" className="text-center">
                        <Form.Control size="sm" name="" placeholder="Description" onChange={e => this.handleChange3(idx, e)} />
                      </Col>
                      <Col sm="1" className="text-center">
                        <Button size="sm" block type="button" onClick={() => this.handleRemove(idx)}>X</Button>
                      </Col>
                    </Row>
                  );
                })}
                <Row className="text-center mt-2">
                  <Col sm="3">
                    <Button block onClick={() => this.handleAdd()}>Add Parameter</Button>
                  </Col>
                </Row>
              </Form.Group>
            </Form>
            <Row>
              <Col md={{ span: 2, offset: 10 }}>
                <Button block onClick={this.submitAddedFeature}>Add</Button>
              </Col>
            </Row>
          </Modal.Body>
        </Modal>


        <Modal
          show={this.state.showEditFeatureModal}
          onHide={() => this.setState({ showEditFeatureModal: false })}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
          size="lg"
        >
          <Modal.Header closeButton>
            <Modal.Title id="example-custom-modal-styling-title">
              Edit Feature
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>

            <Form>
              <Form.Group as={Row} controlId="addOcUser">
                <Form.Label column sm="4">HDMeet Scope</Form.Label>
                <Col sm="8">
                  <Form.Control
                    as="select"
                    custom
                    onChange={this.sendSelectedOcScope}
                    size="sm"
                  >
                    {this.state.scopes.map((scope, i) => (
                      <option value={scope.id} key={i} selected={this.state.editScope == scope.id}>{scope.name}</option>
                    ))}
                  </Form.Control>
                </Col>
                <Form.Label column sm="4">Web participants</Form.Label>
                <Col sm="8">
                  <Form.Control size="sm" name="editWebParticipant" defaultValue={this.state.editWebParticipant} onChange={this.updateFormValue} />
                </Col>

                <Form.Label column sm="4">Video participants</Form.Label>
                <Col sm="8">
                  <Form.Control size="sm" name="editVideoParticipant" defaultValue={this.state.editVideoParticipant} onChange={this.updateFormValue} />
                </Col>

                <Form.Label column sm="4">Custom meeting url</Form.Label>
                <Col sm="8">
                  <Form.Control size="sm" name="editCurrentMeetingUrl" defaultValue={this.state.editCurrentMeetingUrl} onChange={this.updateFormValue} />
                </Col>
                <Col md="12">
                  <div style={{ border: "1px solid #ced4da", margin: "10px auto", borderBottom: "0px" }}></div>
                </Col>

                <Col sm="4">
                  <Form.Check aria-label="Recording" name="editUnlimitedRecording" defaultChecked={this.state.editUnlimitedRecording} label="Recording" onChange={this.handleChecked} />
                </Col>
                <Col sm="4">
                  <Form.Check aria-label="International dial in numbers" name="editInternationDialinNumber" defaultChecked={this.state.editInternationDialinNumber} label="International dial in numbers" onChange={this.handleChecked} />
                </Col>
                <Col sm="4">
                  <Form.Check aria-label="Hipaa complaint" name="editHippaComplaint" defaultChecked={this.state.editHippaComplaint} label="Hipaa complaint" onChange={this.handleChecked} />
                </Col>
                <Col sm="4">
                  <Form.Check aria-label="Webinar" name="editIsWebinar" defaultChecked={this.state.editIsWebinar} label="Is webinar Scope?" onChange={this.handleChecked} />
                </Col>
              </Form.Group>
              <Form.Group>
                <Row className="">
                  <Col sm="3">Config Parameter</Col>
                  <Col sm="2">Select Type</Col>
                  <Col sm="3">Value</Col>
                  <Col sm="3">Description</Col>
                  <Col sm="1"></Col>
                </Row>
                {this.state.editConfig_param && Object.entries(this.state.editConfig_param).map(([key, value],idx) => {
                  return (
                    <Row className="text-center mt-2 allparameter" key={`${key}-${idx}`}>
                      <Col sm="3" className="text-center paramKey">
                        <Form.Control size="sm" id="parameterKey" name="toolbarButtons" placeholder="Enter Parameter" defaultValue={key} />
                      </Col>
                      <Col sm="2" className="text-center paramType">
                        <Form.Control
                          as="select"
                          custom
                          onChange={this.addSelectedFeatureType}
                          size="sm"
                        >
                          <option>Select</option>
                          {this.state.featureType.map((featureType, i) => (
                            <option value={featureType} selected={value.type == featureType} key={i}>{featureType}</option>
                          ))}
                        </Form.Control>
                      </Col>
                      <Col sm="3" className="text-center paramValue">
                        <Form.Control size="sm" name="" placeholder="Enter Value" defaultValue={value.type === "Object" ? value.value : value.value}/>
                      </Col>
                      <Col sm="3" className="text-center paramDescription">
                        <Form.Control size="sm" name="" placeholder="Description" defaultValue={value.description} />
                      </Col>
                      <Col sm="1" className="text-center">
                        <Button size="sm" block type="button" onClick={() => this.handleFeatureEditRemove(key)}>X</Button>
                      </Col>
                    </Row>
                  );
                })}
                <Row className="text-center mt-2">
                  <Col sm="3">
                    <Button block onClick={() => this.handleEditAdd()}>Add Parameter</Button>
                  </Col>
                </Row>
              </Form.Group>
            </Form>
            <Row>
              <Col md={{ span: 2, offset: 10 }}>
                <Button block onClick={() => this.submitUpdatedFeature(this.state.editRowId)}>Update</Button>
              </Col>
            </Row>
          </Modal.Body>
        </Modal>
      </div>
    )
  }
}

export default FeatureTable;
