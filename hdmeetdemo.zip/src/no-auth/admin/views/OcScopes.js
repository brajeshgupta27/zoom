import React, { Component, useState, useEffect } from 'react';
// import axios from 'axios';
import {
  getAllScopesApi,
} from '../../../constant/index';
// react-bootstrap components
import {
  Badge,
  Button,
  Card,
  Navbar,
  Nav,
  Table,
  Container,
  Row,
  Col,
  Modal,
  Form,
} from "react-bootstrap";
import { toast } from 'react-toastify';
import { getAuthToken } from '../../../helpers/auth-header';
import { AvForm, AvField } from 'availity-reactstrap-validation';

class OcScopes extends Component {
  constructor(props) {
    super(props)
    this.state = {
      scopes: [],
      showAddScopeModal: false,
      showEditScopeModal: false,
      editScopeValue: '',
      editScopeId: '',
      newAddedScope: "",
      editedScope: '',
    }
    this.updateNewScopeName = this.updateNewScopeName.bind(this);
  }

  componentDidMount() {
    this.getAllScopes()
  }

  // async componentDidMount() {
    // await this.getAllScopes
    // let token = await getAuthToken();
    // const myHeaders = new Headers();
    // myHeaders.append('Content-Type', 'application/json');
    // myHeaders.append('Authorization', 'Bearer ' + token.access);

    // const requestOptions = {
    //   method: 'GET',
    //   headers: myHeaders
    // };

    // fetch(getAllScopesApi, requestOptions)
    //   .then(res => res.json())
    //   .then(
    //     (result) => {
    //       this.setState({
    //         scopes: result.Result
    //       })
    //       if (result.CodeStatus !== 200) {
    //         toast.dismiss();
    //         toast.error(`${result.Messages}`, {
    //           position: "top-right",
    //           autoClose: 5000,
    //           hideProgressBar: true,
    //           closeOnClick: true,
    //           pauseOnHover: true,
    //           draggable: true,
    //           progress: undefined,
    //         });
    //       }
    //     },
    //     (error) => {
    //       console.log("error", error);
    //     }
    //   )
  // }

  getAllScopes = async () => {
    console.log("called")
    let token = await getAuthToken();
    const myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');
    myHeaders.append('Authorization', 'Bearer ' + token.access);

    const requestOptions = {
      method: 'GET',
      headers: myHeaders
    };

    fetch(getAllScopesApi, requestOptions)
      .then(res => res.json())
      .then(
        (result) => {
          this.setState({
            scopes: result.Result
          })
          if (result.CodeStatus !== 200) {
            toast.dismiss();
            toast.error(`${result.Messages}`, {
              position: "top-right",
              autoClose: 5000,
              hideProgressBar: true,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
            });
          }
        },
        (error) => {
          console.log("error", error);
        }
      )
  }

  addedNewScope = (event) => {
    this.setState({
      newAddedScope: event.target.value
    })
  }

  updateNewScopeName = (event) => {
    this.setState({
      editScopeValue: event.target.value
    })
  }

  openEditModal = (scope) => {
    this.setState({
      editScopeValue: scope.name,
      editScopeId: scope.id,
      showEditScopeModal: true,
    })
  }

  submitUpdatedScope = async () => {
    let token = await getAuthToken();
    try {
      const myHeaders = new Headers();
      myHeaders.append('Content-Type', 'application/json');
      myHeaders.append('Authorization', 'Bearer ' + token.access);
      let result = await fetch(getAllScopesApi + "/" + this.state.editScopeId, {
        method: 'PUT',
        headers: myHeaders,
        body: JSON.stringify({ name: this.state.editScopeValue }),
      })
      const data = await result.json()
      
      if (data.CodeStatus == 200) {
        toast.dismiss();
        toast.success(`${data.Messages}`, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
        this.setState({
          showEditScopeModal: false
        })
        this.getAllScopes()
      } else {
        toast.dismiss();
        toast.error(`${data.Messages}`, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: true,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
        });
      }
    } catch (error) {
      console.log("ERROR", error)
    }
  }

  submitAddedScope = async () => {
    if (this.state.newAddedScope.length > 0) {

      let token = await getAuthToken();
      try {
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        myHeaders.append('Authorization', 'Bearer ' + token.access);
        let result = await fetch(getAllScopesApi, {
          method: 'POST',
          headers: myHeaders,
          body: JSON.stringify({ name: this.state.newAddedScope }),
        })
        const data = await result.json()
        this.setState({
          scopes: [...this.state.scopes, data.Result],
          showAddScopeModal: false
        })
        if (data.CodeStatus == 201) {
          toast.dismiss();
          toast.success(`${data.Messages}`, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
        } else {
          toast.dismiss();
          toast.error(`${data.Messages}`, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: true,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
          });
        }
      } catch (error) {
        console.log("ERROR", error)
      }
    } else {
      toast.dismiss();
      toast.error("Cannot be left blank", {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
    }
  }
  render() {
    return (
      <div>
        <Container fluid>
          <Row>
            <Col md="12">
              <Card className="strpied-tabled-with-hover">
                <Card.Header className="userHeader">
                  <Card.Title as="h4" className="UserHeaderTitle">HDMeet Scopes</Card.Title>
                  <button className="btn btn-primary inportUserBtn" onClick={() => { this.setState({ showAddScopeModal: true }) }}>Add Scope</button>
                </Card.Header>
                <Card.Body className="table-full-width table-responsive px-0 py-0 overflowTable">
                  <Table className="table-hover table-striped tableAlignment">
                    <thead>
                      <tr>
                        {/* <th className="border-0">Oc Scope Id</th> */}
                        <th className="border-0">HDMeet Scope Name</th>
                      </tr>
                    </thead>
                    <tbody>
                      {this.state.scopes.map((scope, i) => (
                        <tr key={i}>
                          {/* <td onClick={() =>this.openEditModal(scope)}>{scope.id}</td> */}
                          <td onClick={() => this.openEditModal(scope)}>{scope.name}</td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </Card.Body>
              </Card>
            </Col>

          </Row>
        </Container>

        <Modal
          show={this.state.showAddScopeModal}
          onHide={() => this.setState({ showAddScopeModal: false })}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
          size="lg"
        >
          <Modal.Header closeButton>
            <Modal.Title id="example-custom-modal-styling-title">
              Add HDMeet Scope
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form>
              <AvForm id="addScopeForm" className="form" action="" method="post" onValidSubmit={this.submitAddedScope}>
                <Form.Group as={Row} controlId="addOcUser">
                  <Form.Label column sm="4">Name</Form.Label>
                  <Col sm="8">
                    <AvField
                      name="one_cloud_user_name"
                      // label="OneCloud User"
                      className="form-control"
                      type="text"
                      errorMessage="Please enter a valid User Name."
                      validate={{
                        required: { value: true, errorMessage: 'No space & special characters allowed.' },
                        pattern: { value: '/^[a-zA-Z0-9,-_]+$/', errorMessage: 'No space & special characters allowed.' }
                      }}
                      value=""
                      onChange={this.addedNewScope}
                    />
                  </Col>
                </Form.Group>
                <Row>
                  <Col md={{ span: 2, offset: 10 }}>
                    <Button block type="submit">Add</Button>
                  </Col>
                </Row>
              </AvForm>
            </Form>
          </Modal.Body>
        </Modal>

        <Modal
          show={this.state.showEditScopeModal}
          onHide={() => this.setState({ showEditScopeModal: false })}
          dialogClassName="modal-90w"
          aria-labelledby="example-custom-modal-styling-title"
          size="lg"
        >
          <Modal.Header closeButton>
            <Modal.Title id="example-custom-modal-styling-title">
              Edit HDMeet Scope
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form>
              <AvForm id="editScopeForm" className="form" action="" method="post" onValidSubmit={this.submitUpdatedScope}>
                <Form.Group as={Row} controlId="editOcUser">
                  <Form.Label column sm="4">Name</Form.Label>
                  <Col sm="8">
                    {/* <Form.Control size="sm" onChange={this.updateNewScopeName} defaultValue={this.state.editScopeValue} /> */}
                    <AvField
                      name="one_cloud_user_name"
                      // label="OneCloud User"
                      className="form-control"
                      type="text"
                      errorMessage="Please enter a valid User Name."
                      validate={{
                        required: { value: true, errorMessage: 'No space & special characters allowed.' },
                        pattern: { value: '/^[a-zA-Z0-9,-_]+$/', errorMessage: 'No space & special characters allowed.' }
                      }}
                      value={this.state.editScopeValue}
                      onChange={this.updateNewScopeName}
                    />
                  </Col>
                </Form.Group>
                <Row>
                  <Col md={{ span: 2, offset: 10 }}>
                    <Button block type="submit">Update</Button>
                  </Col>
                </Row>
              </AvForm>
            </Form>
          </Modal.Body>
        </Modal>
      </div>
    )
  }
}

export default OcScopes;
