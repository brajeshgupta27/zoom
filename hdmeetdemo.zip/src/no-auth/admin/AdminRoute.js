import HdmeetDashboard from "./views/HdmeetDashboard";
import Users from "./views/Users";
import FeatureTable from "./views/FeatureTable";
import OcScopes from "./views/OcScopes";

const AdminRoutes = [
    // {
    //     path: "/dashboard",
    //     name: "Dashboard",
    //     icon: "nc-icon nc-notes",
    //     component: HdmeetDashboard,
    //     layout: "/hdmeetadmin",
    //   },
      {
        path: "/users",
        name: "users",
        icon: "nc-icon nc-notes",
        component: Users,
        layout: "/hdmeetadmin",
      },
      {
        path: "/hdmeetFeature",
        name: "HDMeet Features",
        icon: "nc-icon nc-notes",
        component: FeatureTable,
        layout: "/hdmeetadmin",
      },
      {
        path: "/hdmeetScopes",
        name: "HDMeet Scopes",
        icon: "nc-icon nc-notes",
        component: OcScopes,
        layout: "/hdmeetadmin",
      }
];

export default AdminRoutes;
