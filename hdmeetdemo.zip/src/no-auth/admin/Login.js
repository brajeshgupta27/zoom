import React, { Component } from 'react';
import HdmeetLogo from '../../assets/images/hdmeet_admin_logo.png';
import { AvForm, AvField } from 'availity-reactstrap-validation';
import "./adminStyle.css";
import { hdmeetAdminLoginApi } from '../../constant/index';
import {
    Container,
    Row,
    Col,
    Image,
} from "react-bootstrap";
import { getAuthToken } from '../../helpers/auth-header';

class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            adminUserEmail: '',
            adminUserPassword: '',
            showError:false,
            errorMsg:'',
            isAdminLogin: localStorage.getItem("isAdminLogin") ? localStorage.getItem("isAdminLogin"):false,
        }
        this.adminLoginHandler = this.adminLoginHandler.bind(this);
        this.getHdmeetLogin = this.getHdmeetLogin.bind(this);
    }

    adminLoginHandler = async (e) => {
        let token = await getAuthToken();
        this.setState({
            showError: false,
        })
        const hdmeetAdminLogin = await this.getHdmeetLogin(token, this.state.adminUserEmail, this.state.adminUserPassword)
        if(hdmeetAdminLogin.CodeStatus == "200"){
            localStorage.setItem("isAdminLogin",true)
            this.props.history.push('/hdmeetadmin/users');
        }else{
            this.setState({
                showError: true,
                errorMsg:hdmeetAdminLogin.Messages
            })
        }
    }
    
    getHdmeetLogin = async (token, userName, password) => {
        try {
            const myHeaders = new Headers();
            myHeaders.append('Content-Type', 'application/json');
            myHeaders.append('Authorization', 'Bearer ' + token.access);
            let result = await fetch(hdmeetAdminLoginApi, {
                method: 'POST',
                headers: myHeaders,
                body: JSON.stringify({ username: userName, password: password }),
            })
            const data = await result.json()
            return data
        } catch (error) {
            console.log("ERROR",error)
        }
    }

    updateFormValue = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        });
    }
    render() {
        if(!this.state.isAdminLogin){
        return (
            <Container fluid className="loginContainerBg" >
                <Row className="form-box">
                    <Col xs={12} md={{ span: 4, offset: 4 }} className="body-form loginBox">
                        <Image className="loginLogoImage" src={HdmeetLogo}></Image>
                        <h4 className="adminLoginHeading">HDMeet</h4>
                        <p className="adminLoginTxt">Admin Login</p>
                        {this.state.showError ? <p className="adminLoginTxt" style={{color:'red'}}>{this.state.errorMsg}</p> : null}
                        <AvForm id="login-form" className="form" action="" method="post" onValidSubmit={this.adminLoginHandler}>
                            <div className="input-group fullWidth">
                                <AvField
                                    name="adminUserEmail"
                                    className="form-control loginInput"
                                    placeholder="User Name"
                                    type="text"
                                    errorMessage="Please enter a valid email address."
                                    validate={{
                                        required: { value: true },
                                        // email: { value: true }
                                    }}
                                    value={this.state.adminUserEmail.trim()}
                                    onChange={this.updateFormValue}
                                />
                            </div>
                            <div className="input-group fullWidth">
                                <AvField
                                    name="adminUserPassword"
                                    className="form-control loginInput"
                                    placeholder="Password"
                                    type="password"
                                    autoComplete="true"
                                    errorMessage="Please enter a valid password."
                                    validate={{
                                        required: { value: true }
                                    }}
                                    value={this.state.adminUserPassword.trim()}
                                    onChange={this.updateFormValue}
                                />
                            </div>
                            <button type="submit" className="btn btn-block loginBtnAdmin" name="submit" value="LOGIN">LOGIN</button>
                        </AvForm>
                    </Col>
                </Row>
            </Container>
        )
        }
    else{
        
            <div>
              {document.location.href = '/hdmeetadmin/users'}
            </div>
          
        
    }    

    }
}

export default Login