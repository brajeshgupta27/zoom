import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route, Link
} from "react-router-dom";
import ReactGA from 'react-ga';
ReactGA.initialize('G-RFX1P2LBGC');
import Conf from "./components/app/conf"
import Startconference from "./components/startConference/startconference";
import LandingPage from "./no-auth/landingPage";
import PublicRoute from "./components/Router/PublicRoute";
import PrivateRoute from "./components/Router/PrivateRoute";
import NotFound from "./no-auth/NotFound";
import ScheduleMeeting from "./no-auth/ScheduleMeeting";
import DialInInfo from "../src/no-auth/dialInInfo";
import LoginPage from "../src/no-auth/loginPage";
import ForgotPassword from "../src/no-auth/forgotPassword";
import Dashboard from "../src/no-auth/dashboard";
import SSO from "../src/no-auth/SSO";
import Login from "../src/no-auth/admin/Login";
import AdminLayout from "./no-auth/admin/layout/adminLayout";
import MeetingReg from "./no-auth/meetingRegComponent/meetingReg"
import MeetingRegConform from "./no-auth/meetingRegComponent/meetingRegConform"
import WebinarSchedule from "./no-auth/webinarSchedule/WebinarSchedule"
import Webinar from "./no-auth/Webinar";

import StartWebinar from "./components/startConference/startWebinar";
// import { Link, Route, BrowserRouter as Router, Switch } from 'react-router-dom'

export default function App() {
  React.useEffect(()=>{
  })
  return (
    <div>
    <Router>
      <Switch>
        <PublicRoute exact path="/:meeting_id?" component={LandingPage} />
        <PublicRoute path="/dial/dialInInfo/:meeting_id?" component={DialInInfo} />
        <PublicRoute path="/app/:meeting_id?/:host_name?/:start?/:end?/:host_type?/" component={LandingPage} />
        <PublicRoute path="/login/sso" component={SSO} />
        <PublicRoute path="/schedule/sso" component={SSO} />
        <PublicRoute path="/user/dashboard/sso" component={SSO} />
        <PublicRoute path="/startconference/:cname/:s_audio/:s_video/:token" component={Startconference} />
        {/* <PublicRoute exact path="/webinar" component={Webinar} /> */}
        <PublicRoute path="/startwebinar/:cname/:s_audio/:s_video/:token" component={StartWebinar} />
        <PublicRoute exact path="/schedule/meeting" component={ScheduleMeeting} />
        <PublicRoute exact path="/user/login" component={LoginPage} />
        <PublicRoute exact path="/user/forgotpassword" component={ForgotPassword} />
        <PrivateRoute exact path="/user/dashboard/:meeting_id?" component={Dashboard} />
        <PublicRoute exact path="/hdmeetadmin/login" component={Login} />
        <PublicRoute exact path="/register/:regLink" component={MeetingReg} />
        <PublicRoute exact path="/webinar/regsuccess" component={MeetingRegConform} />
        <PublicRoute exact path="/hdmeetadmin/webinar-schedule" component={WebinarSchedule} />
        <PublicRoute path="/webinar/:meeting_id?" component={Webinar} />
        <Route path="/hdmeetadmin" render={(props) => <AdminLayout {...props} />} />
        <Route component={NotFound} />
      </Switch>
    </Router>
    </div>
  );
}