export const ONE_CLOUD = {
    format: 'json',
    grant_type: 'password',
    client_id: 'hdmeet-05152021',
    client_secret: '8124e1e1d3378a85a579e011b25756fb',
}

export const ONECLOUD_APP_ID = "onecloudmeet_A5xw3dE7WopPDn&d"
export const ONECLOUD_APP_SECRET = "#8C5DTDiq%VC2Q4LaxgZ4DeJAndh8AhojXdjusfH"
export const GuestMaxUserLimit = 50
export const OneCloudMaxUserLimit = 100
export const OneCloudGuestUserID = '1'
export const GuestScopeId = 1
export const WebinarParticipantId = 5
// export const telware_meet = "hdmeet.net"
export const telware_meet = "meet-east1.myonecloud.com"

export const telware_webinar_meet = "meet-east1.myonecloud.com/webinar"
export const userName = "hdmeet"
export const password = "@#$asd123"
export const ocSuperUser = "hdmeetportal@TelWareAdmin"
export const ocSuperPassword = 'w3@S8x@HJizr@FmnpuMdJ%2UbXbTp7'
export const timeDiffRange = "15"
export const versionTag = 'v1.1.0'

// Local URL
// export const Baseurl = process.env.REACT_APP_BASE_URL
// export const Socketurl = process.env.REACT_APP_SOCKET_URL
// export const Baseurl_app = process.env.REACT_APP_BASE_URL_APP
// export const Baseurl_self = process.env.REACT_APP_BASE_URL_SELF
// export const Baseurl_invite = 'https://join.hdmeet.com/?link='+Baseurl_app
// export const MeetingUrl = 'http://172.16.11.180:3000/webinar'
// export const attendeeMeetingUrl = "http://172.16.11.180:3000/webinar"

// Development URL
// export const Baseurl = 'https://dev.hdmeet.com'
// export const Socketurl = 'wss://dev.hdmeet.com'
// export const Baseurl_app = 'https://dev.hdmeet.com'
// export const Baseurl_self = 'https://dev.hdmeet.com'
// export const Baseurl_invite = 'https://join.hdmeet.com/?link='+Baseurl_app
// export const MeetingUrl = Baseurl + '/webinar'
// export const attendeeMeetingUrl = Baseurl + '/webinar'


// Production URL
export const Baseurl = 'https://ocservices.telware.net'
export const Socketurl = 'wss://ocservices.telware.net'
export const Baseurl_app = 'https://hdmeet.com'
export const Baseurl_self = 'https://hdmeet.com'
export const Baseurl_invite = 'https://join.hdmeet.com/?link='+Baseurl_self
export const MeetingUrl = Baseurl + '/webinar'
export const attendeeMeetingUrl = Baseurl + '/webinar'


export const nsapi_url = 'https://myonecloud.com/ns-api/oauth2/token'
export const gettoken = Baseurl+'/hdmeet/api/v1/get_token'
export const onlytoken = Baseurl+'/hdmeet/api/v1/token'
export const schedule = Baseurl+'/hdmeet/api/v1/schedule'
export const config = Baseurl+'/hdmeet/api/v1/config'
export const updateCurrentMeetingApi = Baseurl+'/hdmeet/api/v1/update_current_meeting_id'
export const isModeratorApi = Baseurl+'/hdmeet/api/v1/auth_moderator/'
export const updatecname = Baseurl+'/hdmeet/api/v1/update_conference'
export const recording = Baseurl+'/hdmeet/api/v1/recording/'
export const getOrCreateOcUser = Baseurl+'/hdmeet/api/v1/user/getorcreate'
export const getRecentLoggedInUser = Baseurl+'/hdmeet/api/v1/get_recent_login/'
export const guestApp = Baseurl_app + '/' 
export const guestWebinarApp = Baseurl_app + '/webinar/'
export const userApp = Baseurl_app + '/home/'
export const forgetPassword = Baseurl+'/hdmeet/api/v1/forget_password' 
export const dialInConfCodeUrl = 'https://api-mapper.telware.net/ConferenceMapper2/conferencemapper.php?conference='
export const dialInNumbersUrl = 'https://api-mapper.telware.net/jitsidialin/dialin.json'
export const nsApiUrl = "https://myonecloud.com/ns-api"
export const resetOneCloudPasswordUrl = "https://myonecloud.com/portal/resets/forgotpassword"
export const supportUrl = "https://www.telware.com/Support"
export const backendMeetingApi = Baseurl+'/hdmeet/api/v1/meeting'
export const getFeatureFromMeetingIdApi = Baseurl+'/hdmeet/api/v1/get_feature_from_meeting_id'
export const getRecordingUrl = Baseurl+'/hdmeet/api/v1/get_recordings'
export const serveFile = Baseurl+'/hdmeet/api/v1/serve_file'
export const userToken = Baseurl+'/hdmeet/api/v1/user_token'
export const checkMeetingExistApi = Baseurl+'/hdmeet/api/v1/check_meeting_exists'
export const endMeetingRedirectUrl = 'https://www.telware.com/small-business-solutions/solutions/unified-communications/hdmeet-video-conferencing'
export const appleStoreUrl = 'https://apps.apple.com/app/id1536805343'
export const googleStoreUrl = 'https://play.google.com/store/apps/details?id=com.telware.hdmeet&hl=en_US'
export const termsOfService = 'https://www.telware.com/terms-of-service'
export const privacyPolicy = 'https://www.telware.com/learn/hdmeet-privacy-policy'
export const downloadFile = Baseurl + '/hdmeet/api/v1/download_file'
export const webinarMeeting = Baseurl + '/hdmeet/api/v1/webinar_meeting'
export const webinarRegistration = Baseurl + '/hdmeet/api/v1/webinar_registration'
export const webinarRegistrationCount = Baseurl + '/hdmeet/api/v1/registration_count'
export const downloadIcsAttachment = Baseurl + '/hdmeet/api/v1/download_ics_attachment'
export const downloadAttendeeIcsAttachment = Baseurl + '/hdmeet/api/v1/download_attendee_attachment'
export const webMeetingDetail = Baseurl + '/hdmeet/api/v1/web_registration'
export const attendeewebdetail = Baseurl + '/hdmeet/api/v1/attendeewebdetail'
export const showanalytics = Baseurl + '/hdmeet/api/v1/showanalytics'
export const addAttendeeCount = Baseurl + '/hdmeet/api/v1/iswebinarattend'
export const getWebinarList = Baseurl + '/hdmeet/api/v1/get_webinarlist'
export const getAttendeeDetails = Baseurl + '/hdmeet/api/v1/register_attendee_detail'
export const downloadWebinarRecording = Baseurl + '/hdmeet/api/v1/download_webinar_recording'



// Admin Constant
export const hdmeetAdminLoginApi = Baseurl+'/hdmeet/api/v1/admin_login'
export const getAllUsersApi = Baseurl+'/hdmeet/api/v1/oc_user_list'
export const getAllScopesApi = Baseurl+'/hdmeet/api/v1/oc_scopes'
export const getAllfeatureApi = Baseurl+'/hdmeet/api/v1/feature_list'
export const getAllDomainApi = Baseurl+'/hdmeet/api/v1/get_domains'
export const getAllDomainUserListApi = Baseurl+'/hdmeet/api/v1/get_domains_users_list'
export const sendWelcomeEmail = Baseurl+'/hdmeet/api/v1/send_welcome_email'
export const getParticularUserList = Baseurl+'/hdmeet/api/v1/get_particular_user_list'
export const getScope_featureList = Baseurl+'/hdmeet/api/v1/scope_feature'
export const defaultScopeId = 2
