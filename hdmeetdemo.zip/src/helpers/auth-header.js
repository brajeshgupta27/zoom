import {
    onlytoken,
    userName,
    password,
    getOrCreateOcUser,
    userToken,
    backendMeetingApi,
    gettoken,
} from '../constant/index';

export const getAuthToken = async () => {
    try {
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        let result = await fetch(onlytoken, {
            method: 'POST',
            headers: myHeaders,
            body: JSON.stringify({ username: userName, password: password }),
        })
        const data = await result.json()
        return data
    } catch (error) {
        console.log("ERROR",error)
    }
}

export const getOneCloudUserDetail = async (token, authData) => {
    try {
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        myHeaders.append('Authorization', 'Bearer ' + token.access);
        let result = await fetch(getOrCreateOcUser, {
            method: 'POST',
            headers: myHeaders,
            body: JSON.stringify({
                username: authData.username,
                user: authData.user,
                email: authData.user_email,
                scope: authData.scope,
                uid: authData.uid,
                domain: authData.domain,
                display_name: authData.displayName,
                meeting_ids: [authData.domain + "-" + authData.user],
                current_meeting_id: authData.domain + "-" + authData.user,
                territory: authData.territory,
            }),
        })
        const data = await result.json()
        return data
    } catch (error) {
        console.log(error)
    }
}

export const createUpdateAuthToken = async (token, authData) => {
    try {
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        myHeaders.append('Authorization', 'Bearer ' + token.access);
        let result = await fetch(userToken, {
            method: 'POST',
            headers: myHeaders,
            body: JSON.stringify({
                username: authData.username
            }),
        })
        const data = await result.json()
        return data
    } catch (error) {
        console.log(error)
    }
}

export const getMeetingsFromMeetingId = async (token, meeting_id) => {
    try {
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        myHeaders.append('Authorization', 'Bearer ' + token.access);
        let result = await fetch(backendMeetingApi + "/" + meeting_id, {
            method: 'GET',
            headers: myHeaders,
        })
        const data = await result.json()
        return data
    } catch (error) {
        console.log(error)
    }
}

export const getJwtToken = async (token, participant, meeting_password) => {
    let room_name = localStorage.getItem("meetingUrlLink")
    let moderator = true
    if (participant === "join") {
        room_name = this.state.joincname
        moderator = false
    }
    try {
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        myHeaders.append('Authorization', 'Bearer ' + token.access);
        let result = await fetch(gettoken, {
            method: 'POST',
            headers: myHeaders,
            body: JSON.stringify({
                room: room_name,
                is_mod: moderator,
                meeting_password: meeting_password
            }),
        })
        const data = await result.json()
        return data
    } catch (error) {
        console.log(error)
    }
}

export const createBackendMeeting = async (token, displayname, ocUserId, meetingUrl) => {
    try {
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        myHeaders.append('Authorization', 'Bearer ' + token.access);
        let result = await fetch(backendMeetingApi, {
            method: 'POST',
            headers: myHeaders,
            body: JSON.stringify({
                meeting_id: localStorage.getItem("meetingUrlLink"),
                meeting_name: displayname + "'s Room",
                oc_user: ocUserId,
                current_attendees: 1, // NOTE: Need to check 
                total_attendees: 1, // NOTE: Need to check 
                auth_user: true,
                max_limit_reached: false,
                status: 'I',
                is_scheduled: false,
                meeting_url: meetingUrl
            }),
        })
        const data = await result.json()
        return data
    } catch (error) {
        console.log(error)
    }
}
