import {
    onlytoken,
    gettoken,
    userName,
    password,
    Baseurl_invite
} from './constant';

export async function getAuthToken(participant){
    try {
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        let data = await fetch(onlytoken, {
            method: 'POST',
            headers: myHeaders,
            body: JSON.stringify({ username: userName, password: password }),
        }).then((response) => response.json())
            .then(data => {
                return data
            });
    } catch (error) {
        console.log(error)
    }
}

export async function getJwtToken(participant, room_name, moderator){
    token = this.getAuthToken(participant)
    if (participant === "join" && moderator == true) {
        moderator = true
    } else if (participant === "join") {
        moderator = false
    } else {
        moderator = true
    }

    try {
        const myHeaders = new Headers();
        myHeaders.append('Content-Type', 'application/json');
        myHeaders.append('Authorization', 'Bearer ' + token.access);
        await fetch(gettoken, {
            method: 'POST',
            headers: myHeaders,
            body: JSON.stringify({ room: room_name, is_mod: moderator }),
        }).then((response) => response.json())
            .then(data => {
                return data;
            });
    } catch (error) {
        console.log(error)
    }
}

